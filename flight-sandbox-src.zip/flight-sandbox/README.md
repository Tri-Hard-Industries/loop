# Flight sandbox

npm install
npm run dev      (local dev server)
npm run build    (single-file dist/index.html)

Controls: W nose down, S nose up, A/D turn, Shift/Ctrl throttle, Space brakes, drag/scroll camera, F fullscreen, M map, N night, R restart. Two airfields about 10 km apart: Tristan's Field (start, two long parallel runways, terminal, a metropolis to the west via a tunnel road) and North Field (tiny strip beyond a mountain ridge, with a lake and a lakeside mansion in the woods). N toggles night.

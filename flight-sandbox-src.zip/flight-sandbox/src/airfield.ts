import * as THREE from 'three'
import { PAVEMENT_TOP, insidePave, lakeRadius, pointToWorld, toWorld, type Field, type Pave, type Terminal } from './fields'
import { hash, terrainHeight } from './terrain'
import { CARS, M, addObstacle, box, buildMast, flatten, lambert, place, prismRoof, type Site } from './builders'
import { buildCity } from './city'

const LINE_Y = PAVEMENT_TOP + 0.03

const AIRLINES = [0xd8432f, 0x2f6fd8, 0x27a35f, 0xf2a93b, 0x7b4fd1, 0x1fa8c9]
const DIGITS: Record<string, number[]> = {
  '0': [0, 1, 2, 3, 4, 5],
  '1': [1, 2],
  '2': [0, 1, 6, 4, 3],
  '3': [0, 1, 6, 2, 3],
  '4': [5, 6, 1, 2],
  '5': [0, 5, 6, 2, 3],
  '6': [0, 5, 4, 3, 2, 6],
  '7': [0, 1, 2],
  '8': [0, 1, 2, 3, 4, 5, 6],
  '9': [0, 1, 2, 3, 5, 6],
}
const SEGMENTS: [number, number, number, number][] = [
  [0, 4.35, 6, 1.3],
  [2.35, 2.2, 1.3, 4.6],
  [2.35, -2.2, 1.3, 4.6],
  [0, -4.35, 6, 1.3],
  [-2.35, -2.2, 1.3, 4.6],
  [-2.35, 2.2, 1.3, 4.6],
  [0, 0, 6, 1.3],
]

function planform(halfSpan: number, rootChord: number, tipChord: number, sweepDeg: number, thickness: number) {
  const sw = Math.tan((sweepDeg * Math.PI) / 180) * halfSpan
  const sh = new THREE.Shape()
  sh.moveTo(-halfSpan, sw)
  sh.lineTo(-halfSpan, sw + tipChord)
  sh.lineTo(0, rootChord)
  sh.lineTo(halfSpan, sw + tipChord)
  sh.lineTo(halfSpan, sw)
  sh.lineTo(0, 0)
  sh.closePath()
  const geo = new THREE.ExtrudeGeometry(sh, { depth: thickness, bevelEnabled: false })
  geo.rotateX(Math.PI / 2)
  geo.translate(0, thickness / 2, 0)
  return geo
}

function finShape(rootFrom: number, rootTo: number, tipFrom: number, tipTo: number, height: number, thickness: number) {
  const sh = new THREE.Shape()
  sh.moveTo(rootFrom, 0)
  sh.lineTo(rootTo, 0)
  sh.lineTo(tipTo, height)
  sh.lineTo(tipFrom, height)
  sh.closePath()
  const geo = new THREE.ExtrudeGeometry(sh, { depth: thickness, bevelEnabled: false })
  geo.rotateY(-Math.PI / 2)
  geo.translate(thickness / 2, 0, 0)
  return geo
}

function localToWorld(p: Pave, lx: number, lz: number): [number, number] {
  const c = Math.cos(p.a), s = Math.sin(p.a)
  return [p.x + lx * c + lz * s, p.z - lx * s + lz * c]
}

function paveGroup(site: Site, r: Pave, mat: THREE.Material, height = 0.3) {
  const g = new THREE.Group()
  g.position.set(r.x, 0, r.z)
  g.rotation.y = r.a
  place(site, box(r.w, height, r.d, mat), 0, r.y, 0, g)
  site.scene.add(g)
  return g
}

function digit(site: Site, ch: string, x: number, z: number, side: number, parent: THREE.Object3D) {
  for (const i of DIGITS[ch] ?? []) {
    const [u, v, w, h] = SEGMENTS[i]
    place(site, box(w, 0.06, h, M.paint), x + u * side, LINE_Y, z - v * side, parent)
  }
}

function runwayNumbers(site: Site, r: Pave, g: THREE.Group) {
  const deg = (((-r.a * 180) / Math.PI) % 360 + 360) % 360
  let n = Math.round(deg / 10) % 36
  if (n === 0) n = 36
  const far = ((n + 17) % 36) + 1
  for (const [num, side] of [[n, 1], [far, -1]] as [number, number][]) {
    const txt = num.toString().padStart(2, '0')
    digit(site, txt[0], -4.2 * side, side * (r.d / 2 - 66), side, g)
    digit(site, txt[1], 4.2 * side, side * (r.d / 2 - 66), side, g)
  }
}

export function buildRunway(site: Site, r: Pave) {
  const g = paveGroup(site, r, M.runway)
  const half = r.d / 2
  for (let z = -half + 90; z < half - 90; z += 30) place(site, box(0.9, 0.06, 18, M.paint), 0, LINE_Y, z, g)
  const stripes = Math.round(r.w / 6)
  for (const s of [-1, 1]) {
    place(site, box(0.9, 0.06, r.d - 4, M.paint), s * (r.w / 2 - 1.2), LINE_Y, 0, g)
    for (let i = 0; i < stripes; i++) place(site, box(1.8, 0.06, 30, M.paint), ((i - (stripes - 1) / 2) * (r.w - 8)) / (stripes - 1), LINE_Y, s * (half - 22), g)
    if (half > 480) {
      for (const x of [-1, 1]) {
        place(site, box(5, 0.06, 40, M.paint), x * (r.w / 4 + 2), LINE_Y, s * (half - 300), g)
        place(site, box(1.8, 0.06, 22, M.paint), x * (r.w / 4 + 2), LINE_Y, s * (half - 150), g)
        place(site, box(1.8, 0.06, 22, M.paint), x * (r.w / 4 + 5.5), LINE_Y, s * (half - 150), g)
        place(site, box(1.8, 0.06, 22, M.paint), x * (r.w / 4 + 2), LINE_Y, s * (half - 450), g)
      }
    }
  }
  runwayNumbers(site, r, g)
  flatten(g)
  for (let z = -half + 8; z <= half - 8; z += 60) {
    for (const s of [-1, 1]) {
      const [x, zz] = localToWorld(r, s * (r.w / 2 + 1.5), z)
      site.lights.push({ x, y: 0.45, z: zz, color: 0xffffff })
    }
  }
  for (let x = -r.w / 2; x <= r.w / 2; x += 4.5) {
    for (const s of [-1, 1]) {
      const [xx, zz] = localToWorld(r, x, s * (half + 1.5))
      site.lights.push({ x: xx, y: 0.45, z: zz, color: 0x3cff5a })
    }
  }
}

export function buildTaxiway(site: Site, t: Pave, runways: Pave[]) {
  const g = paveGroup(site, t, M.taxi)
  place(site, box(0.5, 0.04, t.d, M.yellow), 0, 0.19, 0, g)
  for (const end of [-1, 1]) {
    const [ex, ez] = localToWorld(t, 0, end * (t.d / 2))
    if (!runways.some(r => insidePave(r, ex, ez, 30))) continue
    for (const off of [14, 17.5]) place(site, box(t.w, 0.05, 0.7, M.yellow), 0, 0.21, end * (t.d / 2 - off), g)
  }
  flatten(g)
  for (let z = -t.d / 2 + 10; z <= t.d / 2 - 10; z += 40) {
    for (const s of [-1, 1]) {
      const [x, zz] = localToWorld(t, s * (t.w / 2 + 1), z)
      site.lights.push({ x, y: 0.45, z: zz, color: 0x4a7dff })
    }
  }
}

export function buildApron(site: Site, a: Pave) {
  paveGroup(site, a, M.apron)
}

function buildRoad(site: Site, r: Pave) {
  paveGroup(site, r, M.road, 0.2)
}

function buildCarpark(site: Site, r: Pave) {
  const g = paveGroup(site, r, M.road, 0.2)
  const cols = Math.floor(r.w / 3.2), rows = Math.floor(r.d / 9)
  const cars = new THREE.InstancedMesh(new THREE.BoxGeometry(1.9, 1.4, 4.2), lambert(0xffffff), cols * rows)
  const m = new THREE.Matrix4()
  const c = new THREE.Color()
  let n = 0
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      if (hash(i + r.x, j + r.z) > 0.6) continue
      m.makeTranslation((i - cols / 2 + 0.5) * 3.2, r.y + 0.8, (j - rows / 2 + 0.5) * 9)
      cars.setMatrixAt(n, m)
      cars.setColorAt(n, c.setHex(CARS[Math.floor(hash(j + r.x, i + r.z) * CARS.length)]))
      n++
    }
  }
  cars.count = n
  cars.castShadow = true
  g.add(cars)
}

function buildHangar(site: Site, x: number, z: number, rot: number, big: boolean, fieldA: number) {
  const [w, h, d] = big ? [46, 14, 34] : [24, 8, 18]
  const g = new THREE.Group()
  g.position.set(x, PAVEMENT_TOP, z)
  g.rotation.y = rot + fieldA
  place(site, box(w, h, d, M.wall), 0, h / 2, 0, g)
  place(site, new THREE.Mesh(prismRoof(w, d, h, big ? 5 : 3.5), big ? M.roofDark : M.roofRed), 0, 0, 0, g)
  place(site, box(w * 0.6, h * 0.75, 0.4, M.steel), 0, h * 0.375, -d / 2 - 0.1, g)
  addObstacle(site, g)
}

function buildTower(site: Site, x: number, z: number, height: number) {
  const g = new THREE.Group()
  g.position.set(x, PAVEMENT_TOP, z)
  place(site, new THREE.Mesh(new THREE.CylinderGeometry(2.4, 3.6, height, 10), M.concrete), 0, height / 2, 0, g)
  place(site, new THREE.Mesh(new THREE.CylinderGeometry(5.8, 4.2, 2.2, 10), M.concrete), 0, height + 1.1, 0, g)
  place(site, new THREE.Mesh(new THREE.CylinderGeometry(5.6, 5.6, 3.6, 10), M.darkGlass), 0, height + 4, 0, g)
  place(site, new THREE.Mesh(new THREE.CylinderGeometry(6.2, 6.2, 0.7, 10), M.white), 0, height + 6.15, 0, g)
  place(site, new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 6, 5), M.steel), 0, height + 9.5, 0, g)
  addObstacle(site, g)
}

function buildFuel(site: Site, x: number, z: number, fieldA: number) {
  const g = new THREE.Group()
  g.position.set(x, PAVEMENT_TOP, z)
  g.rotation.y = fieldA
  const tank = new THREE.CylinderGeometry(7, 7, 9, 12)
  for (const [tx, tz] of [[-9, -9], [9, -9], [-9, 9], [9, 9]]) place(site, new THREE.Mesh(tank, M.white), tx, 4.5, tz, g)
  place(site, box(30, 0.5, 30, M.concrete), 0, 0.25, 0, g)
  addObstacle(site, g)
}

function buildWindsock(site: Site, x: number, z: number, a: number) {
  const g = new THREE.Group()
  g.position.set(x, 0, z)
  g.rotation.y = a
  const sock = new THREE.ConeGeometry(0.8, 3.2, 6)
  sock.rotateZ(Math.PI / 2)
  place(site, new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 7, 6), M.steel), 0, 3.5, 0, g)
  place(site, new THREE.Mesh(sock, M.orange), 1.8, 7, 0, g)
  site.scene.add(flatten(g))
}

function airliner(site: Site, color: number, s: number) {
  const g = new THREE.Group()
  const tail = lambert(color)
  const R = 2
  const yc = 3.7
  const body = new THREE.CylinderGeometry(R, R, 24, 14)
  body.rotateX(Math.PI / 2)
  place(site, new THREE.Mesh(body, M.white), 0, yc, 1, g)
  place(site, new THREE.Mesh(new THREE.SphereGeometry(R, 14, 9), M.white), 0, yc, -11, g).scale.set(1, 1, 2.2)
  const cone = new THREE.CylinderGeometry(0.55, R, 11, 14)
  cone.rotateX(Math.PI / 2)
  place(site, new THREE.Mesh(cone, M.white), 0, yc + 0.5, 18.4, g).rotation.x = -0.09
  place(site, box(2 * R + 0.06, 0.55, 22, M.darkGlass), 0, yc + 0.55, 1, g)
  place(site, box(2.6, 0.7, 1.4, M.darkGlass), 0, yc + 0.55, -12.6, g)
  place(site, box(2 * R + 0.05, 0.35, 25, tail), 0, yc - 0.35, 1, g)
  place(site, new THREE.Mesh(planform(15.5, 5.6, 1.6, 27, 0.45), M.wing), 0, yc - 1.4, -1.6, g)
  place(site, new THREE.Mesh(planform(5.6, 3, 1.2, 32, 0.28), M.wing), 0, yc + 1, 17.5, g)
  place(site, new THREE.Mesh(finShape(13.5, 21.5, 18.6, 21.5, 6.5, 0.4), tail), 0, yc + 1.2, 0, g)
  const nacelle = new THREE.CylinderGeometry(1.15, 1.05, 4.4, 12)
  nacelle.rotateX(Math.PI / 2)
  const intake = new THREE.CylinderGeometry(1.22, 1.22, 0.5, 12)
  intake.rotateX(Math.PI / 2)
  for (const x of [-5.6, 5.6]) {
    place(site, new THREE.Mesh(nacelle, tail), x, yc - 2.3, 0.4, g)
    place(site, new THREE.Mesh(intake, M.darkGlass), x, yc - 2.3, -1.8, g)
    place(site, box(0.5, 1.4, 2.6, M.wing), x, yc - 1.5, 1.2, g)
  }
  const wheel = new THREE.CylinderGeometry(0.45, 0.45, 0.4, 8)
  wheel.rotateZ(Math.PI / 2)
  place(site, new THREE.Mesh(wheel, M.steel), 0, 0.45, -8, g)
  place(site, box(0.3, 2.6, 0.3, M.steel), 0, 1.6, -8, g)
  for (const x of [-2.6, 2.6]) {
    place(site, new THREE.Mesh(wheel, M.steel), x, 0.45, 2.6, g)
    place(site, box(0.3, 2.6, 0.3, M.steel), x, 1.6, 2.6, g)
  }
  g.scale.setScalar(s)
  return flatten(g)
}

function buildTerminal(site: Site, f: Field, t: Terminal) {
  const [cx, cz] = pointToWorld(f, t.x, t.z)
  const main = new THREE.Group()
  main.position.set(cx, PAVEMENT_TOP, cz)
  main.rotation.y = f.a
  place(site, box(t.width, 15, t.length, M.terminal), 0, 7.5, 0, main)
  for (const y of [4, 9, 13.2]) place(site, box(t.width + 0.4, 2.2, t.length + 0.4, M.darkGlass), 0, y, 0, main)
  const roof = new THREE.CylinderGeometry(t.width / 2, t.width / 2, t.length + 2, 20, 1, false, -Math.PI / 2, Math.PI)
  roof.rotateX(-Math.PI / 2)
  roof.scale(1, 0.3, 1)
  roof.translate(0, 15, 0)
  place(site, new THREE.Mesh(roof, M.roofDark), 0, 0, 0, main)
  addObstacle(site, main)

  let jet = 0
  for (const pier of t.piers) {
    const [px, pz] = pointToWorld(f, t.x, t.z + pier.z)
    const g = new THREE.Group()
    g.position.set(px, PAVEMENT_TOP, pz)
    g.rotation.y = f.a
    place(site, box(pier.length, 9, 30, M.terminal), 0, 4.5, 0, g)
    place(site, box(pier.length + 0.4, 2.4, 30.4, M.darkGlass), 0, 6, 0, g)
    place(site, box(pier.length + 1, 0.6, 32, M.roofDark), 0, 9.3, 0, g)
    for (const side of [-1, 1]) place(site, box(pier.length, 0.05, 0.5, M.yellow), 0, 0.21, side * 80, g)
    const gates = Math.floor(pier.length / pier.gate)
    for (let i = 0; i <= gates; i++) {
      const gx = (i - gates / 2) * pier.gate
      if (Math.abs(gx) < t.width / 2 + 12) continue
      for (const side of [-1, 1]) {
        place(site, box(3.6, 3.4, 14, M.steel), gx, 4.2, side * 22, g)
        place(site, new THREE.Mesh(new THREE.CylinderGeometry(2.4, 2.4, 4.4, 8), M.steel), gx, 4.2, side * 30, g)
        place(site, box(0.5, 0.05, 46, M.yellow), gx, 0.21, side * 57, g)
        if (i % 2 === 0) {
          const [jx, jz] = pointToWorld(f, t.x + gx, t.z + pier.z + side * 47)
          const small = hash(jet, 3) > 0.6
          const plane = airliner(site, AIRLINES[jet++ % AIRLINES.length], small ? 0.72 : 1)
          plane.position.set(jx, PAVEMENT_TOP, jz)
          plane.rotation.y = f.a + (side < 0 ? Math.PI : 0)
          addObstacle(site, plane)
          place(site, box(1.8, 1.4, 3, M.yellow), gx + 9, 0.7, side * 38, g)
          for (let k = 0; k < 3; k++) place(site, box(1.6, 1.3, 2.4, M.steel), gx - 9, 0.65, side * (52 + k * 3.2), g)
        }
      }
    }
    addObstacle(site, g)
  }
}

function buildHouse(site: Site, x: number, z: number, rot: number, fieldA: number, dock: number) {
  const g = new THREE.Group()
  g.position.set(x, terrainHeight(x, z) + 0.05, z)
  g.rotation.y = rot + fieldA
  place(site, box(30, 9, 16, M.wall), 0, 4.5, 0, g)
  place(site, new THREE.Mesh(prismRoof(30, 16, 9, 6), M.roofRed), 0, 0, 0, g)
  for (const wx of [-21, 21]) {
    place(site, box(12, 6.5, 12, M.wall), wx, 3.25, 0, g)
    place(site, new THREE.Mesh(prismRoof(12, 12, 6.5, 4.5), M.roofRed), wx, 0, 0, g)
    place(site, box(10, 1.4, 0.3, M.darkGlass), wx, 3.2, 6.15, g)
    place(site, box(10, 1.4, 0.3, M.darkGlass), wx, 3.2, -6.15, g)
  }
  for (const [y, zz] of [[3, 8.15], [7, 8.15], [3, -8.15], [7, -8.15]]) place(site, box(27, 1.5, 0.3, M.darkGlass), 0, y, zz, g)
  for (const cx of [-4.5, -1.5, 1.5, 4.5]) place(site, new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 6.4, 8), M.white), cx, 3.2, 11, g)
  place(site, box(13, 0.7, 5, M.roofRed), 0, 6.8, 10.5, g)
  place(site, box(1.4, 3.5, 1.4, M.steel), -9, 11.5, 2, g)
  place(site, box(1.4, 3.5, 1.4, M.steel), 9, 11.5, -2, g)
  place(site, box(46, 0.5, 16, M.concrete), 0, 0.25, 16, g)
  place(site, box(14, 0.3, 7, M.glass), -10, 0.55, 16, g)
  place(site, box(3.5, 0.35, dock, M.wall), 2, 0.5, 24 + dock / 2, g)
  for (let d = 6; d < dock; d += 8) for (const px of [0.6, 3.4]) place(site, box(0.35, 3, 0.35, M.steel), px, -0.8, 24 + d, g)
  place(site, box(9, 4.5, 10, M.wall), 8.5, 2.6, 24 + dock - 6, g)
  place(site, new THREE.Mesh(prismRoof(9, 10, 4.5, 3), M.roofRed), 8.5, 0.35, 24 + dock - 6, g)
  place(site, box(2.6, 1, 6, M.white), -1.6, 0.2, 24 + dock - 5, g)
  place(site, box(16, 5, 11, M.wall), -30, 2.5, -14, g)
  place(site, new THREE.Mesh(prismRoof(16, 11, 5, 3.2), M.roofDark), -30, 0, -14, g)
  place(site, box(11, 4, 0.3, M.steel), -30, 2, -19.6, g)
  place(site, box(12, 0.2, 30, M.road), -30, 0.1, -32, g)
  addObstacle(site, g)
}

function buildLake(site: Site, x: number, z: number, r: number) {
  const shape = new THREE.Shape()
  for (let i = 0; i < 64; i++) {
    const t = (i / 64) * Math.PI * 2
    const rad = lakeRadius(r, t) * 0.9
    const px = Math.cos(t) * rad, pz = Math.sin(t) * rad
    if (i === 0) shape.moveTo(px, -pz)
    else shape.lineTo(px, -pz)
  }
  shape.closePath()
  const geo = new THREE.ShapeGeometry(shape)
  geo.rotateX(-Math.PI / 2)
  const water = new THREE.Mesh(geo, new THREE.MeshPhongMaterial({ color: 0x2f7fc8, specular: 0x9bbcff, shininess: 90, transparent: true, opacity: 0.86 }))
  water.position.set(x, -1.5, z)
  water.receiveShadow = true
  site.scene.add(water)
}

function buildPortal(site: Site, x: number, z: number, a: number) {
  const g = new THREE.Group()
  g.position.set(x, 0, z)
  g.rotation.y = a
  place(site, box(16, 6, 4, M.concrete), 0, 3, 0, g)
  place(site, box(11, 4.6, 0.6, M.darkGlass), 0, 2.3, -2, g)
  site.scene.add(flatten(g))
}

export function buildLights(site: Site) {
  const mesh = new THREE.InstancedMesh(new THREE.BoxGeometry(0.45, 0.45, 0.45), new THREE.MeshBasicMaterial({ color: 0xffffff }), site.lights.length)
  const m = new THREE.Matrix4()
  const c = new THREE.Color()
  site.lights.forEach((l, i) => {
    mesh.setMatrixAt(i, m.makeTranslation(l.x, l.y, l.z))
    mesh.setColorAt(i, c.setHex(l.color))
  })
  site.scene.add(mesh)
}

export function buildField(site: Site, f: Field) {
  for (const r of f.runways) buildRunway(site, toWorld(f, r))
  const runways = f.runways.map(r => toWorld(f, r))
  for (const t of f.taxiways) buildTaxiway(site, toWorld(f, t), runways)
  for (const a of f.aprons) buildApron(site, toWorld(f, a))
  for (const r of f.roads) buildRoad(site, toWorld(f, r))
  for (const c of f.carparks) buildCarpark(site, toWorld(f, c))
  for (const [hx, hz, rot, size] of f.hangars) {
    const [x, z] = pointToWorld(f, hx, hz)
    buildHangar(site, x, z, rot, size === 2, f.a)
  }
  for (const [tx, tz, h] of f.towers) {
    const [x, z] = pointToWorld(f, tx, tz)
    buildTower(site, x, z, h)
  }
  for (const [fx, fz] of f.fuel) {
    const [x, z] = pointToWorld(f, fx, fz)
    buildFuel(site, x, z, f.a)
  }
  for (const [mx, mz] of f.masts) {
    const [x, z] = pointToWorld(f, mx, mz)
    buildMast(site, x, z)
  }
  if (f.terminal) buildTerminal(site, f, f.terminal)
  for (const st of f.settlements) buildCity(site, f, st)
  for (const [hx, hz, rot, dock] of f.houses) {
    const [x, z] = pointToWorld(f, hx, hz)
    buildHouse(site, x, z, rot, f.a, dock)
  }
  for (const [lx, lz, r] of f.lakes) {
    const [x, z] = pointToWorld(f, lx, lz)
    buildLake(site, x, z, r)
  }
  if (f.name === "Tristan's Field") {
    buildPortal(site, -272, -380, -Math.PI / 2)
    buildPortal(site, -408, -380, Math.PI / 2)
  }
  const [wx, wz] = pointToWorld(f, f.windsock[0], f.windsock[1])
  buildWindsock(site, wx, wz, f.a)
}

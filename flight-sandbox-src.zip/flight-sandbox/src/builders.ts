import * as THREE from 'three'
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js'
import { PAVEMENT_TOP, pointToWorld, type Field } from './fields'
import { hash } from './terrain'

export type Obstacle = { inv: THREE.Matrix4; box: THREE.Box3 }
export type Light = { x: number; y: number; z: number; color: number }
export interface Site {
  scene: THREE.Scene
  obstacles: Obstacle[]
  buildings: [number, number][]
  lights: Light[]
  trees: TreeSpot[]
}
export type TreeSpot = { x: number; z: number; s: number }


export function lambert(color: number, flat = false) {
  return new THREE.MeshLambertMaterial({ color, flatShading: flat })
}

export const M = {
  runway: lambert(0x484a52),
  taxi: lambert(0x5a5c64),
  apron: lambert(0x83868d),
  road: lambert(0x3d3f47),
  paint: lambert(0xf2f1e6),
  yellow: lambert(0xf2c94c),
  wall: lambert(0xe9e3d2),
  terminal: lambert(0xe4e7ea),
  darkGlass: lambert(0x2d3a4a),
  roofRed: lambert(0xc44b3d, true),
  roofDark: lambert(0x6f7783, true),
  steel: lambert(0x5f6875),
  glass: lambert(0x8ec8f0),
  orange: lambert(0xff8c2b),
  white: lambert(0xf6f7f8),
  wing: lambert(0xd0d4da),
  concrete: lambert(0xb9bcc2),
  lamp: new THREE.MeshBasicMaterial({ color: 0xfff6d5 }),
}
function windowTextures() {
  if (typeof document === 'undefined') return { map: null, emissiveMap: null }
  const make = (draw: (ctx: CanvasRenderingContext2D) => void) => {
    const c = document.createElement('canvas')
    c.width = c.height = 64
    const ctx = c.getContext('2d')!
    draw(ctx)
    const t = new THREE.CanvasTexture(c)
    t.wrapS = t.wrapT = THREE.RepeatWrapping
    t.magFilter = THREE.NearestFilter
    t.colorSpace = THREE.SRGBColorSpace
    return t
  }
  const map = make(ctx => {
    ctx.fillStyle = '#ffffff'
    ctx.fillRect(0, 0, 64, 64)
    ctx.fillStyle = '#4e5a68'
    for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) ctx.fillRect(i * 16 + 3, j * 16 + 4, 10, 8)
  })
  const emissiveMap = make(ctx => {
    ctx.fillStyle = '#000000'
    ctx.fillRect(0, 0, 64, 64)
    for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) {
      ctx.fillStyle = hash(i, j) > 0.3 ? '#ffd27a' : '#332a14'
      ctx.fillRect(i * 16 + 3, j * 16 + 4, 10, 8)
    }
  })
  return { map, emissiveMap }
}

export const CITY_MAT = new THREE.MeshLambertMaterial({ vertexColors: true, ...windowTextures(), emissive: 0x000000 })
export const CARS = [0xd8432f, 0x2f6fd8, 0xf6f7f8, 0x2b2b30, 0xc8ccd2, 0x27a35f, 0xf2c94c]
export const WALLS = [0xf3e9cf, 0xe8d8c0, 0xd9e4ea, 0xf0c9a8, 0xe6e6e6, 0xd8c9a3]
export const ROOFS = [0xb5452f, 0x8a5a3b, 0x6b6f76, 0x9a3f36, 0x556270]

export function box(w: number, h: number, d: number, mat: THREE.Material) {
  return new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat)
}

export function place(site: Site, mesh: THREE.Mesh, x: number, y: number, z: number, parent: THREE.Object3D = site.scene) {
  mesh.position.set(x, y, z)
  mesh.castShadow = true
  mesh.receiveShadow = true
  parent.add(mesh)
  return mesh
}

export function flatten(g: THREE.Object3D) {
  const byMat = new Map<THREE.Material, THREE.BufferGeometry[]>()
  for (const ch of g.children) {
    const m = ch as THREE.Mesh
    if (!m.geometry) continue
    m.updateMatrix()
    let geo = m.geometry.index ? m.geometry.toNonIndexed() : m.geometry.clone()
    geo = geo.applyMatrix4(m.matrix)
    geo.deleteAttribute('uv')
    const mat = m.material as THREE.Material
    if (!byMat.has(mat)) byMat.set(mat, [])
    byMat.get(mat)!.push(geo)
  }
  g.clear()
  for (const [mat, geos] of byMat) {
    const mesh = new THREE.Mesh(mergeGeometries(geos), mat)
    mesh.castShadow = true
    mesh.receiveShadow = true
    g.add(mesh)
  }
  return g
}

export function addObstacle(site: Site, g: THREE.Object3D) {
  flatten(g)
  site.scene.add(g)
  g.updateMatrixWorld(true)
  const local = new THREE.Box3()
  const tmp = new THREE.Box3()
  for (const ch of g.children) {
    const m = ch as THREE.Mesh
    if (!m.geometry) continue
    m.geometry.computeBoundingBox()
    tmp.copy(m.geometry.boundingBox!).applyMatrix4(m.matrix)
    local.union(tmp)
  }
  site.obstacles.push({ inv: g.matrixWorld.clone().invert(), box: local })
  site.buildings.push([g.position.x, g.position.z])
}

export function prismRoof(w: number, d: number, wallH: number, pitch: number) {
  const r = w / Math.sqrt(3)
  const sy = pitch / (1.5 * r)
  const g = new THREE.CylinderGeometry(r, r, d + 0.8, 3, 1)
  g.rotateX(-Math.PI / 2)
  g.scale(1.06, sy, 1)
  g.translate(0, wallH + 0.5 * r * sy, 0)
  return g
}

export type HouseSpot = { x: number; z: number; rot: number; s: number }

export function houseCluster(site: Site, f: Field, parent: THREE.Object3D, ox: number, oz: number, spots: HouseSpot[]) {
  if (!spots.length) return
  const bodies = new THREE.InstancedMesh(new THREE.BoxGeometry(8, 5.5, 7), lambert(0xffffff), spots.length)
  const roofs = new THREE.InstancedMesh(prismRoof(8, 7, 5.5, 3.2), lambert(0xffffff, true), spots.length)
  const m = new THREE.Matrix4()
  const q = new THREE.Quaternion()
  const c = new THREE.Color()
  const up = new THREE.Vector3(0, 1, 0)
  const local = new THREE.Box3(new THREE.Vector3(-4.2, 0, -3.7), new THREE.Vector3(4.2, 9, 3.7))
  spots.forEach((h, i) => {
    q.setFromAxisAngle(up, h.rot)
    m.compose(new THREE.Vector3(h.x, 2.75 * h.s, h.z), q, new THREE.Vector3(h.s, h.s, h.s))
    bodies.setMatrixAt(i, m)
    bodies.setColorAt(i, c.setHex(WALLS[Math.floor(hash(i, 5) * WALLS.length)]))
    m.compose(new THREE.Vector3(h.x, 0, h.z), q, new THREE.Vector3(h.s, h.s, h.s))
    roofs.setMatrixAt(i, m)
    roofs.setColorAt(i, c.setHex(ROOFS[Math.floor(hash(i, 6) * ROOFS.length)]))
    const [x, z] = pointToWorld(f, ox + h.x, oz + h.z)
    const world = new THREE.Matrix4().compose(new THREE.Vector3(x, 0, z), q.setFromAxisAngle(up, h.rot + f.a), new THREE.Vector3(h.s, h.s, h.s))
    site.obstacles.push({ inv: world.invert(), box: local })
  })
  bodies.castShadow = roofs.castShadow = true
  bodies.receiveShadow = true
  parent.add(bodies, roofs)
}

export function buildMast(site: Site, x: number, z: number) {
  const g = new THREE.Group()
  g.position.set(x, PAVEMENT_TOP, z)
  place(site, new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.5, 28, 6), M.steel), 0, 14, 0, g)
  place(site, box(3.2, 0.7, 1, M.lamp), 0, 28, 0, g)
  addObstacle(site, g)
}


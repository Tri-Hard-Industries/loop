import * as THREE from 'three'
import type { Input } from './input'
import type { Plane } from './plane'
import type { World } from './world'

const clamp = THREE.MathUtils.clamp
const DEFAULT_ELEVATION = 0.24

export class ChaseCamera {
  camera = new THREE.PerspectiveCamera(58, innerWidth / innerHeight, 0.5, 24000)
  private az = 0
  private el = DEFAULT_ELEVATION
  private dist = 21
  private look = new THREE.Vector3()
  private desired = new THREE.Vector3()

  constructor(private world: World, private plane: Plane) {
    this.reset()
  }

  reset() {
    this.az = 0
    this.el = DEFAULT_ELEVATION
    this.target(this.desired)
    this.camera.position.copy(this.desired)
    this.look.copy(this.plane.pos)
    this.camera.lookAt(this.look)
  }

  update(dt: number, input: Input) {
    const m = input.takeMouse()
    if (input.dragging) {
      this.az -= m.dx * 0.005
      this.el = clamp(this.el + m.dy * 0.005, -0.1, 1.25)
    } else {
      const k = 1 - Math.exp(-1.2 * dt)
      this.az -= this.az * k
      this.el += (DEFAULT_ELEVATION - this.el) * k
    }
    this.dist = clamp(this.dist * Math.exp(m.wheel * 0.0012), 9, 70)
    this.target(this.desired)
    this.camera.position.lerp(this.desired, 1 - Math.exp(-(this.plane.crashed ? 2 : 6) * dt))
    const p = this.plane.pos
    const f = this.plane.forward
    const aim = this.plane.crashed ? p : this.desired.set(p.x + f.x * 6, p.y + f.y * 6 + 1.5, p.z + f.z * 6)
    this.look.lerp(aim, 1 - Math.exp(-9 * dt))
    this.camera.lookAt(this.look)
  }

  private target(out: THREE.Vector3) {
    const a = this.plane.yaw + this.az
    const p = this.plane.pos
    const horizontal = this.dist * Math.cos(this.el)
    out.set(p.x + Math.sin(a) * horizontal, p.y + this.dist * Math.sin(this.el), p.z + Math.cos(a) * horizontal)
    const floor = this.world.groundHeight(out.x, out.z) + 2
    if (out.y < floor) out.y = floor
  }
}

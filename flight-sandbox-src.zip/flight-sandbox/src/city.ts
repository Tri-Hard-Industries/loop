import * as THREE from 'three'
import { LAKES, RIVER, lakeRadius, pointToWorld, type Field, type Settlement } from './fields'
import { hash, noise } from './terrain'
import { CARS, CITY_MAT, M, buildMast, lambert, place, houseCluster, type HouseSpot, type Site } from './builders'

const SLAB = 0x9a9a98
const ROAD = 0x3a3c43
const PATH = 0xcfc8b4
const GLASS = [0x8fa6bd, 0x6f8499, 0xb7bfc8, 0x77899a, 0xa3b8cc, 0x54697d, 0xcdd3d9, 0x8a7f6d, 0x5a6673]
const MID = [0xc4a07c, 0xd6cbb6, 0xa88763, 0xe2d9cb, 0x9d8d7c, 0xd0b48e, 0xb9b1a6, 0xc9b9a5, 0xa79c8e]
const RES = [0xf1e9d8, 0xe4d7c3, 0xd9e2e8, 0xefd2b7, 0xe9e6df]
const IND = [0xd5d8dc, 0xc7ccd1, 0xe0ddd6, 0xb9c3cb]

type Kind = 'water' | 'cbd' | 'tall' | 'mid' | 'res' | 'ind' | 'park' | 'stadium'
type Block = { x0: number; x1: number; z0: number; z1: number; kind: Kind }

const tmpColor = new THREE.Color()

class BoxWriter {
  pos: number[] = []
  nrm: number[] = []
  uv: number[] = []
  col: number[] = []

  box(cx: number, cy: number, cz: number, w: number, h: number, d: number, side: number, top: number, windows: boolean, rot = 0) {
    const hw = w / 2, hh = h / 2, hd = d / 2
    const cr = Math.cos(rot), sr = Math.sin(rot)
    const faces: [number[], number[], number[], number[], number][] = [
      [[hw, -hh, hd], [0, 0, -d], [0, h, 0], [1, 0, 0], d],
      [[-hw, -hh, -hd], [0, 0, d], [0, h, 0], [-1, 0, 0], d],
      [[-hw, -hh, hd], [w, 0, 0], [0, h, 0], [0, 0, 1], w],
      [[hw, -hh, -hd], [-w, 0, 0], [0, h, 0], [0, 0, -1], w],
      [[-hw, hh, hd], [w, 0, 0], [0, 0, -d], [0, 1, 0], 0],
    ]
    for (const [o, u, v, n, len] of faces) {
      const isTop = n[1] === 1
      const su = windows && !isTop ? len / 4 : 0
      const sv = windows && !isTop ? h / 3.5 : 0
      tmpColor.setHex(isTop ? top : side)
      const corners = [
        [0, 0],
        [1, 0],
        [1, 1],
        [0, 0],
        [1, 1],
        [0, 1],
      ]
      for (const [a, b] of corners) {
        const ox = o[0] + u[0] * a + v[0] * b, oz = o[2] + u[2] * a + v[2] * b
        this.pos.push(cx + ox * cr + oz * sr, cy + o[1] + u[1] * a + v[1] * b, cz - ox * sr + oz * cr)
        this.nrm.push(n[0] * cr + n[2] * sr, n[1], -n[0] * sr + n[2] * cr)
        this.uv.push(0.01 + a * su, 0.01 + b * sv)
        this.col.push(tmpColor.r, tmpColor.g, tmpColor.b)
      }
    }
  }

  geometry() {
    const g = new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3))
    g.setAttribute('normal', new THREE.Float32BufferAttribute(this.nrm, 3))
    g.setAttribute('uv', new THREE.Float32BufferAttribute(this.uv, 2))
    g.setAttribute('color', new THREE.Float32BufferAttribute(this.col, 3))
    return g
  }
}

function shade(hex: number, k: number) {
  tmpColor.setHex(hex).multiplyScalar(k)
  return tmpColor.getHex()
}

function pick(list: number[], r: number) {
  return list[Math.floor(r * list.length) % list.length]
}

function streets(length: number, seed: number) {
  const out = [-length / 2]
  let p = -length / 2
  let i = 0
  while (p < length / 2 - 60) {
    p += [70, 80, 95, 110, 125][Math.floor(hash(i++, seed) * 5)]
    out.push(Math.min(p, length / 2))
  }
  if (length / 2 - out[out.length - 1] > 1) out.push(length / 2)
  return out
}

export function buildCity(site: Site, f: Field, c: Settlement) {
  const [wx, wz] = pointToWorld(f, c.x, c.z)
  const g = new THREE.Group()
  g.position.set(wx, 0, wz)
  g.rotation.y = f.a
  const W = new BoxWriter()
  const up = new THREE.Vector3(0, 1, 0)
  const q = new THREE.Quaternion().setFromAxisAngle(up, f.a)
  const houses: HouseSpot[] = []
  const carSpots: { x: number; z: number; rot: number }[] = []

  const toW = (lx: number, lz: number) => pointToWorld(f, c.x + lx, c.z + lz)
  const inWater = (lx: number, lz: number, margin: number) => {
    const [x, z] = toW(lx, lz)
    for (const [cx, cz, r] of LAKES) {
      const dx = x - cx, dz = z - cz
      if (Math.hypot(dx, dz) < lakeRadius(r, Math.atan2(dz, dx)) * 0.95 + margin) return true
    }
    return x > RIVER.x0 && x < RIVER.x1 && Math.abs(z - RIVER.z(x)) < RIVER.half + margin
  }
  const inRiver = (lx: number, lz: number) => {
    const [x, z] = toW(lx, lz)
    return x > RIVER.x0 && x < RIVER.x1 && Math.abs(z - RIVER.z(x)) < RIVER.half + 10
  }
  const obstacle = (bx: number, bz: number, w: number, h: number, d: number) => {
    const [x, z] = toW(bx, bz)
    const m = new THREE.Matrix4().compose(new THREE.Vector3(x, 0, z), q, new THREE.Vector3(1, 1, 1))
    site.obstacles.push({ inv: m.invert(), box: new THREE.Box3(new THREE.Vector3(-w / 2, 0, -d / 2), new THREE.Vector3(w / 2, h + 1, d / 2)) })
    site.buildings.push([x, z])
  }
  const building = (bx: number, bz: number, w: number, h: number, d: number, wall: number, roof: number, windows = true) => {
    W.box(bx, h / 2, bz, w, h, d, wall, roof, windows)
    obstacle(bx, bz, w, h, d)
  }
  const tree = (lx: number, lz: number, s: number) => {
    const [x, z] = toW(lx, lz)
    site.trees.push({ x, z, s })
  }

  const xs = streets(c.w, 11), zs = streets(c.d, 12)
  const widthOf = (i: number, n: number) => (i === Math.round(n * 0.42) || i === Math.round(n * 0.72) ? 24 : i % 4 === 0 ? 14 : 9)
  const xw = xs.map((_, i) => widthOf(i, xs.length))
  const zw = zs.map((_, i) => widthOf(i, zs.length))

  const segment = (along: 'x' | 'z', pos: number, width: number, a: number, b: number) => {
    const mid = (a + b) / 2
    const [p0x, p0z] = along === 'z' ? [pos, a] : [a, pos]
    const [p1x, p1z] = along === 'z' ? [pos, b] : [b, pos]
    if (inWater(p0x, p0z, -5) || inWater(p1x, p1z, -5)) return
    if (along === 'x' && inRiver(mid, pos)) return
    const crossesRiver = along === 'z' && inRiver(pos, mid)
    if (crossesRiver && width < 14) return
    const len = b - a + width
    if (along === 'z') W.box(pos, 0.05, mid, width, 0.1, len, ROAD, ROAD, false)
    else W.box(mid, 0.05, pos, len, 0.1, width, ROAD, ROAD, false)
    if (crossesRiver) {
      const [rx0] = toW(pos, mid)
      const rz = RIVER.z(rx0)
      const rzl = rz - wz
      const span = RIVER.half * 2 + 44
      W.box(pos, -0.55, rzl, width + 2, 1.1, span, 0x8d9096, 0x7d8086, false)
      for (const s of [-1, 1]) {
        W.box(pos + s * (width / 2 + 0.5), 0.75, rzl, 0.3, 1.3, span, 0xc9ccd1, 0xc9ccd1, false)
        for (let t = -span / 2 + 6; t < span / 2; t += 12) W.box(pos + s * (width / 2 + 0.5), 0.9, rzl + t, 0.5, 1.8, 0.5, 0x9ea3aa, 0x9ea3aa, false)
        W.box(pos, -3.2, rzl + s * RIVER.half * 0.45, width - 2, 5.4, 2.4, 0x8d9096, 0x8d9096, false)
        W.box(pos, -2.4, rzl + s * (RIVER.half + 16), width + 2, 3.6, 12, 0xa4a7ab, 0xa4a7ab, false)
      }
    }
    for (let t = a + 10; t < b - 10; t += 26) {
      const r = hash(t + pos, along === 'z' ? 3 : 4)
      if (r > 0.42) continue
      const lane = width >= 14 ? (r > 0.21 ? 4.5 : 1.8) : 1.8
      const side = hash(t, pos) > 0.5 ? 1 : -1
      if (along === 'z') carSpots.push({ x: pos + side * lane, z: t, rot: 0 })
      else carSpots.push({ x: t, z: pos + side * lane, rot: Math.PI / 2 })
    }
    if (width >= 14) {
      for (let t = a + 12; t < b - 12; t += 15) {
        const s = 0.55 + hash(t, pos + 9) * 0.35
        const [tx, tz] = along === 'z' ? [pos, t] : [t, pos]
        if (inWater(tx, tz, 6)) continue
        if (along === 'z') {
          tree(pos - width / 2 - 2.2, t, s)
          tree(pos + width / 2 + 2.2, t, s)
        } else {
          tree(t, pos - width / 2 - 2.2, s)
          tree(t, pos + width / 2 + 2.2, s)
        }
      }
    }
  }
  for (let i = 0; i < xs.length; i++) for (let j = 0; j < zs.length - 1; j++) segment('z', xs[i], xw[i], zs[j], zs[j + 1])
  for (let j = 0; j < zs.length; j++) for (let i = 0; i < xs.length - 1; i++) segment('x', zs[j], zw[j], xs[i], xs[i + 1])
  const quayX0 = Math.max(RIVER.x0, wx - c.w / 2), quayX1 = Math.min(RIVER.x1, wx + c.w / 2)
  for (let x = quayX0 + 20; x < quayX1 - 20; x += 40) {
    const zc = RIVER.z(x)
    const slope = Math.atan2(RIVER.z(x + 20) - RIVER.z(x - 20), 40)
    for (const s of [-1, 1]) {
      const lz = zc + s * (RIVER.half + 14) - wz
      W.box(x - wx, -0.2, lz, 41, 0.5, 14, 0xb3b3ae, 0xb3b3ae, false, -slope)
      W.box(x - wx, -1.6, zc + s * (RIVER.half + 7.5) - wz, 41, 3.6, 1.2, 0x8f9195, 0x8f9195, false, -slope)
      for (let t = -16; t <= 16; t += 16) {
        const tx = x - wx + t * Math.cos(slope), tz = lz + s * 5.5 + t * Math.sin(slope)
        if (hash(tx, tz) > 0.35) tree(tx, tz, 0.55 + hash(tz, tx) * 0.3)
      }
    }
  }

  const cbd1 = { x: 350, z: -180, s: 560 }
  const cbd2 = { x: -950, z: -220, s: 360 }
  const stadiumAt = { x: -200, z: -680 }
  const parkAt = { x: 200, z: 300, rx: 230, rz: 170 }
  const blocks: Block[] = []
  let stadiumDone = false
  for (let i = 0; i < xs.length - 1; i++) {
    for (let j = 0; j < zs.length - 1; j++) {
      const x0 = xs[i] + xw[i] / 2, x1 = xs[i + 1] - xw[i + 1] / 2
      const z0 = zs[j] + zw[j] / 2, z1 = zs[j + 1] - zw[j + 1] / 2
      const bw = x1 - x0, bd = z1 - z0
      if (bw < 24 || bd < 24) continue
      const bx = (x0 + x1) / 2, bz = (z0 + z1) / 2
      let kind: Kind
      const water = inWater(bx, bz, Math.hypot(bw, bd) * 0.35)
      const d1 = Math.hypot(bx - cbd1.x, bz - cbd1.z) / cbd1.s, d2 = Math.hypot(bx - cbd2.x, bz - cbd2.z) / cbd2.s
      const den = Math.max(Math.exp(-d1 * d1), 0.8 * Math.exp(-d2 * d2)) * (0.75 + 0.5 * noise(bx / 300 + 2, bz / 300 + 5))
      if (water) kind = 'water'
      else if (den > 0.7) kind = 'cbd'
      else if (den > 0.42) kind = 'tall'
      else if (den > 0.18) kind = 'mid'
      else kind = 'res'
      if (kind !== 'water' && kind !== 'cbd' && noise(bx / 230 + 7, bz / 230 + 3) > 0.8) kind = 'park'
      if (kind !== 'water' && Math.hypot((bx - parkAt.x) / parkAt.rx, (bz - parkAt.z) / parkAt.rz) < 1) kind = 'park'
      if ((kind === 'res' || kind === 'mid') && bx > c.w / 2 - 420 && Math.abs(bz) < 600) kind = 'ind'
      if (!stadiumDone && kind !== 'water' && x0 <= stadiumAt.x && x1 + xw[i + 1] + 60 >= stadiumAt.x && z0 <= stadiumAt.z && z1 + zw[j + 1] + 60 >= stadiumAt.z && i + 1 < xs.length - 1 && j + 1 < zs.length - 1) {
        stadiumDone = true
        const sx1 = xs[i + 2] - xw[i + 2] / 2, sz1 = zs[j + 2] - zw[j + 2] / 2
        blocks.push({ x0, x1: sx1, z0, z1: sz1, kind: 'stadium' })
        j++
        continue
      }
      blocks.push({ x0, x1, z0, z1, kind })
    }
  }

  for (const b of blocks) fill(b)

  function fill(b: Block) {
    const { x0, x1, z0, z1, kind } = b
    const bw = x1 - x0, bd = z1 - z0
    const bx = (x0 + x1) / 2, bz = (z0 + z1) / 2
    const seed = bx * 3 + bz * 7
    const h = (k: number) => hash(seed, k)
    if (kind === 'water') return
    if (kind === 'stadium') {
      W.box(bx, 0.06, bz, bw, 0.12, bd, SLAB, SLAB, false)
      stadium(bx, bz, bw / 2 - 12, bd / 2 - 12)
      return
    }
    if (kind === 'park') {
      W.box(bx, 0.07, bz, bw - 6, 0.12, 3, PATH, PATH, false)
      W.box(bx, 0.07, bz, 3, 0.12, bd - 6, PATH, PATH, false)
      const n = Math.floor((bw * bd) / 700)
      for (let k = 0; k < n; k++) {
        const tx = x0 + 6 + h(k + 20) * (bw - 12), tz = z0 + 6 + h(k + 60) * (bd - 12)
        if (Math.abs(tx - bx) < 4 || Math.abs(tz - bz) < 4) continue
        tree(tx, tz, 0.8 + h(k + 100) * 0.7)
      }
      return
    }
    W.box(bx, 0.06, bz, bw, 0.12, bd, SLAB, SLAB, false)
    const ix0 = x0 + 3, ix1 = x1 - 3, iz0 = z0 + 3, iz1 = z1 - 3
    const iw = ix1 - ix0, id = iz1 - iz0
    if (kind === 'cbd' || kind === 'tall') {
      const cbd = kind === 'cbd'
      const wall = pick(GLASS, h(2))
      const style = h(13)
      if (style < 0.4) {
        const podH = cbd ? 8 + h(1) * 8 : 5 + h(1) * 5
        building(bx, bz, iw, podH, id, shade(wall, 0.9), 0x5a616a)
        const tw = Math.min(iw, id) * (cbd ? 0.45 + h(3) * 0.2 : 0.35 + h(3) * 0.15)
        const td = Math.min(iw, id) * (cbd ? 0.45 + h(4) * 0.2 : 0.35 + h(4) * 0.15)
        const cx = h(5) > 0.5 ? ix1 - tw / 2 - 2 : ix0 + tw / 2 + 2
        const cz = h(6) > 0.5 ? iz1 - td / 2 - 2 : iz0 + td / 2 + 2
        tower(cx, cz, tw, cbd ? 90 + h(7) * 150 : 45 + h(7) * 80, td, podH, wall)
        if (iw > 60 && id > 50 && h(8) > 0.35) {
          const ox = cx > bx ? ix0 + 12 : ix1 - 12, oz = cz > bz ? iz0 + 10 : iz1 - 10
          tower(ox, oz, 16 + h(9) * 8, cbd ? 40 + h(10) * 70 : 25 + h(10) * 30, 14 + h(11) * 6, podH, pick(GLASS, h(12)))
        }
      } else if (style < 0.72) {
        const tw = Math.min(iw * 0.42, 34), td = Math.min(id * 0.6, 34)
        const gap = iw - 2 * tw
        for (const s of [-1, 1]) {
          const cx = bx + s * (tw / 2 + gap / 2 - 1)
          tower(cx, bz + (h(14 + s) - 0.5) * (id - td) * 0.6, tw, cbd ? 70 + h(15 + s) * 130 : 40 + h(15 + s) * 60, td, 0, s < 0 ? wall : pick(GLASS, h(16)))
        }
        W.box(bx, 0.35, bz, gap - 4, 0.5, id * 0.5, PATH, PATH, false)
        for (let k = 0; k < 4; k++) tree(bx + (h(k + 40) - 0.5) * (gap - 8), bz + (h(k + 45) - 0.5) * id * 0.4, 0.5 + h(k + 50) * 0.3)
      } else {
        const sw = iw * (0.55 + h(17) * 0.25), sd = id * (0.5 + h(18) * 0.25)
        tower(bx, bz, sw, cbd ? 55 + h(19) * 60 : 30 + h(19) * 35, sd, 0, wall)
        perimeter(ix0, ix1, iz0, iz1, seed, 10, 18, MID, 0)
      }
      return
    }
    if (kind === 'ind') {
      const n = iw > 70 ? 2 : 1
      for (let k = 0; k < n; k++) {
        const ww = n === 2 ? iw * 0.42 : iw * 0.7, wd = id * (0.4 + h(k + 30) * 0.3)
        const wxp = n === 2 ? ix0 + ww / 2 + 2 + k * (iw - ww - 4) : bx
        const wzp = iz0 + wd / 2 + 4 + h(k + 40) * (id - wd - 8)
        const wallc = pick(IND, h(k + 50))
        building(wxp, wzp, ww, 7 + h(k + 60) * 5, wd, wallc, shade(wallc, 0.7), false)
      }
      building(ix1 - 8, iz1 - 7, 14, 9, 12, pick(MID, h(70)), 0x6d7076)
      for (let k = 0; k < 5; k++) W.box(ix0 + 4 + k * 3.2, 1.3, iz1 - 8, 2.5, 2.6, 12, pick(CARS, h(k + 80)), pick(CARS, h(k + 80)), false)
      return
    }
    if (kind === 'mid') {
      perimeter(ix0, ix1, iz0, iz1, seed, 12, 30, MID, 0.15)
      for (let x = ix0 + 8; x <= ix1 - 8; x += 18) for (const zz of [z0 - 3.5, z1 + 3.5]) if (hash(x + seed, zz) > 0.45) tree(x, zz, 0.5 + hash(x, zz + seed) * 0.25)
      return
    }
    const style = h(90)
    if (style < 0.28) {
      perimeter(ix0, ix1, iz0, iz1, seed, 8, 13, RES, 0)
      return
    }
    for (const side of [-1, 1]) {
      const zz = side < 0 ? iz0 + 9 : iz1 - 9
      for (let x = ix0 + 8; x <= ix1 - 8; x += 13.5) {
        if (hash(x + seed, side + 5) < 0.2) continue
        houses.push({ x, z: zz, rot: side < 0 ? 0 : Math.PI, s: 0.85 + hash(x, seed) * 0.35 })
      }
    }
    for (let x = ix0 + 6; x <= ix1 - 6; x += 18) for (const zz of [z0 - 3.5, z1 + 3.5]) if (hash(x + seed, zz) > 0.35) tree(x, zz, 0.55 + hash(x, zz + seed) * 0.35)
    if (id > 60) {
      for (let x = ix0 + 6; x <= ix1 - 6; x += 22) {
        if (hash(x + seed, 77) < 0.5) continue
        tree(x, bz, 0.8 + hash(x, seed + 1) * 0.6)
      }
    }
  }

  function perimeter(ix0: number, ix1: number, iz0: number, iz1: number, seed: number, hMin: number, hMax: number, palette: number[], tallChance: number) {
    const iw = ix1 - ix0, id = iz1 - iz0
    const maxDepth = Math.min(18, id / 2 - 2, iw / 2 - 2)
    if (maxDepth < 8) return
    const sides: [number, number, number, number, boolean][] = [
      [ix0, ix1, iz0, 1, true],
      [ix0, ix1, iz1, -1, true],
      [iz0, iz1, ix0, 1, false],
      [iz0, iz1, ix1, -1, false],
    ]
    let n = 0
    for (const [a, b, edge, dir, alongX] of sides) {
      let p = a + (alongX ? 0 : maxDepth)
      const end = b - (alongX ? 0 : maxDepth)
      while (end - p > 8) {
        let lw = 12 + hash(seed + n, 1) * 16
        if (end - p - lw < 9) lw = end - p
        const depth = Math.min(maxDepth, 10 + hash(seed + n, 2) * 8)
        const hh = hash(seed + n, 3) < tallChance ? hMax * 1.5 : hMin + hash(seed + n, 4) * (hMax - hMin)
        const wall = shade(pick(palette, hash(seed + n, 5)), 0.88 + hash(seed + n, 6) * 0.17)
        const cx = alongX ? p + lw / 2 : edge + (dir * depth) / 2
        const cz = alongX ? edge + (dir * depth) / 2 : p + lw / 2
        building(cx, cz, alongX ? lw : depth, hh, alongX ? depth : lw, wall, shade(wall, 0.62))
        if (hh > 14 && hash(seed + n, 7) > 0.5) W.box(cx, hh + 1, cz, 4, 2, 3, 0x6d7076, 0x6d7076, false)
        p += lw
        n++
      }
    }
  }

  function tower(cx: number, cz: number, tw: number, th: number, td: number, y0: number, wall: number) {
    W.box(cx, y0 + th / 2, cz, tw, th, td, wall, 0x4f5862, true)
    let top = y0 + th
    if (th > 110) {
      const uh = th * 0.35
      W.box(cx, top + uh / 2, cz, tw * 0.62, uh, td * 0.62, wall, 0x4f5862, true)
      top += uh
    }
    W.box(cx, top + 0.8, cz, tw * 0.35, 1.6, td * 0.35, 0x5f6670, 0x5f6670, false)
    if (th > 170) W.box(cx, top + 12, cz, 1, 24, 1, 0x9aa3ad, 0x9aa3ad, false)
    obstacle(cx, cz, tw, top + (th > 170 ? 24 : 2), td)
  }

  function stadium(cx: number, cz: number, rx: number, rz: number) {
    const shape = new THREE.Shape()
    shape.absellipse(0, 0, rx, rz, 0, Math.PI * 2, false, 0)
    const hole = new THREE.Path()
    hole.absellipse(0, 0, rx * 0.68, rz * 0.6, 0, Math.PI * 2, true, 0)
    shape.holes.push(hole)
    const geo = new THREE.ExtrudeGeometry(shape, { depth: 16, bevelEnabled: false, curveSegments: 40 })
    geo.rotateX(-Math.PI / 2)
    place(site, new THREE.Mesh(geo, M.concrete), cx, 0.2, cz, g)
    const seats = new THREE.Shape()
    seats.absellipse(0, 0, rx * 0.72, rz * 0.65, 0, Math.PI * 2, false, 0)
    const seatHole = new THREE.Path()
    seatHole.absellipse(0, 0, rx * 0.62, rz * 0.54, 0, Math.PI * 2, true, 0)
    seats.holes.push(seatHole)
    const seatGeo = new THREE.ExtrudeGeometry(seats, { depth: 6, bevelEnabled: false, curveSegments: 40 })
    seatGeo.rotateX(-Math.PI / 2)
    place(site, new THREE.Mesh(seatGeo, lambert(0xc84b3c)), cx, 0.2, cz, g)
    const pitch = new THREE.Shape()
    pitch.absellipse(0, 0, rx * 0.6, rz * 0.52, 0, Math.PI * 2, false, 0)
    const pitchGeo = new THREE.ShapeGeometry(pitch, 40)
    pitchGeo.rotateX(-Math.PI / 2)
    place(site, new THREE.Mesh(pitchGeo, lambert(0x3f9a3a)), cx, 0.35, cz, g)
    for (const [sx, sz] of [[-0.85, -0.8], [0.85, -0.8], [-0.85, 0.8], [0.85, 0.8]]) {
      const [x, z] = toW(cx + sx * rx, cz + sz * rz)
      buildMast(site, x, z)
    }
    obstacle(cx, cz, rx * 2, 18, rz * 2)
  }

  const mesh = new THREE.Mesh(W.geometry(), CITY_MAT)
  mesh.castShadow = true
  mesh.receiveShadow = true
  g.add(mesh)
  houseCluster(site, f, g, c.x, c.z, houses)

  const cars = new THREE.InstancedMesh(new THREE.BoxGeometry(1.9, 1.4, 4.3), lambert(0xffffff), carSpots.length)
  const m = new THREE.Matrix4()
  const cq = new THREE.Quaternion()
  const col = new THREE.Color()
  carSpots.forEach((s, i) => {
    cq.setFromAxisAngle(up, s.rot)
    m.compose(new THREE.Vector3(s.x, 0.8, s.z), cq, new THREE.Vector3(1, 1, 1))
    cars.setMatrixAt(i, m)
    cars.setColorAt(i, col.setHex(pick(CARS, hash(i, 55))))
  })
  cars.castShadow = true
  g.add(cars)
  site.scene.add(g)

  const river = new THREE.Shape()
  const topEdge: [number, number][] = []
  const bottomEdge: [number, number][] = []
  for (let x = RIVER.x0; x <= RIVER.x1; x += 40) {
    topEdge.push([x, RIVER.z(x) - RIVER.half - 6])
    bottomEdge.push([x, RIVER.z(x) + RIVER.half + 6])
  }
  river.moveTo(topEdge[0][0], -topEdge[0][1])
  for (const [x, z] of topEdge) river.lineTo(x, -z)
  for (const [x, z] of bottomEdge.reverse()) river.lineTo(x, -z)
  river.closePath()
  const riverGeo = new THREE.ShapeGeometry(river)
  riverGeo.rotateX(-Math.PI / 2)
  const water = new THREE.Mesh(riverGeo, new THREE.MeshPhongMaterial({ color: 0x2f7fc8, specular: 0x9bbcff, shininess: 90, transparent: true, opacity: 0.86 }))
  water.position.y = -1.55
  water.receiveShadow = true
  site.scene.add(water)
}

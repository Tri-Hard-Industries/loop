import * as THREE from 'three'
import type { World } from './world'

type Part = { mesh: THREE.Mesh; vel: THREE.Vector3; spin: THREE.Vector3; life: number }

export class Debris {
  private parts: Part[] = []
  private geo = new THREE.BoxGeometry(1.1, 0.4, 1.3)
  private mats = [0xd8432f, 0xf3e9cf, 0x2b2b30].map(c => new THREE.MeshLambertMaterial({ color: c }))

  constructor(private scene: THREE.Scene) {}

  spawn(pos: THREE.Vector3, vel: THREE.Vector3) {
    for (let i = 0; i < 16; i++) {
      const mesh = new THREE.Mesh(this.geo, this.mats[i % 3])
      mesh.castShadow = true
      mesh.position.copy(pos)
      mesh.scale.setScalar(0.6 + Math.random() * 1.2)
      this.scene.add(mesh)
      this.parts.push({
        mesh,
        vel: new THREE.Vector3(vel.x * 0.4 + (Math.random() - 0.5) * 24, Math.abs(vel.y) * 0.3 + 4 + Math.random() * 14, vel.z * 0.4 + (Math.random() - 0.5) * 24),
        spin: new THREE.Vector3(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).multiplyScalar(12),
        life: 5,
      })
    }
  }

  update(dt: number, world: World) {
    for (const p of this.parts) {
      p.vel.y -= 9.81 * dt
      p.mesh.position.addScaledVector(p.vel, dt)
      p.mesh.rotation.x += p.spin.x * dt
      p.mesh.rotation.y += p.spin.y * dt
      p.mesh.rotation.z += p.spin.z * dt
      const floor = world.groundHeight(p.mesh.position.x, p.mesh.position.z) + 0.3
      if (p.mesh.position.y < floor) {
        p.mesh.position.y = floor
        p.vel.y *= -0.35
        p.vel.x *= 0.7
        p.vel.z *= 0.7
        p.spin.multiplyScalar(0.6)
      }
      p.life -= dt
    }
    this.parts = this.parts.filter(p => {
      if (p.life > 0) return true
      this.scene.remove(p.mesh)
      return false
    })
  }

  clear() {
    for (const p of this.parts) this.scene.remove(p.mesh)
    this.parts = []
  }
}

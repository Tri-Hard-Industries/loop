export const PAVEMENT_TOP = 0.2
export const HOME_START = { x: -380, z: 700 }

export type Pave = { x: number; z: number; w: number; d: number; a: number; y: number }
export type Pier = { z: number; length: number; gate: number }
export type Terminal = { x: number; z: number; width: number; length: number; piers: Pier[] }
export type Settlement = { x: number; z: number; w: number; d: number; kind: 'city' }
export const RIVER = { x0: -3500, x1: -760, half: 50, z: (x: number) => 120 * Math.sin((x + 2100) / 650) + 60 }
export type Field = {
  name: string
  x: number
  z: number
  a: number
  flat: number
  runways: Pave[]
  taxiways: Pave[]
  aprons: Pave[]
  roads: Pave[]
  carparks: Pave[]
  hangars: [number, number, number, number][]
  towers: [number, number, number][]
  fuel: [number, number][]
  masts: [number, number][]
  windsock: [number, number]
  terminal: Terminal | null
  settlements: Settlement[]
  lakes: [number, number, number][]
  houses: [number, number, number, number][]
}

export function seg(x1: number, z1: number, x2: number, z2: number, w: number, y = 0.03): Pave {
  return { x: (x1 + x2) / 2, z: (z1 + z2) / 2, w, d: Math.hypot(x2 - x1, z2 - z1), a: Math.atan2(x2 - x1, z2 - z1), y }
}

export function rect(x: number, z: number, w: number, d: number, y = 0.03): Pave {
  return { x, z, w, d, a: 0, y }
}

const T = 18
const LAKE_R = 220

export function lakeRadius(r: number, theta: number) {
  return r * (1 + 0.22 * Math.sin(2 * theta + 1) + 0.14 * Math.sin(3 * theta + 2.3) + 0.08 * Math.sin(5 * theta))
}

const LAKE_HOUSE_X = Math.round(-700 + lakeRadius(LAKE_R, -0.35) * 0.81 + 28)

export const FIELDS: Field[] = [
  {
    name: "Tristan's Field",
    x: 0,
    z: 0,
    a: 0,
    flat: 950,
    runways: [seg(-380, 750, -380, -750, 45, 0.05), seg(380, 750, 380, -750, 45, 0.05)],
    taxiways: [
      seg(-300, -780, -300, 780, T),
      seg(300, -780, 300, 780, T),
      ...[-745, -450, 0, 450, 745].flatMap(z => [seg(-368, z, -300, z, T), seg(300, z, 368, z, T)]),
      seg(-372, 160, -300, 30, T),
      seg(-372, -160, -300, -30, T),
      seg(372, 160, 300, 30, T),
      seg(372, -160, 300, -30, T),
      seg(-300, -300, 300, -300, T),
      seg(-300, 300, 300, 300, T),
      ...[-150, 0, 150].flatMap(z => [seg(-300, z, -270, z, T), seg(270, z, 300, z, T)]),
      seg(0, 300, 0, 480, T),
      seg(395, -200, 460, -200, T),
    ],
    aprons: [rect(0, 0, 560, 480), rect(0, 560, 280, 160), rect(520, -200, 120, 160), rect(-330, 660, 40, 80), rect(330, 660, 40, 80), rect(-330, -660, 40, 80), rect(330, -660, 40, 80)],
    roads: [seg(-140, -380, -272, -380, 12, 0.02), seg(-408, -380, -828, -380, 12, 0.02)],
    carparks: [rect(-60, -380, 160, 100, 0.02)],
    hangars: [[-60, 680, 0, 2], [40, 680, 0, 2], [590, -250, Math.PI / 2, 1], [590, -200, Math.PI / 2, 1], [590, -150, Math.PI / 2, 1]],
    towers: [[-250, 60, 48]],
    fuel: [[-560, -650]],
    masts: [[-270, -230], [270, -230], [-270, 230], [270, 230]],
    windsock: [-450, -830],
    terminal: { x: 0, z: 0, width: 70, length: 360, piers: [{ z: -170, length: 380, gate: 44 }, { z: 170, length: 380, gate: 44 }] },
    settlements: [{ x: -2100, z: 0, w: 2600, d: 2000, kind: 'city' }],
    lakes: [[-3500, 40, 300], [-760, 180, 110]],
    houses: [],
  },
  {
    name: 'North Field',
    x: -6800,
    z: -7200,
    a: 0.35,
    flat: 700,
    runways: [seg(0, 360, 0, -360, 30, 0.05)],
    taxiways: [seg(45, -340, 45, 340, 14), seg(12, -330, 45, -330, 14), seg(12, 0, 45, 0, 14), seg(12, 330, 45, 330, 14), seg(45, 60, 85, 60, 14)],
    aprons: [rect(115, 60, 70, 90)],
    roads: [seg(150, 60, 190, 60, 8, 0.02), seg(190, 60, 190, -450, 8, 0.02), seg(190, -450, LAKE_HOUSE_X + 24, -450, 8, 0.02), seg(LAKE_HOUSE_X + 24, -450, LAKE_HOUSE_X + 24, -292, 8, 0.02)],
    carparks: [],
    hangars: [[160, 60, Math.PI / 2, 1]],
    towers: [[110, -10, 18]],
    fuel: [],
    masts: [],
    windsock: [-60, 300],
    terminal: null,
    settlements: [],
    lakes: [[-700, -250, LAKE_R]],
    houses: [[LAKE_HOUSE_X, -250, -Math.PI / 2, 38]],
  },
]

export function toWorld(f: Field, p: Pave): Pave {
  const c = Math.cos(f.a), s = Math.sin(f.a)
  return { x: f.x + p.x * c + p.z * s, z: f.z - p.x * s + p.z * c, w: p.w, d: p.d, a: p.a + f.a, y: p.y }
}

export function pointToWorld(f: Field, x: number, z: number): [number, number] {
  const c = Math.cos(f.a), s = Math.sin(f.a)
  return [f.x + x * c + z * s, f.z - x * s + z * c]
}

export function insidePave(r: Pave, x: number, z: number, margin: number) {
  const dx = x - r.x, dz = z - r.z
  const c = Math.cos(r.a), s = Math.sin(r.a)
  const lx = dx * c - dz * s
  const lz = dx * s + dz * c
  return Math.abs(lx) <= r.w / 2 + margin && Math.abs(lz) <= r.d / 2 + margin
}

export const PAVEMENT: Pave[] = FIELDS.flatMap(f => [...f.runways, ...f.taxiways, ...f.aprons].map(p => toWorld(f, p)))
export const ROADS: Pave[] = FIELDS.flatMap(f => [...f.roads, ...f.carparks].map(p => toWorld(f, p)))
export const TOWNS: Pave[] = FIELDS.flatMap(f => f.settlements.map(t => toWorld(f, rect(t.x, t.z, t.w, t.d))))
export const LAKES: [number, number, number][] = FIELDS.flatMap(f => f.lakes.map(([x, z, r]) => [...pointToWorld(f, x, z), r] as [number, number, number]))
export const TREE_CLUSTERS: { x: number; z: number; r: number; n: number }[] = [
  ...FIELDS.flatMap(f => f.houses.map(([x, z]) => { const [wx, wz] = pointToWorld(f, x, z); return { x: wx, z: wz, r: 170, n: 140 } })),
]
export const FLAT_SPOTS: { x: number; z: number; r0: number; r1: number }[] = [
  ...FIELDS.map(f => ({ x: f.x, z: f.z, r0: f.flat, r1: f.flat + 600 })),
  ...TOWNS.map(t => ({ x: t.x, z: t.z, r0: Math.hypot(t.w, t.d) / 2 + 40, r1: Math.hypot(t.w, t.d) / 2 + 340 })),
  ...LAKES.map(([x, z, r]) => ({ x, z, r0: r * 1.4 + 100, r1: r * 1.4 + 500 })),
]

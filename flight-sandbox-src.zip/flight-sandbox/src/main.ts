import * as THREE from 'three'
import './style.css'
import { Input } from './input'
import { World } from './world'
import { Plane } from './plane'
import { ChaseCamera } from './camera'
import { Debris } from './debris'
import { Hud } from './hud'
import { MapView } from './map'

const canvas = document.getElementById('c') as HTMLCanvasElement
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true })
renderer.setPixelRatio(Math.min(devicePixelRatio, 2))
renderer.setSize(innerWidth, innerHeight)
renderer.shadowMap.enabled = true
renderer.shadowMap.type = THREE.PCFSoftShadowMap

const world = new World()
const plane = new Plane(world)
world.scene.add(plane.mesh)
const debris = new Debris(world.scene)
const cam = new ChaseCamera(world, plane)
const input = new Input(canvas)
const hud = new Hud()
const map = new MapView(plane)

addEventListener('resize', () => {
  renderer.setSize(innerWidth, innerHeight)
  cam.camera.aspect = innerWidth / innerHeight
  cam.camera.updateProjectionMatrix()
})

const clock = new THREE.Clock()

function frame() {
  const dt = Math.min(clock.getDelta(), 0.05)
  if (input.takeRestart()) {
    plane.reset()
    debris.clear()
    cam.reset()
  }
  if (input.takeMap()) map.toggle()
  if (input.takeNight()) world.setNight(!world.night)
  const wasCrashed = plane.crashed
  plane.update(dt, input)
  if (plane.crashed && !wasCrashed) debris.spawn(plane.pos, plane.velocity)
  debris.update(dt, world)
  world.update(dt, plane.pos)
  cam.update(dt, input)
  hud.update(plane)
  map.draw()
  renderer.render(world.scene, cam.camera)
  requestAnimationFrame(frame)
}

frame()

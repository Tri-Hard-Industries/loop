import { FIELDS, LAKES, PAVEMENT, RIVER, ROADS, TOWNS, lakeRadius, type Pave } from './fields'
import { WORLD_HALF, terrainHeight, terrainColor } from './terrain'
import { Color } from 'three'
import { nav } from './nav'
import type { Plane } from './plane'

const SIZE = 900
const K = SIZE / (2 * WORLD_HALF)

export class MapView {
  visible = false
  private panel = document.getElementById('map') as HTMLElement
  private canvas = document.getElementById('mapcanvas') as HTMLCanvasElement
  private ctx = this.canvas.getContext('2d')!
  private terrain = document.createElement('canvas')

  constructor(private plane: Plane) {
    this.canvas.width = this.canvas.height = SIZE
    this.renderTerrain()
    this.canvas.addEventListener('pointerdown', e => this.pick(e))
  }

  toggle() {
    this.visible = !this.visible
    this.panel.hidden = !this.visible
  }

  draw() {
    if (!this.visible) return
    const c = this.ctx
    c.drawImage(this.terrain, 0, 0, SIZE, SIZE)
    c.fillStyle = '#3d8fd8'
    for (const [lx, lz, r] of LAKES) {
      c.beginPath()
      for (let i = 0; i <= 48; i++) {
        const t = (i / 48) * Math.PI * 2
        const rad = lakeRadius(r, t) * 0.81 * K
        c.lineTo(this.px(lx) + Math.cos(t) * rad, this.px(lz) + Math.sin(t) * rad)
      }
      c.fill()
    }
    c.strokeStyle = '#3d8fd8'
    c.lineWidth = RIVER.half * 2 * K
    c.beginPath()
    for (let x = RIVER.x0; x <= RIVER.x1; x += 40) c.lineTo(this.px(x), this.px(RIVER.z(x)))
    c.stroke()
    c.fillStyle = '#a9a6a0'
    for (const t of TOWNS) this.rect(t, 2)
    c.fillStyle = '#3d3f47'
    for (const r of ROADS) this.rect(r, 1)
    c.fillStyle = '#e8e6df'
    for (const p of PAVEMENT) this.rect(p, 1.5)

    const p = this.plane.pos
    const target = nav.target === null ? this.nearestOther() : nav.target
    const tf = FIELDS[target]
    c.strokeStyle = '#ffb347'
    c.lineWidth = 2
    c.setLineDash([8, 6])
    c.beginPath()
    c.moveTo(this.px(p.x), this.px(p.z))
    c.lineTo(this.px(tf.x), this.px(tf.z))
    c.stroke()
    c.setLineDash([])

    c.font = '600 15px "Avenir Next", "Segoe UI", "Trebuchet MS", sans-serif'
    c.textAlign = 'center'
    FIELDS.forEach((f, i) => {
      const x = this.px(f.x), y = this.px(f.z)
      if (i === target) {
        c.strokeStyle = '#ffb347'
        c.lineWidth = 3
        c.beginPath()
        c.arc(x, y, f.flat * K, 0, Math.PI * 2)
        c.stroke()
      }
      const label = i === target ? `${f.name}  ${(Math.hypot(f.x - p.x, f.z - p.z) / 1000).toFixed(1)} km` : f.name
      c.lineWidth = 4
      c.strokeStyle = 'rgba(10, 16, 28, 0.85)'
      c.strokeText(label, x, y - f.flat * K - 8)
      c.fillStyle = i === target ? '#ffb347' : '#fbf7ec'
      c.fillText(label, x, y - f.flat * K - 8)
    })

    const a = Math.atan2(-Math.cos(this.plane.yaw), -Math.sin(this.plane.yaw))
    c.save()
    c.translate(this.px(p.x), this.px(p.z))
    c.rotate(a)
    c.fillStyle = '#ff5f52'
    c.strokeStyle = '#fbf7ec'
    c.lineWidth = 2
    c.beginPath()
    c.moveTo(14, 0)
    c.lineTo(-10, 9)
    c.lineTo(-6, 0)
    c.lineTo(-10, -9)
    c.closePath()
    c.fill()
    c.stroke()
    c.restore()
  }

  private nearestOther() {
    const p = this.plane.pos
    let best = 0, bestD = Infinity
    FIELDS.forEach((f, i) => {
      const d = Math.hypot(f.x - p.x, f.z - p.z)
      if (d > 600 && d < bestD) {
        best = i
        bestD = d
      }
    })
    return best
  }

  private px(v: number) {
    return (v + WORLD_HALF) * K
  }

  private rect(r: Pave, minWidth: number) {
    const c = this.ctx
    c.save()
    c.translate(this.px(r.x), this.px(r.z))
    c.rotate(Math.PI / 2 - r.a)
    const w = Math.max(r.w * K, minWidth)
    c.fillRect(-r.d * K / 2, -w / 2, r.d * K, w)
    c.restore()
  }

  private pick(e: PointerEvent) {
    const b = this.canvas.getBoundingClientRect()
    const x = ((e.clientX - b.left) / b.width - 0.5) * 2 * WORLD_HALF
    const z = ((e.clientY - b.top) / b.height - 0.5) * 2 * WORLD_HALF
    let best = -1, bestD = 1200
    FIELDS.forEach((f, i) => {
      const d = Math.hypot(f.x - x, f.z - z)
      if (d < bestD) {
        best = i
        bestD = d
      }
    })
    if (best >= 0) nav.target = best
  }

  private renderTerrain() {
    const n = 240
    this.terrain.width = this.terrain.height = n
    const tc = this.terrain.getContext('2d')!
    const img = tc.createImageData(n, n)
    const col = new Color()
    for (let j = 0; j < n; j++) {
      for (let i = 0; i < n; i++) {
        const x = ((i + 0.5) / n - 0.5) * 2 * WORLD_HALF
        const z = ((j + 0.5) / n - 0.5) * 2 * WORLD_HALF
        const h = terrainHeight(x, z)
        const dh = terrainHeight(x + 40, z) - h
        const ny = 1 / Math.hypot(1, dh / 40)
        terrainColor(col, h, ny, 0.3)
        const shade = 1 - Math.max(-0.2, Math.min(0.2, dh / 120))
        const k = (j * n + i) * 4
        img.data[k] = col.r * 255 * shade
        img.data[k + 1] = col.g * 255 * shade
        img.data[k + 2] = col.b * 255 * shade
        img.data[k + 3] = 255
      }
    }
    tc.putImageData(img, 0, 0)
  }
}

import * as THREE from 'three'
import type { Input } from './input'
import { HOME_START, PAVEMENT_TOP } from './fields'
import { WORLD_HALF } from './terrain'
import type { World } from './world'

const G = 9.81
export const STALL_SPEED = 22
export const ROTATE_SPEED = 25
const MAX_THRUST = 7.5
const DRAG = 0.0019
const PITCH_RATE = 0.7
const MAX_BANK = 1.0
const ROLL_RATE = 2.2
export const GEAR = 1.17
const START = new THREE.Vector3(HOME_START.x, PAVEMENT_TOP + GEAR, HOME_START.z)

const clamp = THREE.MathUtils.clamp

function approach(v: number, target: number, step: number) {
  return v < target ? Math.min(v + step, target) : Math.max(v - step, target)
}

export class Plane {
  mesh = new THREE.Group()
  pos = new THREE.Vector3()
  velocity = new THREE.Vector3()
  forward = new THREE.Vector3()
  yaw = 0
  pitch = 0
  roll = 0
  speed = 0
  throttle = 0
  onGround = true
  crashed = false
  stalled = false
  landed = false
  crashReason = ''
  private vy = 0
  private airTime = 0
  private prop: THREE.Mesh

  constructor(private world: World) {
    this.prop = this.build()
    this.reset()
  }

  get altitude() {
    return Math.max(0, this.pos.y - GEAR - PAVEMENT_TOP)
  }

  reset() {
    this.pos.copy(START)
    this.velocity.set(0, 0, 0)
    this.yaw = this.pitch = this.roll = 0
    this.speed = this.throttle = this.vy = this.airTime = 0
    this.onGround = true
    this.crashed = this.stalled = this.landed = false
    this.crashReason = ''
    this.mesh.visible = true
    this.sync(0)
  }

  update(dt: number, input: Input) {
    if (this.crashed) return
    const pitchIn = input.axis(['KeyW', 'ArrowUp'], ['KeyS', 'ArrowDown'])
    const turnIn = input.axis(['KeyD', 'ArrowRight'], ['KeyA', 'ArrowLeft'])
    const brake = input.down('Space')
    const thrIn = (input.down('ShiftLeft', 'ShiftRight') ? 1 : 0) - (input.down('ControlLeft', 'ControlRight') ? 1 : 0)
    this.throttle = clamp(this.throttle + thrIn * 0.6 * dt, 0, 1)

    const lift = clamp((this.speed - 0.5 * STALL_SPEED) / (0.5 * STALL_SPEED), 0, 1)
    const authority = clamp(this.speed / STALL_SPEED, 0.15, 1)
    this.stalled = !this.onGround && lift < 1

    if (this.onGround) {
      this.roll += (0 - this.roll) * Math.min(1, 6 * dt)
      if (pitchIn > 0 && this.speed >= ROTATE_SPEED) this.pitch += PITCH_RATE * dt
      else this.pitch += (0 - this.pitch) * Math.min(1, 4 * dt)
      this.pitch = clamp(this.pitch, 0, 0.35)
      this.yaw += turnIn * 1.1 * clamp(this.speed / 6, 0, 1) * dt
    } else {
      const rollRate = turnIn !== 0 ? ROLL_RATE * authority : ROLL_RATE
      this.roll = approach(this.roll, turnIn * MAX_BANK, rollRate * dt)
      this.yaw += clamp((G / Math.max(this.speed, 15)) * Math.tan(this.roll), -0.6, 0.6) * dt
      const trim = -0.12 * (1 - this.throttle)
      if (pitchIn !== 0) this.pitch += pitchIn * PITCH_RATE * authority * dt
      else this.pitch += (trim - this.pitch) * Math.min(1, 0.6 * dt)
      this.pitch -= (1 - lift) * 1.5 * dt
      this.pitch = clamp(this.pitch, -1.0, 1.0)
    }

    let acc = MAX_THRUST * this.throttle - DRAG * this.speed * this.speed - G * Math.sin(this.pitch)
    if (this.onGround) acc -= 0.6 + (brake ? 6 : 0)
    this.speed = Math.max(0, this.speed + acc * dt)

    const cp = Math.cos(this.pitch)
    this.forward.set(-Math.sin(this.yaw) * cp, Math.sin(this.pitch), -Math.cos(this.yaw) * cp)
    if (this.onGround) {
      this.vy = 0
      const rotating = pitchIn > 0 && this.pitch > 0
      this.velocity.set(this.forward.x, rotating ? this.forward.y : 0, this.forward.z).multiplyScalar(this.speed)
    } else {
      this.vy -= G * (1 - lift) * dt
      this.vy += (0 - this.vy) * Math.min(1, 3 * lift * dt)
      this.velocity.copy(this.forward).multiplyScalar(this.speed)
      this.velocity.y += this.vy
      this.airTime += dt
    }
    this.pos.addScaledVector(this.velocity, dt)

    const floor = this.world.groundHeight(this.pos.x, this.pos.z) + GEAR
    if (this.pos.y <= floor + 0.05) {
      if (!this.onGround) this.touchdown()
      this.pos.y = floor
      this.onGround = true
      this.vy = 0
      this.velocity.y = 0
    } else if (this.onGround) {
      this.onGround = false
      this.landed = false
      this.airTime = 0
    }

    if (Math.abs(this.pos.x) > WORLD_HALF || Math.abs(this.pos.z) > WORLD_HALF) this.crash('Flew off the map')
    if (!this.crashed) this.checkObstacles()
    this.sync(dt)
  }

  private touchdown() {
    const pave = this.world.onPavement(this.pos.x, this.pos.z)
    if (this.velocity.y < -7) return this.crash('Hard landing')
    if (Math.abs(this.roll) > 0.45) return this.crash('Wing hit the ground')
    if (this.pitch < -0.2) return this.crash('Nose hit the ground')
    if (!pave && this.speed > 32) return this.crash('Too fast for the grass')
    if (!pave && this.world.slope(this.pos.x, this.pos.z) > 0.2) return this.crash('Hit the hillside')
    this.landed = this.airTime > 1.5
  }

  private checkObstacles() {
    const p = this.pos
    const right = Math.cos(this.yaw), back = -Math.sin(this.yaw)
    const points = [
      [p.x, p.y, p.z],
      [p.x + this.forward.x * 4, p.y + this.forward.y * 4, p.z + this.forward.z * 4],
      [p.x + right * 5.5, p.y, p.z + back * 5.5],
      [p.x - right * 5.5, p.y, p.z - back * 5.5],
    ]
    for (const [x, y, z] of points) if (this.world.collides(x, y, z)) return this.crash('Hit an obstacle')
  }

  private crash(reason: string) {
    this.crashed = true
    this.crashReason = reason
    this.mesh.visible = false
  }

  private sync(dt: number) {
    this.mesh.position.copy(this.pos)
    this.mesh.rotation.set(this.pitch, this.yaw, this.roll, 'YXZ')
    this.prop.rotation.z += (4 + this.throttle * 50) * dt
  }

  private build() {
    const red = new THREE.MeshLambertMaterial({ color: 0xd8432f })
    const cream = new THREE.MeshLambertMaterial({ color: 0xf3e9cf })
    const dark = new THREE.MeshLambertMaterial({ color: 0x2b2b30 })
    const glass = new THREE.MeshLambertMaterial({ color: 0x9fd8ff, transparent: true, opacity: 0.75 })
    const add = (geo: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number) => {
      const m = new THREE.Mesh(geo, mat)
      m.position.set(x, y, z)
      m.castShadow = true
      this.mesh.add(m)
      return m
    }
    add(new THREE.BoxGeometry(1.3, 1.2, 4.6), red, 0, 0, 0.3)
    add(new THREE.BoxGeometry(1.0, 0.9, 1.4), cream, 0, -0.05, -2.6)
    add(new THREE.ConeGeometry(0.35, 0.7, 8), dark, 0, 0, -3.65).rotation.x = -Math.PI / 2
    const prop = add(new THREE.BoxGeometry(0.18, 2.6, 0.12), dark, 0, 0, -3.42)
    add(new THREE.BoxGeometry(11, 0.18, 1.7), cream, 0, 0.25, -0.4)
    add(new THREE.BoxGeometry(11, 0.2, 0.3), red, 0, 0.26, -1.1)
    add(new THREE.BoxGeometry(0.9, 0.7, 1.7), glass, 0, 0.85, -0.6)
    add(new THREE.BoxGeometry(4.2, 0.12, 1.1), cream, 0, 0.2, 2.5)
    add(new THREE.BoxGeometry(0.12, 1.5, 1.2), red, 0, 1.1, 2.5)
    const wheel = new THREE.CylinderGeometry(0.32, 0.32, 0.25, 8)
    wheel.rotateZ(Math.PI / 2)
    const strut = new THREE.BoxGeometry(0.12, 0.7, 0.12)
    for (const x of [-1.4, 1.4]) {
      add(wheel, dark, x, -0.85, -0.3)
      add(strut, dark, x, -0.45, -0.3)
    }
    add(wheel, dark, 0, -0.85, 2.3)
    add(strut, dark, 0, -0.45, 2.3)
    const lamp = (color: number, x: number, y: number, z: number) => add(new THREE.SphereGeometry(0.14, 6, 4), new THREE.MeshBasicMaterial({ color }), x, y, z)
    lamp(0xff2a2a, -5.5, 0.3, -0.4)
    lamp(0x2aff5a, 5.5, 0.3, -0.4)
    lamp(0xffffff, 0, 1.85, 2.5)
    return prop
  }
}

import { Color, MathUtils } from 'three'
import { FLAT_SPOTS, LAKES, RIVER, lakeRadius } from './fields'

export const WORLD_HALF = 8500
const clamp = MathUtils.clamp

export function hash(x: number, z: number) {
  const s = Math.sin(x * 127.1 + z * 311.7) * 43758.5453
  return s - Math.floor(s)
}

export function noise(x: number, z: number) {
  const xi = Math.floor(x), zi = Math.floor(z)
  const fx = x - xi, fz = z - zi
  const u = fx * fx * (3 - 2 * fx), v = fz * fz * (3 - 2 * fz)
  const a = hash(xi, zi), b = hash(xi + 1, zi), c = hash(xi, zi + 1), d = hash(xi + 1, zi + 1)
  return (a * (1 - u) + b * u) * (1 - v) + (c * (1 - u) + d * u) * v
}

export function smoothstep(a: number, b: number, x: number) {
  const t = clamp((x - a) / (b - a), 0, 1)
  return t * t * (3 - 2 * t)
}

export function terrainHeight(x: number, z: number) {
  const d = Math.hypot(x, z)
  const hills = noise(x / 380, z / 380) * 70 + noise(x / 130 + 7.3, z / 130 + 2.1) * 22 + noise(x / 40 + 3.7, z / 40 + 9.2) * 5
  const big = smoothstep(1300, 2400, d) * noise(x / 800 + 2, z / 800 + 9) * 110 + smoothstep(3800, 5200, d) * noise(x / 1300 + 4, z / 1300 + 1) * 140
  const edge = Math.max(Math.abs(x), Math.abs(z))
  const mountains = smoothstep(7300, 8400, edge) * (noise(x / 520 + 11, z / 520 + 5) * 520 + noise(x / 170 + 4, z / 170 + 8) * 90)
  const bump = (u: number, w: number) => Math.exp(-((u / w) ** 2))
  const rx = x + 3400, rz = z + 3600
  const u = rx * 0.727 - rz * 0.687
  const v = rx * 0.687 + rz * 0.727
  const along = bump(u + 800, 620) * 820 + bump(u - 500, 520) * 650 + bump(u - 1800, 560) * 420 + bump(u + 2100, 560) * 380
  const ridge = along * bump(v, 480) * (0.8 + 0.4 * noise(x / 160 + 5, z / 160 + 3))
  let flat = 1
  for (const f of FLAT_SPOTS) flat *= smoothstep(f.r0, f.r1, Math.hypot(x - f.x, z - f.z))
  let bowl = 0
  for (const [lx, lz, r] of LAKES) {
    const dx = x - lx, dz = z - lz
    const u = Math.hypot(dx, dz) / lakeRadius(r, Math.atan2(dz, dx))
    bowl += 10 * (1 - smoothstep(0.35, 1, u))
  }
  if (x > RIVER.x0 && x < RIVER.x1) bowl += 6 * (1 - smoothstep(RIVER.half * 0.6, RIVER.half * 1.5, Math.abs(z - RIVER.z(x))))
  return (hills + big + mountains + ridge) * flat - bowl
}

const GRASS = new Color(0x74b94e)
const DARK_GRASS = new Color(0x4c8c3a)
const ROCK = new Color(0x8d8578)
const SNOW = new Color(0xf4f6f8)
const SAND = new Color(0xd9c99a)

export function terrainColor(out: Color, h: number, ny: number, r: number) {
  out.copy(GRASS).lerp(DARK_GRASS, clamp(h / 140, 0, 1) * 0.75 + r * 0.18)
  if (ny < 0.8) out.lerp(ROCK, clamp((0.8 - ny) / 0.3, 0, 1))
  if (h > 250) out.lerp(SNOW, smoothstep(250, 380, h))
  if (h < 0) out.lerp(SAND, clamp(-h / 2, 0, 1))
}

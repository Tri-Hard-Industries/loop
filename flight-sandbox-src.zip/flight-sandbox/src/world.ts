import * as THREE from 'three'
import { FIELDS, PAVEMENT, PAVEMENT_TOP, ROADS, TOWNS, TREE_CLUSTERS, insidePave } from './fields'
import { WORLD_HALF, hash, terrainColor, terrainHeight } from './terrain'
import { buildField, buildLights } from './airfield'
import { CITY_MAT, M, flatten, type Obstacle, type Site, type TreeSpot } from './builders'

export const SKY = 0x8ec9ff

export class World implements Site {
  scene = new THREE.Scene()
  obstacles: Obstacle[] = []
  buildings: [number, number][] = []
  lights: { x: number; y: number; z: number; color: number }[] = []
  trees: TreeSpot[] = []
  night = false
  private sun = new THREE.DirectionalLight(0xfff1d6, 2.6)
  private hemi = new THREE.HemisphereLight(0xd6ecff, 0x5e9440, 1.2)
  private stars = new THREE.Points()
  private moon = new THREE.Mesh(new THREE.SphereGeometry(110, 16, 12), new THREE.MeshBasicMaterial({ color: 0xe6ecff, fog: false }))
  private clouds: THREE.Group[] = []
  private grid = new Map<number, Obstacle[]>()
  private probe = new THREE.Vector3()

  constructor() {
    this.scene.background = new THREE.Color(SKY)
    this.scene.fog = new THREE.Fog(SKY, 1200, 7500)
    this.scene.add(this.hemi)
    this.buildSky()
    this.sun.castShadow = true
    this.sun.shadow.mapSize.set(2048, 2048)
    this.sun.shadow.bias = -0.0004
    const sc = this.sun.shadow.camera
    sc.left = sc.bottom = -140
    sc.right = sc.top = 140
    sc.near = 10
    sc.far = 900
    this.scene.add(this.sun, this.sun.target)
    this.buildTerrain()
    for (const f of FIELDS) buildField(this, f)
    buildLights(this)
    this.buildGrid()
    this.buildTrees()
    this.buildGrid()
    this.buildClouds()
  }

  collides(x: number, y: number, z: number) {
    const list = this.grid.get(this.cell(x, z))
    if (!list) return false
    for (const o of list) if (o.box.containsPoint(this.probe.set(x, y, z).applyMatrix4(o.inv))) return true
    return false
  }

  private cell(x: number, z: number) {
    return Math.floor((x + WORLD_HALF) / 150) * 4096 + Math.floor((z + WORLD_HALF) / 150)
  }

  private buildGrid() {
    this.grid.clear()
    const m = new THREE.Matrix4()
    const wb = new THREE.Box3()
    for (const o of this.obstacles) {
      wb.copy(o.box).applyMatrix4(m.copy(o.inv).invert())
      for (let x = wb.min.x; x <= wb.max.x + 150; x += 150) {
        for (let z = wb.min.z; z <= wb.max.z + 150; z += 150) {
          const key = this.cell(Math.min(x, wb.max.x), Math.min(z, wb.max.z))
          const list = this.grid.get(key)
          if (list) {
            if (list[list.length - 1] !== o) list.push(o)
          } else this.grid.set(key, [o])
        }
      }
    }
  }

  groundHeight(x: number, z: number) {
    return terrainHeight(x, z) + (this.onPavement(x, z) ? PAVEMENT_TOP : 0)
  }

  onPavement(x: number, z: number, margin = 3) {
    return PAVEMENT.some(r => insidePave(r, x, z, margin))
  }

  setNight(on: boolean) {
    this.night = on
    const sky = on ? 0x0a1020 : SKY
    ;(this.scene.background as THREE.Color).setHex(sky)
    ;(this.scene.fog as THREE.Fog).color.setHex(sky)
    this.hemi.color.setHex(on ? 0x2a3a6a : 0xd6ecff)
    this.hemi.groundColor.setHex(on ? 0x0e1218 : 0x5e9440)
    this.hemi.intensity = on ? 0.35 : 1.2
    this.sun.color.setHex(on ? 0xaabbff : 0xfff1d6)
    this.sun.intensity = on ? 0.45 : 2.6
    this.stars.visible = this.moon.visible = on
    M.darkGlass.emissive.setHex(on ? 0x8a7a3c : 0)
    M.glass.emissive.setHex(on ? 0x5a6a80 : 0)
    CITY_MAT.emissive.setHex(on ? 0xffffff : 0)
  }

  slope(x: number, z: number) {
    const dx = terrainHeight(x + 4, z) - terrainHeight(x - 4, z)
    const dz = terrainHeight(x, z + 4) - terrainHeight(x, z - 4)
    return Math.hypot(dx, dz) / 8
  }

  update(dt: number, focus: THREE.Vector3) {
    this.sun.position.set(focus.x + 150, focus.y + 260, focus.z + 90)
    this.sun.target.position.copy(focus)
    for (const c of this.clouds) {
      c.position.x += 2.5 * dt
      if (c.position.x > 8200) c.position.x = -8200
    }
  }

  private buildSky() {
    const n = 1600
    const pos = new Float32Array(n * 3)
    for (let i = 0; i < n; i++) {
      const u = hash(i, 91) * Math.PI * 2, v = Math.acos(1 - hash(i, 92))
      const r = 9000
      pos[i * 3] = r * Math.sin(v) * Math.cos(u)
      pos[i * 3 + 1] = Math.abs(r * Math.cos(v)) + 200
      pos[i * 3 + 2] = r * Math.sin(v) * Math.sin(u)
    }
    const geo = new THREE.BufferGeometry()
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3))
    this.stars = new THREE.Points(geo, new THREE.PointsMaterial({ color: 0xffffff, size: 18, fog: false, sizeAttenuation: true }))
    this.stars.visible = false
    this.moon.position.set(3200, 2600, -4200)
    this.moon.visible = false
    this.scene.add(this.stars, this.moon)
  }

  private buildTerrain() {
    const size = WORLD_HALF * 2
    const geo = new THREE.PlaneGeometry(size, size, 300, 300)
    geo.rotateX(-Math.PI / 2)
    const p = geo.attributes.position as THREE.BufferAttribute
    for (let i = 0; i < p.count; i++) p.setY(i, terrainHeight(p.getX(i), p.getZ(i)))
    const flat = geo.toNonIndexed()
    flat.computeVertexNormals()
    const pos = flat.attributes.position as THREE.BufferAttribute
    const nrm = flat.attributes.normal as THREE.BufferAttribute
    const colors = new Float32Array(pos.count * 3)
    const c = new THREE.Color()
    for (let i = 0; i < pos.count; i += 3) {
      const h = (pos.getY(i) + pos.getY(i + 1) + pos.getY(i + 2)) / 3
      const ny = (nrm.getY(i) + nrm.getY(i + 1) + nrm.getY(i + 2)) / 3
      terrainColor(c, h, ny, hash(Math.round(pos.getX(i)), Math.round(pos.getZ(i))))
      for (let k = 0; k < 3; k++) c.toArray(colors, (i + k) * 3)
    }
    flat.setAttribute('color', new THREE.BufferAttribute(colors, 3))
    const mesh = new THREE.Mesh(flat, new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true }))
    mesh.receiveShadow = true
    this.scene.add(mesh)
  }

  private buildTrees() {
    const spots: { x: number; y: number; z: number; s: number }[] = []
    for (let i = 0; i < 7000; i++) {
      const x = (hash(i, 1) - 0.5) * 14400
      const z = (hash(i, 2) - 0.5) * 14400
      if (this.onPavement(x, z, 35)) continue
      if (ROADS.some(r => insidePave(r, x, z, 15))) continue
      if (TOWNS.some(r => insidePave(r, x, z, 20))) continue
      if (this.buildings.some(([bx, bz]) => Math.hypot(x - bx, z - bz) < 60)) continue
      const y = terrainHeight(x, z)
      if (y < 0.2 || y > 240 || this.slope(x, z) > 0.6) continue
      spots.push({ x, y, z, s: 0.8 + hash(i, 3) * 0.8 })
    }
    for (const t of this.trees) spots.push({ x: t.x, y: terrainHeight(t.x, t.z), z: t.z, s: t.s })
    TREE_CLUSTERS.forEach((cl, k) => {
      for (let i = 0; i < cl.n; i++) {
        const a = hash(i + k * 1000, 8) * Math.PI * 2, d = Math.sqrt(hash(i + k * 1000, 9)) * cl.r
        const x = cl.x + Math.cos(a) * d, z = cl.z + Math.sin(a) * d
        const y = terrainHeight(x, z)
        if (y < 0.2) continue
        if (this.onPavement(x, z, 8) || ROADS.some(r => insidePave(r, x, z, 6))) continue
        if (this.collides(x, y + 1, z)) continue
        spots.push({ x, y, z, s: 0.9 + hash(i + k * 1000, 10) * 0.9 })
      }
    })
    const trunks = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.35, 0.5, 3, 5), new THREE.MeshLambertMaterial({ color: 0x6b4a2b }), spots.length)
    const leaves = new THREE.InstancedMesh(new THREE.ConeGeometry(2.6, 7, 6), new THREE.MeshLambertMaterial({ flatShading: true }), spots.length)
    const m = new THREE.Matrix4()
    const c = new THREE.Color()
    const identity = new THREE.Matrix4()
    spots.forEach((t, i) => {
      m.makeScale(t.s, t.s, t.s).setPosition(t.x, t.y + 1.5 * t.s, t.z)
      trunks.setMatrixAt(i, m)
      m.makeScale(t.s, t.s, t.s).setPosition(t.x, t.y + 6 * t.s, t.z)
      leaves.setMatrixAt(i, m)
      leaves.setColorAt(i, c.setHSL(0.3 + hash(i, 4) * 0.09, 0.55, 0.3 + hash(i, 5) * 0.12))
      this.obstacles.push({ inv: identity, box: new THREE.Box3().setFromCenterAndSize(new THREE.Vector3(t.x, t.y + 4.5 * t.s, t.z), new THREE.Vector3(3.4 * t.s, 9 * t.s, 3.4 * t.s)) })
    })
    trunks.castShadow = leaves.castShadow = true
    this.scene.add(trunks, leaves)
  }

  private buildClouds() {
    const mat = new THREE.MeshLambertMaterial({ color: 0xffffff, flatShading: true })
    const geo = new THREE.SphereGeometry(1, 7, 5)
    for (let i = 0; i < 160; i++) {
      const g = new THREE.Group()
      const n = 3 + Math.floor(hash(i, 7) * 3)
      for (let k = 0; k < n; k++) {
        const s = new THREE.Mesh(geo, mat)
        const r = 12 + hash(i, k + 10) * 14
        s.scale.set(r * 1.5, r * 0.7, r)
        s.position.set((hash(i, k + 20) - 0.5) * 60, (hash(i, k + 30) - 0.5) * 8, (hash(i, k + 40) - 0.5) * 36)
        g.add(s)
      }
      g.position.set((hash(i, 50) - 0.5) * 16000, 260 + hash(i, 60) * 240, (hash(i, 70) - 0.5) * 16000)
      this.clouds.push(g)
      this.scene.add(flatten(g))
    }
  }
}

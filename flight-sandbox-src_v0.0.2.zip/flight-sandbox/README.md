# Flight sandbox

npm install
npm run dev      (local dev server)
npm run build    (single-file dist/index.html)

Main menu (also on Esc): choose the red Sparrow (230 km/h), the yellow Pelican amphibian (lands on water too) , the bigger blue Kingfisher (330 km/h) or the Condor twin-jet airliner (700 km/h) and a start: any airfield runway, or for the Pelican the city bay or one of the lakes.

Controls: W nose down, S nose up, A/D roll, Q/E rudder, I engine on/off, Shift/Ctrl throttle, Space brakes, drag/scroll camera, F fullscreen, M map, N night, V sound on/off, R restart. Flight model: attitude quaternion with angle of attack, lift, induced and parasitic drag, static stability and stall with autorotation, so loops, rolls, spins and dead-stick glides all work. Sound is synthesized with the Web Audio API (engine, wind, runway, water, stall horn, touchdowns, crashes); the menu has a volume slider and it starts on the first key press or click. Four airfields: Tristan's Field (start, two long parallel runways, terminal, a metropolis to the west via a tunnel road), North Field 10 km north-west (tiny strip beyond a mountain ridge, with a lake and a lakeside mansion in the woods), Crosswind Cove 7.8 km north-east (small strip with one hangar, a lakeside town with a church square, an island lighthouse, farmland, forest and a wind farm), and Longhaul Key 50 km south across the mountains and the coastal plain: an island in the ocean with a 1.8 km runway, small terminal, palm-lined resort town, marina and lighthouse, opposite a mainland fishing town with a ferry pier. N toggles night.

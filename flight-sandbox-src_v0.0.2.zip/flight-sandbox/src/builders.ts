import * as THREE from 'three'
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js'
import { PAVEMENT_TOP, pointToWorld, type Field } from './fields'
import { hash } from './terrain'

export type Obstacle = { inv: THREE.Matrix4; box: THREE.Box3; reason: string }
export const WATER_LEVEL = -1.5
export type Light = { x: number; y: number; z: number; color: number }
export interface Site {
  scene: THREE.Scene
  obstacles: Obstacle[]
  buildings: [number, number][]
  lights: Light[]
  trees: TreeSpot[]
  rotors: THREE.Object3D[]
  farmRects: { x: number; z: number; w: number; d: number; a: number; y: number }[]
}
export type TreeSpot = { x: number; z: number; s: number }


export function lambert(color: number, flat = false) {
  return new THREE.MeshLambertMaterial({ color, flatShading: flat })
}

export const M = {
  runway: lambert(0x484a52),
  taxi: lambert(0x5a5c64),
  apron: lambert(0x83868d),
  road: lambert(0x3d3f47),
  paint: lambert(0xf2f1e6),
  yellow: lambert(0xf2c94c),
  wall: lambert(0xe9e3d2),
  terminal: lambert(0xe4e7ea),
  darkGlass: lambert(0x2d3a4a),
  roofRed: lambert(0xc44b3d, true),
  roofDark: lambert(0x6f7783, true),
  steel: lambert(0x5f6875),
  glass: lambert(0x8ec8f0),
  orange: lambert(0xff8c2b),
  white: lambert(0xf6f7f8),
  wing: lambert(0xd0d4da),
  concrete: lambert(0xb9bcc2),
  lamp: new THREE.MeshBasicMaterial({ color: 0xfff6d5 }),
}
function windowTextures() {
  if (typeof document === 'undefined') return { map: null, emissiveMap: null }
  const make = (draw: (ctx: CanvasRenderingContext2D) => void) => {
    const c = document.createElement('canvas')
    c.width = c.height = 64
    const ctx = c.getContext('2d')!
    draw(ctx)
    const t = new THREE.CanvasTexture(c)
    t.wrapS = t.wrapT = THREE.RepeatWrapping
    t.magFilter = THREE.NearestFilter
    t.colorSpace = THREE.SRGBColorSpace
    return t
  }
  const map = make(ctx => {
    ctx.fillStyle = '#ffffff'
    ctx.fillRect(0, 0, 64, 64)
    ctx.fillStyle = '#4e5a68'
    for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) ctx.fillRect(i * 16 + 3, j * 16 + 4, 10, 8)
  })
  const emissiveMap = make(ctx => {
    ctx.fillStyle = '#000000'
    ctx.fillRect(0, 0, 64, 64)
    for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) {
      ctx.fillStyle = hash(i, j) > 0.3 ? '#ffd27a' : '#332a14'
      ctx.fillRect(i * 16 + 3, j * 16 + 4, 10, 8)
    }
  })
  return { map, emissiveMap }
}

export const CITY_MAT = new THREE.MeshLambertMaterial({ vertexColors: true, ...windowTextures(), emissive: 0x000000 })

function waterTexture() {
  if (typeof document === 'undefined') return null
  const c = document.createElement('canvas')
  c.width = c.height = 128
  const ctx = c.getContext('2d')!
  ctx.fillStyle = '#2f7fc8'
  ctx.fillRect(0, 0, 128, 128)
  for (let i = 0; i < 260; i++) {
    const x = hash(i, 31) * 128, y = hash(i, 32) * 128, r = 6 + hash(i, 33) * 14
    const light = hash(i, 34) > 0.5
    const grd = ctx.createRadialGradient(x, y, 0, x, y, r)
    grd.addColorStop(0, light ? 'rgba(120,190,240,0.35)' : 'rgba(20,70,130,0.35)')
    grd.addColorStop(1, 'rgba(0,0,0,0)')
    ctx.fillStyle = grd
    for (const [dx, dy] of [[0, 0], [-128, 0], [128, 0], [0, -128], [0, 128]]) {
      ctx.beginPath()
      ctx.arc(x + dx, y + dy, r, 0, Math.PI * 2)
      ctx.fill()
    }
  }
  const t = new THREE.CanvasTexture(c)
  t.wrapS = t.wrapT = THREE.RepeatWrapping
  t.repeat.set(1 / 48, 1 / 48)
  t.colorSpace = THREE.SRGBColorSpace
  return t
}

export const WATER_MAT = new THREE.MeshPhongMaterial({ color: 0xffffff, map: waterTexture(), specular: 0x9bbcff, shininess: 90, transparent: true, opacity: 0.88 })
if (!WATER_MAT.map) WATER_MAT.color.setHex(0x2f7fc8)
export const CARS = [0xd8432f, 0x2f6fd8, 0xf6f7f8, 0x2b2b30, 0xc8ccd2, 0x27a35f, 0xf2c94c]
export const WALLS = [0xf3e9cf, 0xe8d8c0, 0xd9e4ea, 0xf0c9a8, 0xe6e6e6, 0xd8c9a3]
export const ROOFS = [0xb5452f, 0x8a5a3b, 0x6b6f76, 0x9a3f36, 0x556270]

const tmpColor = new THREE.Color()

export class BoxWriter {
  pos: number[] = []
  nrm: number[] = []
  uv: number[] = []
  col: number[] = []

  box(cx: number, cy: number, cz: number, w: number, h: number, d: number, side: number, top: number, windows: boolean, rot = 0, tilt = 0) {
    const hw = w / 2, hh = h / 2, hd = d / 2
    const cr = Math.cos(rot), sr = Math.sin(rot)
    const ct = Math.cos(tilt), st = Math.sin(tilt)
    const faces: [number[], number[], number[], number[], number][] = [
      [[hw, -hh, hd], [0, 0, -d], [0, h, 0], [1, 0, 0], d],
      [[-hw, -hh, -hd], [0, 0, d], [0, h, 0], [-1, 0, 0], d],
      [[-hw, -hh, hd], [w, 0, 0], [0, h, 0], [0, 0, 1], w],
      [[hw, -hh, -hd], [-w, 0, 0], [0, h, 0], [0, 0, -1], w],
      [[-hw, hh, hd], [w, 0, 0], [0, 0, -d], [0, 1, 0], 0],
    ]
    for (const [o, u, v, n, len] of faces) {
      const isTop = n[1] === 1
      const su = windows && !isTop ? len / 4 : 0
      const sv = windows && !isTop ? h / 3.5 : 0
      tmpColor.setHex(isTop ? top : side)
      const corners = [
        [0, 0],
        [1, 0],
        [1, 1],
        [0, 0],
        [1, 1],
        [0, 1],
      ]
      for (const [a, b] of corners) {
        const ox = o[0] + u[0] * a + v[0] * b, oy0 = o[1] + u[1] * a + v[1] * b, oz0 = o[2] + u[2] * a + v[2] * b
        const oy = oy0 * ct - oz0 * st, oz = oy0 * st + oz0 * ct
        const ny0 = n[1] * ct - n[2] * st, nz0 = n[1] * st + n[2] * ct
        this.pos.push(cx + ox * cr + oz * sr, cy + oy, cz - ox * sr + oz * cr)
        this.nrm.push(n[0] * cr + nz0 * sr, ny0, -n[0] * sr + nz0 * cr)
        this.uv.push(0.01 + a * su, 0.01 + b * sv)
        this.col.push(tmpColor.r, tmpColor.g, tmpColor.b)
      }
    }
  }

  geometry() {
    const g = new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3))
    g.setAttribute('normal', new THREE.Float32BufferAttribute(this.nrm, 3))
    g.setAttribute('uv', new THREE.Float32BufferAttribute(this.uv, 2))
    g.setAttribute('color', new THREE.Float32BufferAttribute(this.col, 3))
    return g
  }
}

export function writeBoat(W: BoxWriter, x: number, z: number, rot: number, len: number, sail: boolean, color = 0xf6f7f8) {
  const beam = len * 0.36
  W.box(x, WATER_LEVEL + 0.5, z, beam, 1, len * 0.78, color, 0xd8dde3, false, rot)
  const bx = x - Math.sin(rot) * len * 0.42, bz = z - Math.cos(rot) * len * 0.42
  W.box(bx, WATER_LEVEL + 0.5, bz, beam * 0.7, 1, beam * 0.7, color, 0xd8dde3, false, rot + Math.PI / 4)
  if (sail) {
    W.box(x, WATER_LEVEL + 4.5, z, 0.16, 8, 0.16, 0x6d6a62, 0x6d6a62, false, rot)
    W.box(x + Math.sin(rot) * 0.9, WATER_LEVEL + 4.2, z + Math.cos(rot) * 0.9, 0.06, 5.4, 2.0, 0xfbf7ec, 0xfbf7ec, false, rot)
  } else {
    W.box(x + Math.sin(rot) * len * 0.12, WATER_LEVEL + 1.45, z + Math.cos(rot) * len * 0.12, beam * 0.7, 0.9, len * 0.3, 0xe4e7ea, 0x6f7783, false, rot)
    W.box(x + Math.sin(rot) * len * 0.05, WATER_LEVEL + 1.55, z + Math.cos(rot) * len * 0.05, beam * 0.72, 0.4, len * 0.12, 0x2d3a4a, 0x2d3a4a, false, rot)
  }
}

function vehicleGeometry(bus: boolean) {
  const W = new BoxWriter()
  if (bus) {
    W.box(0, 1.7, 0, 2.5, 2.6, 11, 0xffffff, 0xdcdcdc, false)
    W.box(0, 2.15, 0, 2.54, 0.9, 11.04, 0x3b4652, 0x3b4652, false)
    for (const z of [-3.6, 3.6]) for (const x of [-1.05, 1.05]) W.box(x, 0.5, z, 0.3, 1, 1, 0x1a1a1e, 0x1a1a1e, false)
  } else {
    W.box(0, 0.62, 0, 1.8, 0.62, 4.2, 0xffffff, 0xf0f0f0, false)
    W.box(0, 1.15, -0.25, 1.62, 0.5, 2.2, 0x59636f, 0x6f7783, false)
    for (const z of [-1.35, 1.35]) for (const x of [-0.82, 0.82]) W.box(x, 0.32, z, 0.26, 0.64, 0.64, 0x1a1a1e, 0x1a1a1e, false)
  }
  return W.geometry()
}

export const CAR_GEOMETRY = vehicleGeometry(false)
export const BUS_GEOMETRY = vehicleGeometry(true)
export const VEHICLE_MAT = new THREE.MeshLambertMaterial({ vertexColors: true })

export function box(w: number, h: number, d: number, mat: THREE.Material) {
  return new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat)
}

export function place(site: Site, mesh: THREE.Mesh, x: number, y: number, z: number, parent: THREE.Object3D = site.scene) {
  mesh.position.set(x, y, z)
  mesh.castShadow = true
  mesh.receiveShadow = true
  parent.add(mesh)
  return mesh
}

export function flatten(g: THREE.Object3D) {
  const byMat = new Map<THREE.Material, THREE.BufferGeometry[]>()
  for (const ch of g.children) {
    const m = ch as THREE.Mesh
    if (!m.geometry) continue
    m.updateMatrix()
    let geo = m.geometry.index ? m.geometry.toNonIndexed() : m.geometry.clone()
    geo = geo.applyMatrix4(m.matrix)
    geo.deleteAttribute('uv')
    const mat = m.material as THREE.Material
    if (!byMat.has(mat)) byMat.set(mat, [])
    byMat.get(mat)!.push(geo)
  }
  g.clear()
  for (const [mat, geos] of byMat) {
    const mesh = new THREE.Mesh(mergeGeometries(geos), mat)
    mesh.castShadow = true
    mesh.receiveShadow = true
    g.add(mesh)
  }
  return g
}

export function addObstacle(site: Site, g: THREE.Object3D, reason = 'Hit a building') {
  flatten(g)
  site.scene.add(g)
  g.updateMatrixWorld(true)
  const local = new THREE.Box3()
  const tmp = new THREE.Box3()
  for (const ch of g.children) {
    const m = ch as THREE.Mesh
    if (!m.geometry) continue
    m.geometry.computeBoundingBox()
    tmp.copy(m.geometry.boundingBox!).applyMatrix4(m.matrix)
    local.union(tmp)
  }
  site.obstacles.push({ inv: g.matrixWorld.clone().invert(), box: local, reason })
  site.buildings.push([g.position.x, g.position.z])
}

export function prismRoof(w: number, d: number, wallH: number, pitch: number) {
  const r = w / Math.sqrt(3)
  const sy = pitch / (1.5 * r)
  const g = new THREE.CylinderGeometry(r, r, d + 0.8, 3, 1)
  g.rotateX(-Math.PI / 2)
  g.scale(1.06, sy, 1)
  g.translate(0, wallH + 0.5 * r * sy, 0)
  return g
}

export type HouseSpot = { x: number; z: number; rot: number; s: number }

export function houseCluster(site: Site, f: Field, parent: THREE.Object3D, ox: number, oz: number, spots: HouseSpot[]) {
  const reason = 'Hit a house'
  if (!spots.length) return
  const bodies = new THREE.InstancedMesh(new THREE.BoxGeometry(8, 5.5, 7), lambert(0xffffff), spots.length)
  const roofs = new THREE.InstancedMesh(prismRoof(8, 7, 5.5, 3.2), lambert(0xffffff, true), spots.length)
  const chimneyGeo = new THREE.BoxGeometry(0.9, 2.2, 0.9)
  chimneyGeo.translate(2.6, 7.4, 1.4)
  const chimneys = new THREE.InstancedMesh(chimneyGeo, lambert(0x6d6a62), spots.length)
  const doorGeo = new THREE.BoxGeometry(1.1, 2.2, 0.16)
  doorGeo.translate(-1.6, 1.1, 3.55)
  const doors = new THREE.InstancedMesh(doorGeo, lambert(0x4a3a2a), spots.length)
  const m = new THREE.Matrix4()
  const q = new THREE.Quaternion()
  const c = new THREE.Color()
  const up = new THREE.Vector3(0, 1, 0)
  const local = new THREE.Box3(new THREE.Vector3(-4.2, 0, -3.7), new THREE.Vector3(4.2, 9, 3.7))
  spots.forEach((h, i) => {
    q.setFromAxisAngle(up, h.rot)
    m.compose(new THREE.Vector3(h.x, 2.75 * h.s, h.z), q, new THREE.Vector3(h.s, h.s, h.s))
    bodies.setMatrixAt(i, m)
    bodies.setColorAt(i, c.setHex(WALLS[Math.floor(hash(i, 5) * WALLS.length)]))
    m.compose(new THREE.Vector3(h.x, 0, h.z), q, new THREE.Vector3(h.s, h.s, h.s))
    roofs.setMatrixAt(i, m)
    roofs.setColorAt(i, c.setHex(ROOFS[Math.floor(hash(i, 6) * ROOFS.length)]))
    chimneys.setMatrixAt(i, m)
    doors.setMatrixAt(i, m)
    const [x, z] = pointToWorld(f, ox + h.x, oz + h.z)
    const world = new THREE.Matrix4().compose(new THREE.Vector3(x, 0, z), q.setFromAxisAngle(up, h.rot + f.a), new THREE.Vector3(h.s, h.s, h.s))
    site.obstacles.push({ inv: world.invert(), box: local, reason })
  })
  bodies.castShadow = roofs.castShadow = true
  bodies.receiveShadow = true
  parent.add(bodies, roofs, chimneys, doors)
}

export function buildMast(site: Site, x: number, z: number) {
  const g = new THREE.Group()
  g.position.set(x, PAVEMENT_TOP, z)
  place(site, new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.5, 28, 6), M.steel), 0, 14, 0, g)
  place(site, box(3.2, 0.7, 1, M.lamp), 0, 28, 0, g)
  addObstacle(site, g, 'Hit a light mast')
}


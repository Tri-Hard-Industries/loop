import * as THREE from 'three'
import { BAY_X, BOULEVARDS, LAKES, RIVER, lakeRadius, pointToWorld, streets, type Field, type Settlement } from './fields'
import { hash, noise } from './terrain'
import { BoxWriter, CARS, CAR_GEOMETRY, BUS_GEOMETRY, CITY_MAT, M, VEHICLE_MAT, WATER_LEVEL, WATER_MAT, addObstacle, buildMast, lambert, place, prismRoof, houseCluster, writeBoat, type HouseSpot, type Site } from './builders'

const SLAB = 0x9a9a98
const ROAD = 0x3a3c43
const PATH = 0xcfc8b4
const GLASS = [0x8fa6bd, 0x6f8499, 0xb7bfc8, 0x77899a, 0xa3b8cc, 0x54697d, 0xcdd3d9, 0x8a7f6d, 0x5a6673]
const MID = [0xc4a07c, 0xd6cbb6, 0xa88763, 0xe2d9cb, 0x9d8d7c, 0xd0b48e, 0xb9b1a6, 0xc9b9a5, 0xa79c8e]
const RES = [0xf1e9d8, 0xe4d7c3, 0xd9e2e8, 0xefd2b7, 0xe9e6df]
const IND = [0xd5d8dc, 0xc7ccd1, 0xe0ddd6, 0xb9c3cb]

export type Kind = 'water' | 'cbd' | 'tall' | 'mid' | 'res' | 'ind' | 'park' | 'stadium' | 'square'
type Block = { x0: number; x1: number; z0: number; z1: number; kind: Kind }
export const CITY_MAP = {
  blocks: [] as { x0: number; z0: number; x1: number; z1: number; kind: Kind }[],
  streets: [] as { x0: number; z0: number; x1: number; z1: number; w: number }[],
  bridge: null as { x: number; z0: number; z1: number } | null,
}

const tmpColor = new THREE.Color()

function shade(hex: number, k: number) {
  tmpColor.setHex(hex).multiplyScalar(k)
  return tmpColor.getHex()
}

function pick(list: number[], r: number) {
  return list[Math.floor(r * list.length) % list.length]
}

export function buildCity(site: Site, f: Field, c: Settlement) {
  const [wx, wz] = pointToWorld(f, c.x, c.z)
  const g = new THREE.Group()
  g.position.set(wx, 0, wz)
  g.rotation.y = f.a
  const W = new BoxWriter()
  const up = new THREE.Vector3(0, 1, 0)
  const q = new THREE.Quaternion().setFromAxisAngle(up, f.a)
  const houses: HouseSpot[] = []
  const carSpots: { x: number; z: number; rot: number; bus: boolean }[] = []

  const toW = (lx: number, lz: number) => pointToWorld(f, c.x + lx, c.z + lz)
  const inWater = (lx: number, lz: number, margin: number) => {
    const [x, z] = toW(lx, lz)
    for (const [cx, cz, r] of LAKES) {
      const dx = x - cx, dz = z - cz
      if (Math.hypot(dx, dz) < lakeRadius(r, Math.atan2(dz, dx)) * 0.95 + margin) return true
    }
    return x > RIVER.x0 && x < RIVER.x1 && Math.abs(z - RIVER.z(x)) < RIVER.half(x) + margin
  }
  const inRiver = (lx: number, lz: number) => {
    const [x, z] = toW(lx, lz)
    return x > RIVER.x0 && x < RIVER.x1 && Math.abs(z - RIVER.z(x)) < RIVER.half(x) + 10
  }
  const obstacle = (bx: number, bz: number, w: number, h: number, d: number, y0 = 0, reason = 'Hit a building') => {
    const [x, z] = toW(bx, bz)
    const m = new THREE.Matrix4().compose(new THREE.Vector3(x, 0, z), q, new THREE.Vector3(1, 1, 1))
    site.obstacles.push({ inv: m.invert(), box: new THREE.Box3(new THREE.Vector3(-w / 2, y0, -d / 2), new THREE.Vector3(w / 2, y0 + h + 1, d / 2)), reason })
    site.buildings.push([x, z])
  }
  const building = (bx: number, bz: number, w: number, h: number, d: number, wall: number, roof: number, windows = true) => {
    W.box(bx, h / 2, bz, w, h, d, wall, roof, windows)
    obstacle(bx, bz, w, h, d)
  }
  const tree = (lx: number, lz: number, s: number) => {
    const [x, z] = toW(lx, lz)
    site.trees.push({ x, z, s })
  }

  const town = c.kind === 'town'
  const xs = streets(c.w, town ? 13 : 11), zs = streets(c.d, town ? 14 : 12)
  const widthOf = (i: number, n: number) => (town ? (i === Math.round(n * 0.5) ? 12 : 8) : i === Math.round(n * BOULEVARDS[0]) || i === Math.round(n * BOULEVARDS[1]) ? 24 : i % 4 === 0 ? 14 : 9)
  const grandX = town ? NaN : xs[Math.round(xs.length * BOULEVARDS[1])]
  const xw = xs.map((_, i) => widthOf(i, xs.length))
  const zw = zs.map((_, i) => widthOf(i, zs.length))

  const segment = (along: 'x' | 'z', pos: number, width: number, a: number, b: number) => {
    const mid = (a + b) / 2
    const [p0x, p0z] = along === 'z' ? [pos, a] : [a, pos]
    const [p1x, p1z] = along === 'z' ? [pos, b] : [b, pos]
    if (inWater(p0x, p0z, -5) || inWater(p1x, p1z, -5)) return
    if (along === 'x' && inRiver(mid, pos)) return
    const crossesRiver = along === 'z' && inRiver(pos, mid)
    if (crossesRiver && (width < 14 || pos === grandX)) return
    const len = b - a + width
    if (along === 'z') W.box(pos, 0.05, mid, width, 0.1, len, ROAD, ROAD, false)
    else W.box(mid, 0.05, pos, len, 0.1, width, ROAD, ROAD, false)
    const [m0x, m0z] = toW(p0x, p0z), [m1x, m1z] = toW(p1x, p1z)
    CITY_MAP.streets.push({ x0: m0x, z0: m0z, x1: m1x, z1: m1z, w: width })
    if (crossesRiver) {
      const [rx0] = toW(pos, mid)
      const rz = RIVER.z(rx0)
      const rzl = rz - wz
      const span = RIVER.half(rx0) * 2 + 44
      W.box(pos, -0.55, rzl, width + 2, 1.1, span, 0x8d9096, 0x7d8086, false)
      for (const s of [-1, 1]) {
        W.box(pos + s * (width / 2 + 0.5), 0.75, rzl, 0.3, 1.3, span, 0xc9ccd1, 0xc9ccd1, false)
        for (let t = -span / 2 + 6; t < span / 2; t += 12) W.box(pos + s * (width / 2 + 0.5), 0.9, rzl + t, 0.5, 1.8, 0.5, 0x9ea3aa, 0x9ea3aa, false)
        W.box(pos, -3.2, rzl + s * RIVER.half(rx0) * 0.45, width - 2, 5.4, 2.4, 0x8d9096, 0x8d9096, false)
        W.box(pos, -2.4, rzl + s * (RIVER.half(rx0) + 16), width + 2, 3.6, 12, 0xa4a7ab, 0xa4a7ab, false)
      }
    }
    for (let t = a + 10; t < b - 10; t += 26) {
      const r = hash(t + pos, along === 'z' ? 3 : 4)
      if (r > (town ? 0.18 : 0.42)) continue
      const lane = width >= 14 ? (r > 0.21 ? 4.5 : 1.8) : 1.8
      const side = hash(t, pos) > 0.5 ? 1 : -1
      const bus = width >= 14 && hash(t + 3, pos + 7) > 0.9
      const rot = side > 0 ? 0 : Math.PI
      if (along === 'z') carSpots.push({ x: pos + side * lane, z: t, rot, bus })
      else carSpots.push({ x: t, z: pos + side * lane, rot: rot + Math.PI / 2, bus })
    }
    if (width >= 14) {
      for (let t = a + 20; t < b - 12; t += 40) {
        const [lx, lz] = along === 'z' ? [pos, t] : [t, pos]
        if (inWater(lx, lz, 6)) continue
        for (const s of [-1, 1]) {
          const px = along === 'z' ? pos + s * (width / 2 + 1.2) : t, pz = along === 'z' ? t : pos + s * (width / 2 + 1.2)
          W.box(px, 4, pz, 0.25, 8, 0.25, 0x6d7076, 0x6d7076, false)
          W.box(px - (along === 'z' ? s * 1.2 : 0), 8, pz - (along === 'z' ? 0 : s * 1.2), along === 'z' ? 2.4 : 0.3, 0.3, along === 'z' ? 0.3 : 2.4, 0x6d7076, 0x6d7076, false)
          W.box(px - (along === 'z' ? s * 2.2 : 0), 7.8, pz - (along === 'z' ? 0 : s * 2.2), 0.9, 0.35, 0.9, 0xfff6d5, 0xfff6d5, false)
        }
      }
      for (let t = a + 12; t < b - 12; t += 15) {
        const s = 0.55 + hash(t, pos + 9) * 0.35
        const [tx, tz] = along === 'z' ? [pos, t] : [t, pos]
        if (inWater(tx, tz, 6)) continue
        if (along === 'z') {
          tree(pos - width / 2 - 2.2, t, s)
          tree(pos + width / 2 + 2.2, t, s)
        } else {
          tree(t, pos - width / 2 - 2.2, s)
          tree(t, pos + width / 2 + 2.2, s)
        }
      }
    }
  }
  for (let i = 0; i < xs.length; i++) for (let j = 0; j < zs.length - 1; j++) segment('z', xs[i], xw[i], zs[j], zs[j + 1])
  for (let j = 0; j < zs.length; j++) for (let i = 0; i < xs.length - 1; i++) segment('x', zs[j], zw[j], xs[i], xs[i + 1])
  const quayX0 = town ? 1 : Math.max(RIVER.x0, wx - c.w / 2), quayX1 = town ? 0 : Math.min(RIVER.x1, wx + c.w / 2)
  for (let x = quayX0 + 20; x < quayX1 - 20; x += 40) {
    const zc = RIVER.z(x)
    const hw = RIVER.half(x)
    for (const s of [-1, 1]) {
      const edge = (xx: number) => RIVER.z(xx) + s * (RIVER.half(xx) + 7.5)
      const slope = Math.atan2(edge(x + 20) - edge(x - 20), 40)
      const lz = zc + s * (hw + 14) - wz
      if (s > 0 && Math.abs(x - BAY_X) < 250) {
        W.box(x - wx, -1.3, zc + s * (hw + 4) - wz, 41 / Math.cos(slope), 0.4, 30, 0xe3d3a3, 0xe3d3a3, false, -slope)
        for (let t = -14; t <= 14; t += 14) if (hash(x + t, 51) > 0.4) {
          const ux = x - wx + t * Math.cos(slope), uz = zc + s * (hw + 8 + hash(t, x) * 8) - wz + t * Math.sin(slope)
          W.box(ux, -0.2, uz, 0.2, 2.2, 0.2, 0xf6f7f8, 0xf6f7f8, false)
          W.box(ux, 0.95, uz, 2.6, 0.25, 2.6, hash(x, t) > 0.5 ? 0xd8432f : 0x2f6fd8, hash(x, t) > 0.5 ? 0xd8432f : 0x2f6fd8, false)
        }
        continue
      }
      W.box(x - wx, -0.2, lz, 41 / Math.cos(slope), 0.5, 14, 0xb3b3ae, 0xb3b3ae, false, -slope)
      W.box(x - wx, -1.6, zc + s * (hw + 7.5) - wz, 41 / Math.cos(slope), 3.6, 1.2, 0x8f9195, 0x8f9195, false, -slope)
      W.box(x - wx, 0.5, zc + s * (hw + 8.4) - wz, 41 / Math.cos(slope), 1, 0.25, 0x6d7076, 0x6d7076, false, -slope)
      W.box(x - wx, 2.2, zc + s * (hw + 12) - wz, 0.25, 4.4, 0.25, 0x6d7076, 0x6d7076, false)
      W.box(x - wx, 4.4, zc + s * (hw + 12) - wz, 1, 0.4, 0.4, 0xfff6d5, 0xfff6d5, false)
      for (let t = -16; t <= 16; t += 16) {
        const tx = x - wx + t * Math.cos(slope), tz = lz + s * 5.5 + t * Math.sin(slope)
        if (hash(tx, tz) > 0.35) tree(tx, tz, 0.55 + hash(tz, tx) * 0.3)
      }
    }
  }

  if (!town) waterfront()
  function waterfront() {
  grandBridge(grandX, 24)
  const marinaX = BAY_X - 175
  const marinaZ = RIVER.z(marinaX) - RIVER.half(marinaX) - 2 - wz
  W.box(marinaX - wx, -0.5, marinaZ + 55, 4, 0.5, 110, 0xd9c9a0, 0xd9c9a0, false)
  for (let k = 0; k < 6; k++) {
    const pz = marinaZ + 18 + k * 16
    for (const s of [-1, 1]) {
      W.box(marinaX - wx + s * 17, -0.5, pz, 30, 0.4, 1.6, 0xd9c9a0, 0xd9c9a0, false)
      for (let b = 0; b < 4; b++) if (hash(k + b, s + 60) > 0.25) writeBoat(W, marinaX - wx + s * (6 + b * 7), pz + 5.6, 0, 6.5 + hash(b, k) * 2, hash(b + 2, k) > 0.5, hash(b, k + 5) > 0.7 ? 0x2f6fd8 : 0xf6f7f8)
    }
    for (let t = -60; t <= 60; t += 30) W.box(marinaX - wx, -1.5, marinaZ + 55 + t, 0.6, 2.4, 0.6, 0x8a7a5a, 0x8a7a5a, false)
  }
  const ferryX = BAY_X + 170
  const ferryZ = RIVER.z(ferryX) - RIVER.half(ferryX) - wz
  W.box(ferryX - wx, -0.4, ferryZ + 32, 8, 0.6, 64, 0xb3b3ae, 0xb3b3ae, false)
  W.box(ferryX - wx, 2.5, ferryZ + 58, 12, 5, 9, 0xe4e7ea, 0x6f7783, true)
  W.box(ferryX - wx + 12, -0.9, ferryZ + 46, 7, 2.6, 26, 0xf6f7f8, 0xd8dde3, false)
  W.box(ferryX - wx + 12, -0.9, ferryZ + 32, 5, 2.6, 5, 0xf6f7f8, 0xd8dde3, false, Math.PI / 4)
  W.box(ferryX - wx + 12, 1.8, ferryZ + 46, 5.6, 2.4, 16, 0x2f6fd8, 0xe8e8e8, false)
  W.box(ferryX - wx + 12, 2.2, ferryZ + 46, 5.7, 0.9, 16.1, 0x2d3a4a, 0x2d3a4a, false)
  W.box(ferryX - wx + 12, 3.9, ferryZ + 50, 3.2, 1.8, 6, 0xf6f7f8, 0xe8e8e8, false)
  W.box(ferryX - wx + 12, 5.6, ferryZ + 54, 1.2, 2, 1.2, 0xd8432f, 0x2b2b30, false)
  for (let k = 0; k < 10; k++) {
    const bxw = BAY_X + 40 + (hash(k, 21) - 0.5) * 280
    const bzw = RIVER.z(bxw) + (hash(k, 22) - 0.3) * (RIVER.half(bxw) * 1.2)
    writeBoat(W, bxw - wx, bzw - wz, hash(k, 24) * Math.PI, 6 + hash(k, 23) * 5, hash(k, 25) > 0.45)
  }
  }

  const cbd1 = { x: 350, z: -180, s: 560 }
  const cbd2 = { x: -950, z: -220, s: 360 }
  const stadiumAt = { x: -200, z: -680 }
  const parkAt = { x: 200, z: 300, rx: 230, rz: 170 }
  const blocks: Block[] = []
  let stadiumDone = false
  let squareDone = false
  for (let i = 0; i < xs.length - 1; i++) {
    for (let j = 0; j < zs.length - 1; j++) {
      const x0 = xs[i] + xw[i] / 2, x1 = xs[i + 1] - xw[i + 1] / 2
      const z0 = zs[j] + zw[j] / 2, z1 = zs[j + 1] - zw[j + 1] / 2
      const bw = x1 - x0, bd = z1 - z0
      if (bw < 24 || bd < 24) continue
      const bx = (x0 + x1) / 2, bz = (z0 + z1) / 2
      let kind: Kind
      const water = inWater(bx, bz, Math.hypot(bw, bd) * 0.35)
      const d1 = Math.hypot(bx - cbd1.x, bz - cbd1.z) / cbd1.s, d2 = Math.hypot(bx - cbd2.x, bz - cbd2.z) / cbd2.s
      const den = Math.max(Math.exp(-d1 * d1), 0.8 * Math.exp(-d2 * d2)) * (0.75 + 0.5 * noise(bx / 300 + 2, bz / 300 + 5))
      if (town) {
        const dt = Math.hypot(bx / (c.w * 0.5), bz / (c.d * 0.5))
        if (water) kind = 'water'
        else if (dt < 0.22 && !squareDone) { kind = 'square'; squareDone = true }
        else if (dt < 0.55 * (0.8 + 0.4 * noise(bx / 200 + 1, bz / 200 + 8))) kind = 'mid'
        else kind = 'res'
        if (kind === 'res' && noise(bx / 180 + 7, bz / 180 + 3) > 0.82) kind = 'park'
        blocks.push({ x0, x1, z0, z1, kind })
        continue
      }
      if (water) kind = 'water'
      else if (den > 0.7) kind = 'cbd'
      else if (den > 0.42) kind = 'tall'
      else if (den > 0.18) kind = 'mid'
      else kind = 'res'
      if (kind !== 'water' && kind !== 'cbd' && noise(bx / 230 + 7, bz / 230 + 3) > 0.8) kind = 'park'
      if (kind !== 'water' && Math.hypot((bx - parkAt.x) / parkAt.rx, (bz - parkAt.z) / parkAt.rz) < 1) kind = 'park'
      if ((kind === 'res' || kind === 'mid') && bx > c.w / 2 - 420 && Math.abs(bz) < 600) kind = 'ind'
      if (!stadiumDone && kind !== 'water' && x0 <= stadiumAt.x && x1 + xw[i + 1] + 60 >= stadiumAt.x && z0 <= stadiumAt.z && z1 + zw[j + 1] + 60 >= stadiumAt.z && i + 1 < xs.length - 1 && j + 1 < zs.length - 1) {
        stadiumDone = true
        const sx1 = xs[i + 2] - xw[i + 2] / 2, sz1 = zs[j + 2] - zw[j + 2] / 2
        blocks.push({ x0, x1: sx1, z0, z1: sz1, kind: 'stadium' })
        j++
        continue
      }
      blocks.push({ x0, x1, z0, z1, kind })
    }
  }

  for (const b of blocks) {
    fill(b)
    const [ax, az] = toW(b.x0, b.z0), [bx1, bz1] = toW(b.x1, b.z1)
    CITY_MAP.blocks.push({ x0: ax, z0: az, x1: bx1, z1: bz1, kind: b.kind })
  }

  function fill(b: Block) {
    const { x0, x1, z0, z1, kind } = b
    const bw = x1 - x0, bd = z1 - z0
    const bx = (x0 + x1) / 2, bz = (z0 + z1) / 2
    const seed = bx * 3 + bz * 7
    const h = (k: number) => hash(seed, k)
    if (kind === 'water') return
    if (kind === 'stadium') {
      W.box(bx, 0.06, bz, bw, 0.12, bd, SLAB, SLAB, false)
      stadium(bx, bz, bw / 2 - 12, bd / 2 - 12)
      return
    }
    if (kind === 'square') {
      W.box(bx, 0.06, bz, bw, 0.12, bd, PATH, PATH, false)
      church(bx, bz - bd / 4 + 6)
      W.box(bx, 0.6, bz + bd / 4, 6, 1, 6, 0x9a9a98, 0x9a9a98, false)
      W.box(bx, 1.4, bz + bd / 4, 2.4, 0.9, 2.4, 0x3d8fd8, 0x3d8fd8, false)
      for (const [tx, tz] of [[-bw / 2 + 8, -bd / 2 + 8], [bw / 2 - 8, -bd / 2 + 8], [-bw / 2 + 8, bd / 2 - 8], [bw / 2 - 8, bd / 2 - 8], [-bw / 2 + 8, 0], [bw / 2 - 8, 0]]) tree(bx + tx, bz + tz, 0.9)
      return
    }
    if (kind === 'park') {
      W.box(bx, 0.07, bz, bw - 6, 0.12, 3, PATH, PATH, false)
      W.box(bx, 0.07, bz, 3, 0.12, bd - 6, PATH, PATH, false)
      const n = Math.floor((bw * bd) / 700)
      for (let k = 0; k < n; k++) {
        const tx = x0 + 6 + h(k + 20) * (bw - 12), tz = z0 + 6 + h(k + 60) * (bd - 12)
        if (Math.abs(tx - bx) < 4 || Math.abs(tz - bz) < 4) continue
        tree(tx, tz, 0.8 + h(k + 100) * 0.7)
      }
      return
    }
    W.box(bx, 0.06, bz, bw, 0.12, bd, SLAB, SLAB, false)
    const ix0 = x0 + 3, ix1 = x1 - 3, iz0 = z0 + 3, iz1 = z1 - 3
    const iw = ix1 - ix0, id = iz1 - iz0
    if (kind === 'cbd' || kind === 'tall') {
      const cbd = kind === 'cbd'
      const wall = pick(GLASS, h(2))
      const style = h(13)
      if (style < 0.4) {
        const podH = cbd ? 8 + h(1) * 8 : 5 + h(1) * 5
        building(bx, bz, iw, podH, id, shade(wall, 0.9), 0x5a616a)
        const tw = Math.min(iw, id) * (cbd ? 0.45 + h(3) * 0.2 : 0.35 + h(3) * 0.15)
        const td = Math.min(iw, id) * (cbd ? 0.45 + h(4) * 0.2 : 0.35 + h(4) * 0.15)
        const cx = h(5) > 0.5 ? ix1 - tw / 2 - 2 : ix0 + tw / 2 + 2
        const cz = h(6) > 0.5 ? iz1 - td / 2 - 2 : iz0 + td / 2 + 2
        tower(cx, cz, tw, cbd ? 90 + h(7) * 150 : 45 + h(7) * 80, td, podH, wall)
        if (iw > 60 && id > 50 && h(8) > 0.35) {
          const ox = cx > bx ? ix0 + 12 : ix1 - 12, oz = cz > bz ? iz0 + 10 : iz1 - 10
          tower(ox, oz, 16 + h(9) * 8, cbd ? 40 + h(10) * 70 : 25 + h(10) * 30, 14 + h(11) * 6, podH, pick(GLASS, h(12)))
        }
      } else if (style < 0.72) {
        const tw = Math.min(iw * 0.42, 34), td = Math.min(id * 0.6, 34)
        const gap = iw - 2 * tw
        for (const s of [-1, 1]) {
          const cx = bx + s * (tw / 2 + gap / 2 - 1)
          tower(cx, bz + (h(14 + s) - 0.5) * (id - td) * 0.6, tw, cbd ? 70 + h(15 + s) * 130 : 40 + h(15 + s) * 60, td, 0, s < 0 ? wall : pick(GLASS, h(16)))
        }
        W.box(bx, 0.35, bz, gap - 4, 0.5, id * 0.5, PATH, PATH, false)
        for (let k = 0; k < 4; k++) tree(bx + (h(k + 40) - 0.5) * (gap - 8), bz + (h(k + 45) - 0.5) * id * 0.4, 0.5 + h(k + 50) * 0.3)
      } else {
        const sw = iw * (0.55 + h(17) * 0.25), sd = id * (0.5 + h(18) * 0.25)
        tower(bx, bz, sw, cbd ? 55 + h(19) * 60 : 30 + h(19) * 35, sd, 0, wall)
        perimeter(ix0, ix1, iz0, iz1, seed, 10, 18, MID, 0)
      }
      return
    }
    if (kind === 'ind') {
      const n = iw > 70 ? 2 : 1
      for (let k = 0; k < n; k++) {
        const ww = n === 2 ? iw * 0.42 : iw * 0.7, wd = id * (0.4 + h(k + 30) * 0.3)
        const wxp = n === 2 ? ix0 + ww / 2 + 2 + k * (iw - ww - 4) : bx
        const wzp = iz0 + wd / 2 + 4 + h(k + 40) * (id - wd - 8)
        const wallc = pick(IND, h(k + 50))
        building(wxp, wzp, ww, 7 + h(k + 60) * 5, wd, wallc, shade(wallc, 0.7), false)
      }
      building(ix1 - 8, iz1 - 7, 14, 9, 12, pick(MID, h(70)), 0x6d7076)
      for (let k = 0; k < 5; k++) W.box(ix0 + 4 + k * 3.2, 1.3, iz1 - 8, 2.5, 2.6, 12, pick(CARS, h(k + 80)), pick(CARS, h(k + 80)), false)
      for (let k = 0; k < 3; k++) {
        const tx = ix0 + 22 + k * 9, tz = iz1 - 4
        W.box(tx, 0.6, tz, 4, 1.2, 1.4, 0x3b4046, 0x3b4046, false)
        if (h(k + 90) > 0.4) {
          W.box(tx, 1.9, tz - 8, 2.5, 3, 10, 0xe6e6e6, 0xd0d0d0, false)
          W.box(tx, 1.6, tz - 14.6, 2.5, 2.6, 3, pick(CARS, h(k + 95)), 0x3b4652, false)
        }
      }
      return
    }
    if (kind === 'mid') {
      const resort = town && c.resort
      perimeter(ix0, ix1, iz0, iz1, seed, resort ? 10 : town ? 7 : 12, resort ? 26 : town ? 13 : 30, resort ? [0xf6f1e8, 0xf2d9c4, 0xdfe9ef, 0xf7e7c9, 0xe9f2e4] : town ? [...RES, ...MID] : MID, town ? 0 : 0.15)
      for (let x = ix0 + 8; x <= ix1 - 8; x += 18) for (const zz of [z0 - 3.5, z1 + 3.5]) if (hash(x + seed, zz) > 0.45) tree(x, zz, 0.5 + hash(x, zz + seed) * 0.25)
      return
    }
    const style = h(90)
    if (style < 0.28) {
      perimeter(ix0, ix1, iz0, iz1, seed, 8, 13, RES, 0)
      return
    }
    for (const side of [-1, 1]) {
      const zz = side < 0 ? iz0 + 9 : iz1 - 9
      for (let x = ix0 + 8; x <= ix1 - 8; x += 13.5) {
        if (hash(x + seed, side + 5) < 0.2) continue
        houses.push({ x, z: zz, rot: side < 0 ? 0 : Math.PI, s: 0.85 + hash(x, seed) * 0.35 })
      }
    }
    for (let x = ix0 + 6; x <= ix1 - 6; x += 18) for (const zz of [z0 - 3.5, z1 + 3.5]) if (hash(x + seed, zz) > 0.35) tree(x, zz, 0.55 + hash(x, zz + seed) * 0.35)
    if (id > 60) {
      for (let x = ix0 + 6; x <= ix1 - 6; x += 22) {
        if (hash(x + seed, 77) < 0.5) continue
        tree(x, bz, 0.8 + hash(x, seed + 1) * 0.6)
      }
    }
  }

  function perimeter(ix0: number, ix1: number, iz0: number, iz1: number, seed: number, hMin: number, hMax: number, palette: number[], tallChance: number) {
    const iw = ix1 - ix0, id = iz1 - iz0
    const maxDepth = Math.min(18, id / 2 - 2, iw / 2 - 2)
    if (maxDepth < 8) return
    const sides: [number, number, number, number, boolean][] = [
      [ix0, ix1, iz0, 1, true],
      [ix0, ix1, iz1, -1, true],
      [iz0, iz1, ix0, 1, false],
      [iz0, iz1, ix1, -1, false],
    ]
    let n = 0
    for (const [a, b, edge, dir, alongX] of sides) {
      let p = a + (alongX ? 0 : maxDepth)
      const end = b - (alongX ? 0 : maxDepth)
      while (end - p > 8) {
        let lw = 12 + hash(seed + n, 1) * 16
        if (end - p - lw < 9) lw = end - p
        const depth = Math.min(maxDepth, 10 + hash(seed + n, 2) * 8)
        const hh = hash(seed + n, 3) < tallChance ? hMax * 1.5 : hMin + hash(seed + n, 4) * (hMax - hMin)
        const wall = shade(pick(palette, hash(seed + n, 5)), 0.88 + hash(seed + n, 6) * 0.17)
        const cx = alongX ? p + lw / 2 : edge + (dir * depth) / 2
        const cz = alongX ? edge + (dir * depth) / 2 : p + lw / 2
        building(cx, cz, alongX ? lw : depth, hh, alongX ? depth : lw, wall, shade(wall, 0.62))
        if (hh > 14 && hash(seed + n, 7) > 0.5) W.box(cx, hh + 1, cz, 4, 2, 3, 0x6d7076, 0x6d7076, false)
        if (hMax > 14 && hash(seed + n, 8) > 0.35) {
          const fx = alongX ? cx : edge + dir * 0.12, fz = alongX ? edge + dir * 0.12 : cz
          W.box(fx, 1.9, fz, alongX ? lw - 0.6 : 0.28, 3.2, alongX ? 0.28 : lw - 0.6, 0x2d3a4a, 0x2d3a4a, false)
          W.box(fx, 3.75, fz, alongX ? lw - 0.4 : 0.5, 0.35, alongX ? 0.5 : lw - 0.4, pick([0xd8432f, 0x2f6fd8, 0x27a35f, 0xf2a93b, 0x9a3f36], hash(seed + n, 9)), 0x6d7076, false)
        }
        p += lw
        n++
      }
    }
  }

  function tower(cx: number, cz: number, tw: number, th: number, td: number, y0: number, wall: number) {
    W.box(cx, y0 + th / 2, cz, tw, th, td, wall, 0x4f5862, true)
    let top = y0 + th
    if (th > 110) {
      const uh = th * 0.35
      W.box(cx, top + uh / 2, cz, tw * 0.62, uh, td * 0.62, wall, 0x4f5862, true)
      top += uh
    }
    W.box(cx, top + 0.8, cz, tw * 0.35, 1.6, td * 0.35, 0x5f6670, 0x5f6670, false)
    if (th > 170) W.box(cx, top + 12, cz, 1, 24, 1, 0x9aa3ad, 0x9aa3ad, false)
    else if (hash(cx, cz) > 0.65) {
      W.box(cx + tw * 0.26, top + 0.35, cz - td * 0.26, Math.min(tw, td) * 0.4, 0.7, Math.min(tw, td) * 0.4, 0x8a9199, 0x3b4046, false)
      W.box(cx + tw * 0.26, top + 0.75, cz - td * 0.26, Math.min(tw, td) * 0.08, 0.1, Math.min(tw, td) * 0.26, 0xfbf7ec, 0xfbf7ec, false)
    }
    W.box(cx, 2.4, cz + td / 2 + 1.6, Math.min(tw * 0.5, 14), 0.5, 3.2, 0x9aa3ad, 0x9aa3ad, false)
    for (const s of [-1, 1]) W.box(cx + s * Math.min(tw * 0.5, 14) * 0.45, 1.2, cz + td / 2 + 2.9, 0.35, 2.4, 0.35, 0x9aa3ad, 0x9aa3ad, false)
    obstacle(cx, cz, tw, top + (th > 170 ? 24 : 2), td)
  }

  function grandBridge(pos: number, width: number) {
    const [rxw] = toW(pos, 0)
    const zc = RIVER.z(rxw) - wz
    const hw = RIVER.half(rxw)
    const span = hw * 2 + 90
    const H = 16
    const ramp = 210
    const deckW = width + 8
    const light = 0xb9bcc2, steel = 0x9a9da3, red = 0xb8372b
    W.box(pos, H - 1.4, zc, deckW, 2.8, span, steel, ROAD, false)
    W.box(pos, H + 0.06, zc, 0.4, 0.06, span, 0xf2f1e6, 0xf2f1e6, false)
    for (const s of [-1, 1]) {
      W.box(pos + s * (deckW / 2 - 0.4), H + 0.7, zc, 0.4, 1.4, span, light, light, false)
      for (let t = -span / 2 + 12; t < span / 2; t += 24) {
        W.box(pos + s * (deckW / 2 - 1.2), H + 3.2, zc + t, 0.35, 6.4, 0.35, light, light, false)
        W.box(pos + s * (deckW / 2 - 1.8), H + 6.4, zc + t, 1.6, 0.5, 0.5, 0xfff6d5, 0xfff6d5, false)
      }
    }
    const tops = H + 92
    for (const s of [-1, 1]) {
      const zp = zc + s * hw * 0.52
      W.box(pos, -5, zp, deckW + 10, 10, 16, steel, steel, false)
      for (const sx of [-1, 1]) {
        const lx = pos + sx * (deckW / 2 + 1.6)
        W.box(lx, tops / 2 - 5, zp, 3.6, tops + 10, 4.4, red, red, false)
      }
      W.box(pos, H + 30, zp, deckW + 7, 4, 3.6, red, red, false)
      W.box(pos, tops - 3, zp, deckW + 7, 6, 4.4, red, red, false)
      W.box(pos, tops + 6, zp, 0.6, 12, 0.6, light, light, false)
      for (let k = 1; k <= 7; k++) {
        for (const dir of [-1, 1]) {
          const za = zp + dir * k * 15
          if (Math.abs(za - zc) > span / 2 - 6) continue
          const dy = tops - 4 - (H + 1.4), dz = zp - za
          const L = Math.hypot(dy, dz)
          for (const sx of [-1, 1]) W.box(pos + sx * (deckW / 2 - 0.6), H + 1.4 + dy / 2, za + dz / 2, 0.22, 0.22, L, light, light, false, 0, Math.atan2(-dy, dz))
        }
      }
      obstacle(pos, zp, deckW + 14, tops + 10, 8, 0, 'Hit the bridge pylon')
    }
    obstacle(pos, zc, deckW, 5, span, H - 3.5, 'Hit the bridge deck')
    const tilt = Math.atan2(H, ramp)
    const rampLen = Math.hypot(H, ramp)
    for (const s of [-1, 1]) {
      const z0 = zc + s * span / 2
      const zm = z0 + s * ramp / 2
      W.box(pos, H / 2 - 0.9, zm, width + 4, 1.8, rampLen, steel, ROAD, false, 0, -s * tilt)
      for (const sx of [-1, 1]) W.box(pos + sx * (width / 2 + 1.7), H / 2 + 0.6, zm, 0.4, 1.2, rampLen, light, light, false, 0, -s * tilt)
      for (let t = 22; t < ramp; t += 36) {
        const hz = H * (1 - t / ramp)
        W.box(pos - 6, hz / 2 - 1, z0 + s * t, 2.4, hz, 2.4, steel, steel, false)
        W.box(pos + 6, hz / 2 - 1, z0 + s * t, 2.4, hz, 2.4, steel, steel, false)
        W.box(pos, hz - 1.3, z0 + s * t, width + 2, 1.4, 2.6, steel, steel, false)
      }
      for (let k = 0; k < 5; k++) {
        const t0 = (k / 5) * ramp, t1 = ((k + 1) / 5) * ramp
        obstacle(pos, z0 + s * (t0 + t1) / 2, width + 6, 4, t1 - t0, H * (1 - (t0 + t1) / (2 * ramp)) - 2.5, 'Hit the bridge ramp')
      }
    }
    const [bxw, bz0] = toW(pos, zc - span / 2 - ramp), [, bz1] = toW(pos, zc + span / 2 + ramp)
    CITY_MAP.bridge = { x: bxw, z0: bz0, z1: bz1 }
  }

  function church(cx: number, cz: number) {
    const cg = new THREE.Group()
    cg.position.set(cx, 0.2, cz)
    place(site, new THREE.Mesh(new THREE.BoxGeometry(12, 8, 26), M.wall), 0, 4, 0, cg)
    place(site, new THREE.Mesh(prismRoof(12, 26, 8, 5), M.roofDark), 0, 0, 0, cg)
    place(site, new THREE.Mesh(new THREE.BoxGeometry(6.5, 24, 6.5), M.wall), 0, 12, -16, cg)
    place(site, new THREE.Mesh(new THREE.ConeGeometry(4.2, 12, 4), M.roofDark), 0, 30, -16, cg).rotation.y = Math.PI / 4
    place(site, new THREE.Mesh(new THREE.BoxGeometry(0.4, 3, 0.4), M.steel), 0, 37.5, -16, cg)
    place(site, new THREE.Mesh(new THREE.BoxGeometry(2, 0.4, 0.4), M.steel), 0, 37.8, -16, cg)
    for (const s of [-1, 1]) for (let zz = -8; zz <= 10; zz += 6) place(site, new THREE.Mesh(new THREE.BoxGeometry(0.3, 3.5, 1.6), M.darkGlass), s * 6.1, 4.5, zz, cg)
    cg.rotation.y = f.a
    const [x, z] = toW(cx, cz)
    cg.position.set(x, 0.2, z)
    addObstacle(site, cg, 'Hit the church')
  }

  function stadium(cx: number, cz: number, rx: number, rz: number) {
    const shape = new THREE.Shape()
    shape.absellipse(0, 0, rx, rz, 0, Math.PI * 2, false, 0)
    const hole = new THREE.Path()
    hole.absellipse(0, 0, rx * 0.68, rz * 0.6, 0, Math.PI * 2, true, 0)
    shape.holes.push(hole)
    const geo = new THREE.ExtrudeGeometry(shape, { depth: 16, bevelEnabled: false, curveSegments: 40 })
    geo.rotateX(-Math.PI / 2)
    place(site, new THREE.Mesh(geo, M.concrete), cx, 0.2, cz, g)
    const seats = new THREE.Shape()
    seats.absellipse(0, 0, rx * 0.72, rz * 0.65, 0, Math.PI * 2, false, 0)
    const seatHole = new THREE.Path()
    seatHole.absellipse(0, 0, rx * 0.62, rz * 0.54, 0, Math.PI * 2, true, 0)
    seats.holes.push(seatHole)
    const seatGeo = new THREE.ExtrudeGeometry(seats, { depth: 6, bevelEnabled: false, curveSegments: 40 })
    seatGeo.rotateX(-Math.PI / 2)
    place(site, new THREE.Mesh(seatGeo, lambert(0xc84b3c)), cx, 0.2, cz, g)
    const pitch = new THREE.Shape()
    pitch.absellipse(0, 0, rx * 0.6, rz * 0.52, 0, Math.PI * 2, false, 0)
    const pitchGeo = new THREE.ShapeGeometry(pitch, 40)
    pitchGeo.rotateX(-Math.PI / 2)
    place(site, new THREE.Mesh(pitchGeo, lambert(0x3f9a3a)), cx, 0.35, cz, g)
    for (const [sx, sz] of [[-0.85, -0.8], [0.85, -0.8], [-0.85, 0.8], [0.85, 0.8]]) {
      const [x, z] = toW(cx + sx * rx, cz + sz * rz)
      buildMast(site, x, z)
    }
    obstacle(cx, cz, rx * 2, 18, rz * 2, 0, 'Hit the stadium')
  }

  const mesh = new THREE.Mesh(W.geometry(), CITY_MAT)
  mesh.castShadow = true
  mesh.receiveShadow = true
  g.add(mesh)
  houseCluster(site, f, g, c.x, c.z, houses)

  const busSpots = carSpots.filter(s => s.bus), autoSpots = carSpots.filter(s => !s.bus)
  const m = new THREE.Matrix4()
  const cq = new THREE.Quaternion()
  const col = new THREE.Color()
  const cars = new THREE.InstancedMesh(CAR_GEOMETRY, VEHICLE_MAT, autoSpots.length)
  autoSpots.forEach((s, i) => {
    cq.setFromAxisAngle(up, s.rot)
    const k = 0.9 + hash(i, 56) * 0.25
    m.compose(new THREE.Vector3(s.x, 0.12, s.z), cq, new THREE.Vector3(k, k, k))
    cars.setMatrixAt(i, m)
    cars.setColorAt(i, col.setHex(pick(CARS, hash(i, 55))))
  })
  cars.castShadow = true
  g.add(cars)
  if (busSpots.length) {
    const buses = new THREE.InstancedMesh(BUS_GEOMETRY, VEHICLE_MAT, busSpots.length)
    busSpots.forEach((s, i) => {
      cq.setFromAxisAngle(up, s.rot)
      m.compose(new THREE.Vector3(s.x, 0.12, s.z), cq, new THREE.Vector3(1, 1, 1))
      buses.setMatrixAt(i, m)
      buses.setColorAt(i, col.setHex(hash(i, 57) > 0.5 ? 0xf2c94c : 0x2f6fd8))
    })
    buses.castShadow = true
    g.add(buses)
  }
  site.scene.add(g)

  if (town) return
  const river = new THREE.Shape()
  const topEdge: [number, number][] = []
  const bottomEdge: [number, number][] = []
  for (let x = RIVER.x0; x <= RIVER.x1; x += 20) {
    topEdge.push([x, RIVER.z(x) - RIVER.half(x) - 6])
    bottomEdge.push([x, RIVER.z(x) + RIVER.half(x) + 6])
  }
  river.moveTo(topEdge[0][0], -topEdge[0][1])
  for (const [x, z] of topEdge) river.lineTo(x, -z)
  for (const [x, z] of bottomEdge.reverse()) river.lineTo(x, -z)
  river.closePath()
  const riverGeo = new THREE.ShapeGeometry(river)
  riverGeo.rotateX(-Math.PI / 2)
  const water = new THREE.Mesh(riverGeo, WATER_MAT)
  water.position.y = WATER_LEVEL - 0.12
  water.receiveShadow = true
  site.scene.add(water)
}

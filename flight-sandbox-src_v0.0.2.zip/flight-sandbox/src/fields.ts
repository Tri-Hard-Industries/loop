import { hash } from './noise'
export const PAVEMENT_TOP = 0.2
export const HOME_START = { x: -380, z: 700 }
export type Start = { name: string; x: number; z: number; yaw: number; water: boolean }

export type Pave = { x: number; z: number; w: number; d: number; a: number; y: number }
export type Pier = { z: number; length: number; gate: number }
export type Terminal = { x: number; z: number; width: number; length: number; piers: Pier[] }
export type Settlement = { x: number; z: number; w: number; d: number; kind: 'city' | 'town'; resort?: boolean }

export function streets(length: number, seed: number) {
  const out = [-length / 2]
  let p = -length / 2
  let i = 0
  while (p < length / 2 - 60) {
    p += [70, 80, 95, 110, 125][Math.floor(hash(i++, seed) * 5)]
    out.push(Math.min(p, length / 2))
  }
  if (length / 2 - out[out.length - 1] > 1) out.push(length / 2)
  return out
}

export const BOULEVARDS = [0.36, 0.64]
export const COAST = (x: number) => 44000 + 900 * Math.sin(x / 2500) + 500 * Math.sin(x / 900 + 2)
export const ISLE = { x: 2500, z: 49500, rx: 3400, rz: 2100 }
export type Field = {
  name: string
  x: number
  z: number
  a: number
  flat: number
  runways: Pave[]
  taxiways: Pave[]
  aprons: Pave[]
  roads: Pave[]
  carparks: Pave[]
  hangars: [number, number, number, number][]
  towers: [number, number, number][]
  fuel: [number, number][]
  masts: [number, number][]
  windsock: [number, number]
  terminal: Terminal | null
  settlements: Settlement[]
  lakes: [number, number, number][]
  houses: [number, number, number, number][]
  islands: [number, number, number, number][]
  lighthouses: [number, number][]
  piers: [number, number, number, number][]
  turbines: [number, number][]
  farms: Pave[]
}

export function seg(x1: number, z1: number, x2: number, z2: number, w: number, y = 0.03): Pave {
  return { x: (x1 + x2) / 2, z: (z1 + z2) / 2, w, d: Math.hypot(x2 - x1, z2 - z1), a: Math.atan2(x2 - x1, z2 - z1), y }
}

export function rect(x: number, z: number, w: number, d: number, y = 0.03): Pave {
  return { x, z, w, d, a: 0, y }
}

const T = 18
const LAKE_R = 220

export function lakeRadius(r: number, theta: number) {
  return r * (1 + 0.22 * Math.sin(2 * theta + 1) + 0.14 * Math.sin(3 * theta + 2.3) + 0.08 * Math.sin(5 * theta))
}

const LAKE_HOUSE_X = Math.round(-700 + lakeRadius(LAKE_R, -0.35) * 0.81 + 28)

export const FIELDS: Field[] = [
  {
    name: "Tristan's Field",
    x: 0,
    z: 0,
    a: 0,
    flat: 950,
    runways: [seg(-380, 750, -380, -750, 45, 0.05), seg(380, 750, 380, -750, 45, 0.05)],
    taxiways: [
      seg(-300, -780, -300, 780, T),
      seg(300, -780, 300, 780, T),
      ...[-745, -450, 0, 450, 745].flatMap(z => [seg(-368, z, -300, z, T), seg(300, z, 368, z, T)]),
      seg(-372, 160, -300, 30, T),
      seg(-372, -160, -300, -30, T),
      seg(372, 160, 300, 30, T),
      seg(372, -160, 300, -30, T),
      seg(-300, -300, 300, -300, T),
      seg(-300, 300, 300, 300, T),
      ...[-150, 0, 150].flatMap(z => [seg(-300, z, -270, z, T), seg(270, z, 300, z, T)]),
      seg(0, 300, 0, 480, T),
      seg(395, -200, 460, -200, T),
    ],
    aprons: [rect(0, 0, 560, 480), rect(0, 560, 280, 160), rect(520, -200, 120, 160), rect(-330, 660, 40, 80), rect(330, 660, 40, 80), rect(-330, -660, 40, 80), rect(330, -660, 40, 80)],
    roads: [seg(-140, -380, -272, -380, 12, 0.02), seg(-408, -380, -828, -380, 12, 0.02)],
    carparks: [rect(-60, -380, 160, 100, 0.02)],
    hangars: [[-60, 680, 0, 2], [40, 680, 0, 2], [590, -250, Math.PI / 2, 1], [590, -200, Math.PI / 2, 1], [590, -150, Math.PI / 2, 1]],
    towers: [[-250, 60, 48]],
    fuel: [[-560, -650]],
    masts: [[-270, -230], [270, -230], [-270, 230], [270, 230]],
    windsock: [-450, -830],
    terminal: { x: 0, z: 0, width: 70, length: 360, piers: [{ z: -170, length: 380, gate: 44 }, { z: 170, length: 380, gate: 44 }] },
    settlements: [{ x: -2100, z: 0, w: 2600, d: 2000, kind: 'city' }],
    lakes: [[-3500, 40, 300], [-760, 180, 110]],
    houses: [],
    islands: [],
    lighthouses: [],
    piers: [],
    turbines: [],
    farms: [],
  },
  {
    name: 'North Field',
    x: -6800,
    z: -7200,
    a: 0.35,
    flat: 700,
    runways: [seg(0, 360, 0, -360, 30, 0.05)],
    taxiways: [seg(45, -340, 45, 340, 14), seg(12, -330, 45, -330, 14), seg(12, 0, 45, 0, 14), seg(12, 330, 45, 330, 14), seg(45, 60, 85, 60, 14)],
    aprons: [rect(115, 60, 70, 90)],
    roads: [seg(150, 60, 190, 60, 8, 0.02), seg(190, 60, 190, -450, 8, 0.02), seg(190, -450, LAKE_HOUSE_X + 24, -450, 8, 0.02), seg(LAKE_HOUSE_X + 24, -450, LAKE_HOUSE_X + 24, -292, 8, 0.02)],
    carparks: [],
    hangars: [[160, 60, Math.PI / 2, 1]],
    towers: [[110, -10, 18]],
    fuel: [],
    masts: [],
    windsock: [-60, 300],
    terminal: null,
    settlements: [],
    lakes: [[-700, -250, LAKE_R]],
    houses: [[LAKE_HOUSE_X, -250, -Math.PI / 2, 38]],
    islands: [],
    lighthouses: [],
    piers: [],
    turbines: [],
    farms: [],
  },
  {
    name: 'Crosswind Cove',
    x: 5600,
    z: -5400,
    a: 0,
    flat: 650,
    runways: [seg(0, 350, 0, -350, 30, 0.05)],
    taxiways: [seg(45, -330, 45, 330, 14), seg(12, -320, 45, -320, 14), seg(12, 0, 45, 0, 14), seg(12, 320, 45, 320, 14), seg(45, 60, 85, 60, 14)],
    aprons: [rect(110, 60, 60, 80)],
    roads: [seg(-340, 200, -340, 420, 8, 0.02), seg(-340, 420, 130, 420, 8, 0.02), seg(130, 420, 130, 100, 8, 0.02)],
    carparks: [],
    hangars: [[150, 60, Math.PI / 2, 1]],
    towers: [],
    fuel: [],
    masts: [],
    windsock: [-40, 300],
    terminal: null,
    settlements: [{ x: -650, z: 150, w: 620, d: 460, kind: 'town' }],
    lakes: [[-600, -650, 320]],
    houses: [],
    islands: [[-480, -710, 52, 14]],
    lighthouses: [[-480, -710]],
    piers: [[-640, -372, 0, 50]],
    turbines: [[750, -100], [900, -350], [1050, -600], [1200, 100], [1000, 400], [800, 650], [1250, -250]],
    farms: [rect(-200, 700, 2000, 380), rect(400, 100, 500, 800), rect(-1500, 250, 600, 700)],
  },
  {
    name: 'Longhaul Key',
    x: 2500,
    z: 49500,
    a: 0,
    flat: 1000,
    runways: [seg(0, 900, 0, -900, 45, 0.05)],
    taxiways: [seg(80, -880, 80, 880, 18), seg(25, -870, 80, -870, 18), seg(25, -300, 80, -300, 18), seg(25, 300, 80, 300, 18), seg(25, 870, 80, 870, 18), seg(80, -120, 120, -120, 18), seg(80, 120, 120, 120, 18)],
    aprons: [rect(250, 0, 260, 400)],
    roads: [seg(440, 40, 440, 600, 10, 0.02), seg(440, 600, 700, 600, 10, 0.02), seg(-5100, -7250, -5100, COAST(-2600) - 49500, 8, 0.02)],
    carparks: [rect(440, 0, 100, 80, 0.02)],
    hangars: [[250, 260, 0, 1]],
    towers: [[180, 210, 30]],
    fuel: [[330, 250]],
    masts: [[130, -190], [370, -190], [130, 190], [370, 190]],
    windsock: [-50, 950],
    terminal: { x: 260, z: 0, width: 40, length: 160, piers: [{ z: -125, length: 150, gate: 44 }] },
    settlements: [{ x: 1000, z: 950, w: 900, d: 600, kind: 'town', resort: true }, { x: -5100, z: -7500, w: 700, d: 500, kind: 'town' }],
    lakes: [[-6500, -24500, 1400]],
    houses: [],
    islands: [],
    lighthouses: [[-2900, 0]],
    piers: [[1000, 1760, Math.PI, 60], [-5100, COAST(-2600) - 49500 - 12, Math.PI, 90]],
    turbines: [],
    farms: [rect(-3500, -7900, 6000, 1300), rect(-7600, -7400, 3000, 1100), rect(1200, -1200, 1600, 700)],
  },
]

const CITY = FIELDS[0].settlements[0]
const CITY_XS = streets(CITY.w, 11)
export const BAY_X = FIELDS[0].x + CITY.x + CITY_XS[Math.round(CITY_XS.length * BOULEVARDS[1])]
export const RIVER = {
  x0: -3500,
  x1: -760,
  z: (x: number) => 120 * Math.sin((x + 2100) / 650) + 60,
  half: (x: number) => 50 + 140 * Math.exp(-(((x - BAY_X) / 260) ** 4)),
}

export function toWorld(f: Field, p: Pave): Pave {
  const c = Math.cos(f.a), s = Math.sin(f.a)
  return { x: f.x + p.x * c + p.z * s, z: f.z - p.x * s + p.z * c, w: p.w, d: p.d, a: p.a + f.a, y: p.y }
}

export function pointToWorld(f: Field, x: number, z: number): [number, number] {
  const c = Math.cos(f.a), s = Math.sin(f.a)
  return [f.x + x * c + z * s, f.z - x * s + z * c]
}

export function insidePave(r: Pave, x: number, z: number, margin: number) {
  const dx = x - r.x, dz = z - r.z
  const c = Math.cos(r.a), s = Math.sin(r.a)
  const lx = dx * c - dz * s
  const lz = dx * s + dz * c
  return Math.abs(lx) <= r.w / 2 + margin && Math.abs(lz) <= r.d / 2 + margin
}

export const PAVEMENT: Pave[] = FIELDS.flatMap(f => [...f.runways, ...f.taxiways, ...f.aprons].map(p => toWorld(f, p)))
export const ROADS: Pave[] = FIELDS.flatMap(f => [...f.roads, ...f.carparks].map(p => toWorld(f, p)))
export const TOWNS: Pave[] = FIELDS.flatMap(f => f.settlements.map(t => toWorld(f, rect(t.x, t.z, t.w, t.d))))
export const LAKES: [number, number, number][] = FIELDS.flatMap(f => f.lakes.map(([x, z, r]) => [...pointToWorld(f, x, z), r] as [number, number, number]))
export const ISLANDS: [number, number, number, number][] = FIELDS.flatMap(f => f.islands.map(([x, z, r, h]) => [...pointToWorld(f, x, z), r, h] as [number, number, number, number]))
export const TREE_CLUSTERS: { x: number; z: number; r: number; n: number }[] = [
  ...FIELDS.flatMap(f => f.houses.map(([x, z]) => { const [wx, wz] = pointToWorld(f, x, z); return { x: wx, z: wz, r: 170, n: 140 } })),
  ...FIELDS.filter(f => f.name === 'Crosswind Cove').flatMap(f => [{ x: f.x - 600, z: f.z - 650, r: 800, n: 900 }, { x: f.x + 300, z: f.z - 900, r: 500, n: 350 }]),
  ...FIELDS.filter(f => f.name === 'Longhaul Key').flatMap(f => [{ x: f.x + 1000, z: f.z + 1000, r: 900, n: 650 }, { x: f.x - 1400, z: f.z - 300, r: 1100, n: 500 }, { x: f.x - 5100, z: f.z - 7500, r: 700, n: 260 }]),
]
export const STARTS: Start[] = [
  ...FIELDS.map(f => {
    const r = f.runways[0]
    const [x, z] = pointToWorld(f, r.x - Math.sin(r.a) * (r.d / 2 - 50), r.z - Math.cos(r.a) * (r.d / 2 - 50))
    return { name: f.name, x, z, yaw: r.a + f.a + Math.PI, water: false }
  }),
  { name: 'City bay', x: BAY_X - 30, z: RIVER.z(BAY_X - 30), yaw: Math.PI / 2, water: true },
  { name: 'Crosswind Cove lake', x: LAKES[3][0] - 60, z: LAKES[3][1] + 40, yaw: Math.PI / 2, water: true },
  { name: 'North Field lake', x: LAKES[2][0], z: LAKES[2][1] + 60, yaw: 0, water: true },
  { name: 'Longhaul Key strait', x: 2500, z: 46000, yaw: -Math.PI / 2, water: true },
]
export const FLAT_SPOTS: { x: number; z: number; r0: number; r1: number }[] = [
  ...FIELDS.map(f => ({ x: f.x, z: f.z, r0: f.flat, r1: f.flat + 600 })),
  ...TOWNS.map(t => ({ x: t.x, z: t.z, r0: Math.hypot(t.w, t.d) / 2 + 40, r1: Math.hypot(t.w, t.d) / 2 + 340 })),
  ...LAKES.map(([x, z, r]) => ({ x, z, r0: r * 1.4 + 100, r1: r * 1.4 + 500 })),
]

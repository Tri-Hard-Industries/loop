import type { Plane } from './plane'
import { FIELDS } from './fields'
import { nav } from './nav'

const el = (id: string) => document.getElementById(id) as HTMLElement

export class Hud {
  private speed = el('speed')
  private alt = el('alt')
  private vs = el('vs')
  private hdg = el('hdg')
  private thr = el('thr')
  private fieldName = el('fieldname')
  private fieldDist = el('fielddist')
  private fieldHdg = el('fieldhdg')
  private banner = el('banner')
  private sub = el('sub')

  update(p: Plane) {
    this.speed.textContent = Math.round(p.speed * 3.6).toString()
    this.alt.textContent = Math.round(p.altitude).toString()
    const climb = p.velocity.y
    this.vs.textContent = (climb > 0.05 ? '+' : '') + climb.toFixed(1)
    this.hdg.textContent = Math.round((((-p.yaw * 180) / Math.PI) % 360 + 360) % 360).toString()
    this.thr.style.width = `${Math.round(p.throttle * 100)}%`

    let idx = nav.target ?? 0, bestD = Infinity
    if (nav.target === null) {
      FIELDS.forEach((f, i) => {
        const d = Math.hypot(f.x - p.pos.x, f.z - p.pos.z)
        if (d > 600 && d < bestD) { idx = i; bestD = d }
      })
    }
    const best = FIELDS[idx]
    bestD = Math.hypot(best.x - p.pos.x, best.z - p.pos.z)
    const hdg = Math.round((Math.atan2(best.x - p.pos.x, -(best.z - p.pos.z)) * 180 / Math.PI + 360) % 360)
    this.fieldName.textContent = best.name
    this.fieldDist.textContent = (bestD / 1000).toFixed(1)
    this.fieldHdg.textContent = `km, heading ${hdg}`

    let banner = '', cls = '', sub = ''
    if (p.crashed) {
      banner = 'Crashed'
      cls = 'bad'
      sub = `${p.crashReason}. Press R to restart.`
    } else if (p.landed && p.speed < 2) {
      banner = p.surface === 'water' ? 'Landed on the water' : 'Landed'
      cls = 'good'
      sub = 'Hold Shift to fly again, or press R to reset.'
    } else if (p.landed) {
      sub = p.surface === 'water' ? 'Down on the water. Space slows you.' : 'Touchdown. Hold Space to brake.'
    } else if (p.stalled) {
      banner = 'Stall'
      cls = 'warn'
      sub = 'Ease off the stick, nose down, opposite rudder if spinning.'
    } else if (!p.engineOn) {
      banner = p.starting > 0 ? 'Starting' : 'Engine off'
      cls = 'warn'
      sub = p.starting > 0 ? 'Cranking...' : 'Press I to start the engine. Keep the nose down to keep flying speed.'
    } else if (p.onGround && p.speed < 2) {
      sub = `Click the scene, hold Shift for full throttle, then pull S gently above ${Math.round(p.spec.rotate * 3.6)} km/h to lift off${p.surface === 'water' ? ' the water' : ''}. M opens the map, Esc the menu.`
    }
    if (this.banner.textContent !== banner) this.banner.textContent = banner
    if (this.banner.className !== cls) this.banner.className = cls
    if (this.sub.textContent !== sub) this.sub.textContent = sub
  }
}

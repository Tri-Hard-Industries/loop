export class Input {
  dragging = false
  private keys = new Set<string>()
  private restart = false
  private map = false
  private night = false
  private menu = false
  private mute = false
  private ignition = false
  private dx = 0
  private dy = 0
  private wheel = 0

  constructor(el: HTMLElement) {
    addEventListener('keydown', e => {
      if (e.code === 'Space' || e.code.startsWith('Arrow') || (e.ctrlKey && /^Key[WASD]$/.test(e.code))) e.preventDefault()
      this.keys.add(e.code)
      if (e.code === 'KeyR' && !e.repeat) this.restart = true
      if (e.code === 'KeyM' && !e.repeat) this.map = true
      if (e.code === 'KeyN' && !e.repeat) this.night = true
      if (e.code === 'Escape' && !e.repeat) this.menu = true
      if (e.code === 'KeyV' && !e.repeat) this.mute = true
      if (e.code === 'KeyI' && !e.repeat) this.ignition = true
      if (e.code === 'KeyF' && !e.repeat) this.toggleFullscreen()
    })
    addEventListener('keyup', e => this.keys.delete(e.code))
    addEventListener('blur', () => this.keys.clear())
    el.addEventListener('pointerdown', e => {
      this.dragging = true
      el.setPointerCapture(e.pointerId)
    })
    el.addEventListener('pointerup', () => (this.dragging = false))
    el.addEventListener('pointercancel', () => (this.dragging = false))
    el.addEventListener('pointermove', e => {
      if (!this.dragging) return
      this.dx += e.movementX
      this.dy += e.movementY
    })
    el.addEventListener('wheel', e => {
      e.preventDefault()
      this.wheel += e.deltaMode === 1 ? e.deltaY * 30 : e.deltaY
    }, { passive: false })
    el.addEventListener('contextmenu', e => e.preventDefault())
  }

  private toggleFullscreen() {
    if (document.fullscreenElement) {
      document.exitFullscreen()
      return
    }
    document.documentElement.requestFullscreen().then(() => {
      const kb = (navigator as { keyboard?: { lock(keys: string[]): Promise<void> } }).keyboard
      kb?.lock(['KeyW', 'KeyS', 'KeyA', 'KeyD']).catch(() => {})
    }).catch(() => {})
  }

  down(...codes: string[]) {
    return codes.some(c => this.keys.has(c))
  }

  axis(neg: string[], pos: string[]) {
    return (this.down(...pos) ? 1 : 0) - (this.down(...neg) ? 1 : 0)
  }

  takeRestart() {
    const r = this.restart
    this.restart = false
    return r
  }

  takeIgnition() {
    const i = this.ignition
    this.ignition = false
    return i
  }

  takeMute() {
    const m = this.mute
    this.mute = false
    return m
  }

  takeMenu() {
    const m = this.menu
    this.menu = false
    return m
  }

  takeNight() {
    const n = this.night
    this.night = false
    return n
  }

  takeMap() {
    const m = this.map
    this.map = false
    return m
  }

  takeMouse() {
    const m = { dx: this.dx, dy: this.dy, wheel: this.wheel }
    this.dx = this.dy = this.wheel = 0
    return m
  }
}

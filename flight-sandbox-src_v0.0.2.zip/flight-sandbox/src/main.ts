import * as THREE from 'three'
import './style.css'
import { Input } from './input'
import { World } from './world'
import { Plane } from './plane'
import { ChaseCamera } from './camera'
import { Debris } from './debris'
import { Hud } from './hud'
import { MapView } from './map'
import { Menu } from './menu'
import { Sound } from './sound'
import { STARTS } from './fields'
import { PLANES } from './plane'

const canvas = document.getElementById('c') as HTMLCanvasElement
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, logarithmicDepthBuffer: true })
renderer.setPixelRatio(Math.min(devicePixelRatio, 2))
renderer.setSize(innerWidth, innerHeight)
renderer.shadowMap.enabled = true
renderer.shadowMap.type = THREE.PCFSoftShadowMap

const world = new World()
const plane = new Plane(world, STARTS[0])
world.scene.add(plane.mesh)
const debris = new Debris(world.scene)
const cam = new ChaseCamera(world, plane)
const input = new Input(canvas)
const hud = new Hud()
const map = new MapView(plane)
const sound = new Sound()
const menu = new Menu(v => sound.setVolume(v), (kind, start) => {
  plane.setKind(kind)
  plane.reset(start)
  debris.clear()
  cam.fit(PLANES[kind].cam)
  cam.reset()
  canvas.focus()
})

addEventListener('resize', () => {
  renderer.setSize(innerWidth, innerHeight)
  cam.camera.aspect = innerWidth / innerHeight
  cam.camera.updateProjectionMatrix()
})

const clock = new THREE.Clock()

function frame() {
  const dt = Math.min(clock.getDelta(), 0.05)
  if (input.takeRestart() && !menu.open) {
    plane.reset()
    debris.clear()
    cam.reset()
  }
  if (input.takeMenu()) menu.open ? menu.resume() : menu.show()
  if (input.takeMute()) menu.setMuted(sound.toggleMute())
  if (input.takeMap()) map.toggle()
  if (input.takeNight()) world.setNight(!world.night)
  const wasCrashed = plane.crashed
  const wasAirborne = !plane.onGround
  if (input.takeIgnition() && !menu.open) plane.toggleEngine()
  if (!menu.open) plane.update(dt, input)
  if (plane.crashed && !wasCrashed) {
    const water = plane.crashReason.includes('water')
    debris.spawn(plane.pos, plane.velocity, water)
    sound.crash(water)
  } else if (wasAirborne && plane.onGround && !plane.crashed) {
    sound.touchdown(-plane.lastTouchdown, plane.surface === 'water')
  }
  sound.update(dt, plane, menu.open)
  debris.update(dt, world)
  world.update(dt, plane.pos)
  cam.update(dt, input)
  hud.update(plane)
  map.draw()
  renderer.render(world.scene, cam.camera)
  requestAnimationFrame(frame)
}

frame()

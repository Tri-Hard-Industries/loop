import { FIELDS, LAKES, PAVEMENT, RIVER, ROADS, lakeRadius, type Pave } from './fields'
import { CITY_MAP, type Kind } from './city'
import { WORLD, seaFactor, terrainHeight, terrainColor } from './terrain'
import { Color } from 'three'
import { nav } from './nav'
import type { Plane } from './plane'

const SIZE = 900
const K = SIZE / (WORLD.maxZ - WORLD.minZ)
const WIDTH = Math.round((WORLD.maxX - WORLD.minX) * K)

export class MapView {
  visible = false
  private panel = document.getElementById('map') as HTMLElement
  private canvas = document.getElementById('mapcanvas') as HTMLCanvasElement
  private ctx = this.canvas.getContext('2d')!
  private terrain = document.createElement('canvas')

  constructor(private plane: Plane) {
    this.canvas.width = WIDTH
    this.canvas.height = SIZE
    this.renderTerrain()
    this.canvas.addEventListener('pointerdown', e => this.pick(e))
  }

  toggle() {
    this.visible = !this.visible
    this.panel.hidden = !this.visible
  }

  draw() {
    if (!this.visible) return
    const c = this.ctx
    c.drawImage(this.terrain, 0, 0, WIDTH, SIZE)
    c.fillStyle = '#3d8fd8'
    for (const [lx, lz, r] of LAKES) {
      c.beginPath()
      for (let i = 0; i <= 48; i++) {
        const t = (i / 48) * Math.PI * 2
        const rad = lakeRadius(r, t) * 0.81 * K
        c.lineTo(this.px(lx) + Math.cos(t) * rad, this.pz(lz) + Math.sin(t) * rad)
      }
      c.fill()
    }
    const zoneColor: Record<Kind, string> = { water: '', cbd: '#5b6270', tall: '#6f7683', mid: '#8b8d93', res: '#aaa59b', ind: '#8d86a0', park: '#5f9c48', stadium: '#c9c9c6', square: '#d9cfb6' }
    for (const b of CITY_MAP.blocks) {
      if (b.kind === 'water') continue
      c.fillStyle = zoneColor[b.kind]
      c.fillRect(this.px(b.x0), this.pz(b.z0), (b.x1 - b.x0) * K, (b.z1 - b.z0) * K)
      if (b.kind === 'stadium') {
        c.fillStyle = '#4f9a3c'
        c.beginPath()
        c.ellipse(this.px((b.x0 + b.x1) / 2), this.pz((b.z0 + b.z1) / 2), ((b.x1 - b.x0) / 2 - 12) * K, ((b.z1 - b.z0) / 2 - 12) * K, 0, 0, Math.PI * 2)
        c.fill()
      }
    }
    c.fillStyle = '#3d8fd8'
    c.beginPath()
    for (let x = RIVER.x0; x <= RIVER.x1; x += 20) c.lineTo(this.px(x), this.pz(RIVER.z(x) - RIVER.half(x)))
    for (let x = RIVER.x1; x >= RIVER.x0; x -= 20) c.lineTo(this.px(x), this.pz(RIVER.z(x) + RIVER.half(x)))
    c.closePath()
    c.fill()
    c.lineCap = 'butt'
    for (const s of CITY_MAP.streets) {
      c.strokeStyle = s.w >= 24 ? '#2c2e33' : s.w >= 14 ? '#3b3e45' : '#55585f'
      c.lineWidth = Math.max(s.w * K, s.w >= 14 ? 1.4 : 0.7)
      c.beginPath()
      c.moveTo(this.px(s.x0), this.pz(s.z0))
      c.lineTo(this.px(s.x1), this.pz(s.z1))
      c.stroke()
    }
    if (CITY_MAP.bridge) {
      c.strokeStyle = '#e8564a'
      c.lineWidth = 3
      c.beginPath()
      c.moveTo(this.px(CITY_MAP.bridge.x), this.pz(CITY_MAP.bridge.z0))
      c.lineTo(this.px(CITY_MAP.bridge.x), this.pz(CITY_MAP.bridge.z1))
      c.stroke()
    }
    c.fillStyle = '#3d3f47'
    for (const r of ROADS) this.rect(r, 1)
    c.fillStyle = '#e8e6df'
    for (const p of PAVEMENT) this.rect(p, 1.5)

    const p = this.plane.pos
    const target = nav.target === null ? this.nearestOther() : nav.target
    const tf = FIELDS[target]
    c.strokeStyle = '#ffb347'
    c.lineWidth = 2
    c.setLineDash([8, 6])
    c.beginPath()
    c.moveTo(this.px(p.x), this.pz(p.z))
    c.lineTo(this.px(tf.x), this.pz(tf.z))
    c.stroke()
    c.setLineDash([])

    c.font = '600 15px "Avenir Next", "Segoe UI", "Trebuchet MS", sans-serif'
    c.textAlign = 'center'
    FIELDS.forEach((f, i) => {
      const x = this.px(f.x), y = this.pz(f.z)
      if (i === target) {
        c.strokeStyle = '#ffb347'
        c.lineWidth = 3
        c.beginPath()
        c.arc(x, y, f.flat * K, 0, Math.PI * 2)
        c.stroke()
      }
      const label = i === target ? `${f.name}  ${(Math.hypot(f.x - p.x, f.z - p.z) / 1000).toFixed(1)} km` : f.name
      c.lineWidth = 4
      c.strokeStyle = 'rgba(10, 16, 28, 0.85)'
      c.strokeText(label, x, y - f.flat * K - 8)
      c.fillStyle = i === target ? '#ffb347' : '#fbf7ec'
      c.fillText(label, x, y - f.flat * K - 8)
    })

    const a = Math.atan2(-Math.cos(this.plane.yaw), -Math.sin(this.plane.yaw))
    c.save()
    c.translate(this.px(p.x), this.pz(p.z))
    c.rotate(a)
    c.fillStyle = '#ff5f52'
    c.strokeStyle = '#fbf7ec'
    c.lineWidth = 2
    c.beginPath()
    c.moveTo(14, 0)
    c.lineTo(-10, 9)
    c.lineTo(-6, 0)
    c.lineTo(-10, -9)
    c.closePath()
    c.fill()
    c.stroke()
    c.restore()
  }

  private nearestOther() {
    const p = this.plane.pos
    let best = 0, bestD = Infinity
    FIELDS.forEach((f, i) => {
      const d = Math.hypot(f.x - p.x, f.z - p.z)
      if (d > 600 && d < bestD) {
        best = i
        bestD = d
      }
    })
    return best
  }

  private px(v: number) {
    return (v - WORLD.minX) * K
  }

  private pz(v: number) {
    return (v - WORLD.minZ) * K
  }

  private rect(r: Pave, minWidth: number) {
    const c = this.ctx
    c.save()
    c.translate(this.px(r.x), this.pz(r.z))
    c.rotate(Math.PI / 2 - r.a)
    const w = Math.max(r.w * K, minWidth)
    c.fillRect(-r.d * K / 2, -w / 2, r.d * K, w)
    c.restore()
  }

  private pick(e: PointerEvent) {
    const b = this.canvas.getBoundingClientRect()
    const x = WORLD.minX + ((e.clientX - b.left) / b.width) * (WORLD.maxX - WORLD.minX)
    const z = WORLD.minZ + ((e.clientY - b.top) / b.height) * (WORLD.maxZ - WORLD.minZ)
    let best = -1, bestD = 1200
    FIELDS.forEach((f, i) => {
      const d = Math.hypot(f.x - x, f.z - z)
      if (d < bestD) {
        best = i
        bestD = d
      }
    })
    if (best >= 0) nav.target = best
  }

  private renderTerrain() {
    const nz = 400, nx = Math.round((nz * (WORLD.maxX - WORLD.minX)) / (WORLD.maxZ - WORLD.minZ))
    this.terrain.width = nx
    this.terrain.height = nz
    const tc = this.terrain.getContext('2d')!
    const img = tc.createImageData(nx, nz)
    const col = new Color()
    for (let j = 0; j < nz; j++) {
      for (let i = 0; i < nx; i++) {
        const x = WORLD.minX + ((i + 0.5) / nx) * (WORLD.maxX - WORLD.minX)
        const z = WORLD.minZ + ((j + 0.5) / nz) * (WORLD.maxZ - WORLD.minZ)
        const h = terrainHeight(x, z)
        const dh = terrainHeight(x + 40, z) - h
        const ny = 1 / Math.hypot(1, dh / 40)
        if (h < -1.5) col.setHex(0x3d8fd8)
        else terrainColor(col, h, ny, 0.3, seaFactor(x, z))
        const shade = h < -1.5 ? 1 : 1 - Math.max(-0.2, Math.min(0.2, dh / 120))
        const k = (j * nx + i) * 4
        img.data[k] = col.r * 255 * shade
        img.data[k + 1] = col.g * 255 * shade
        img.data[k + 2] = col.b * 255 * shade
        img.data[k + 3] = 255
      }
    }
    tc.putImageData(img, 0, 0)
  }
}

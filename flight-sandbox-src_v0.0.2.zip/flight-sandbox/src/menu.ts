import { STARTS, type Start } from './fields'
import { PLANES, type PlaneKind } from './plane'

export class Menu {
  open = true
  kind: PlaneKind = 'wheels'
  start: Start = STARTS[0]
  private panel = document.getElementById('menu') as HTMLElement
  private planes = document.getElementById('planes') as HTMLElement
  private starts = document.getElementById('starts') as HTMLElement

  constructor(onVolume: (v: number) => void, private onFly: (kind: PlaneKind, start: Start) => void) {
    const slider = document.getElementById('volume') as HTMLInputElement
    slider.addEventListener('input', () => onVolume(Number(slider.value) / 100))
    for (const kind of Object.keys(PLANES) as PlaneKind[]) {
      const p = PLANES[kind]
      const b = document.createElement('button')
      b.className = 'choice'
      b.innerHTML = `<span class="swatch" style="background:${p.color}"></span><span><b>${p.name}</b><small>${p.blurb}</small></span>`
      b.addEventListener('click', () => {
        this.kind = kind
        if (this.start.water && kind !== 'floats') this.start = STARTS[0]
        this.render()
      })
      this.planes.append(b)
    }
    for (const s of STARTS) {
      const b = document.createElement('button')
      b.className = 'choice'
      b.innerHTML = `<span><b>${s.name}</b><small>${s.water ? 'On the water, floatplane only' : 'Runway, ready for takeoff'}</small></span>`
      b.addEventListener('click', () => {
        if (s.water && this.kind !== 'floats') return
        this.start = s
        this.render()
      })
      this.starts.append(b)
    }
    ;(document.getElementById('fly') as HTMLButtonElement).addEventListener('click', () => this.fly())
    ;(document.getElementById('resume') as HTMLButtonElement).addEventListener('click', () => this.resume())
    this.render()
  }

  started = false

  setMuted(muted: boolean) {
    ;(document.getElementById('mutelabel') as HTMLElement).textContent = muted ? 'Sound off (V)' : 'Sound'
  }

  show() {
    this.open = true
    this.panel.hidden = false
    ;(document.getElementById('resume') as HTMLButtonElement).hidden = !this.started
  }

  resume() {
    if (!this.started) return
    this.open = false
    this.panel.hidden = true
  }

  fly() {
    this.started = true
    this.open = false
    this.panel.hidden = true
    this.onFly(this.kind, this.start)
  }

  private render() {
    const kinds = Object.keys(PLANES) as PlaneKind[]
    Array.from(this.planes.children).forEach((el, i) => el.classList.toggle('selected', kinds[i] === this.kind))
    Array.from(this.starts.children).forEach((el, i) => {
      const s = STARTS[i]
      el.classList.toggle('selected', s === this.start)
      el.classList.toggle('disabled', s.water && this.kind !== 'floats')
    })
  }
}

export const nav = { target: null as number | null }

import * as THREE from 'three'
import type { Input } from './input'
import { PAVEMENT_TOP, type Start } from './fields'
import { WATER_LEVEL } from './builders'
import { WORLD } from './terrain'
import type { World } from './world'
import { finShape, planform } from './airfield'

const G = 9.81
const CL_ALPHA = 5.2

export type PlaneKind = 'wheels' | 'floats' | 'fast' | 'jet'
export type PlaneSpec = {
  name: string
  blurb: string
  gear: number
  thrust: number
  falloff: number
  vmax: number
  vref: number
  vtrim: number
  liftK: number
  cd0: number
  ar: number
  alphaStall: number
  rotate: number
  stall: number
  span: number
  nose: number
  scale: number
  pitchRate: number
  rollRate: number
  yawRate: number
  tau: number
  cam: number
  color: string
}
export const PLANES: Record<PlaneKind, PlaneSpec> = {
  wheels: { name: 'Sparrow', blurb: 'Red trainer, 240 km/h, stalls at 95. Forgiving and aerobatic.', gear: 1.17, thrust: 4.6, falloff: 0.5, vmax: 70, vref: 45, vtrim: 48, liftK: 0.0104, cd0: 0.034, ar: 19, alphaStall: 0.27, rotate: 30, stall: 26, span: 5.5, nose: 4, scale: 1, pitchRate: 1.0, rollRate: 1.7, yawRate: 0.9, tau: 0.16, cam: 1, color: '#d8432f' },
  floats: { name: 'Pelican', blurb: 'Yellow amphibian, 200 km/h, stalls at 90. Lands on water, runways and grass.', gear: 1.42, thrust: 4.4, falloff: 0.5, vmax: 60, vref: 42, vtrim: 42, liftK: 0.0112, cd0: 0.047, ar: 17, alphaStall: 0.27, rotate: 29, stall: 25, span: 5.8, nose: 4, scale: 1, pitchRate: 0.85, rollRate: 1.25, yawRate: 0.8, tau: 0.22, cam: 1, color: '#f2c12e' },
  fast: { name: 'Kingfisher', blurb: 'Blue tourer, 340 km/h, stalls at 115. Fast rolls, needs runway.', gear: 1.46, thrust: 5.5, falloff: 0.5, vmax: 100, vref: 65, vtrim: 72, liftK: 0.00684, cd0: 0.03, ar: 22, alphaStall: 0.26, rotate: 36, stall: 32, span: 6.9, nose: 5, scale: 1.25, pitchRate: 1.2, rollRate: 2.3, yawRate: 0.9, tau: 0.14, cam: 1.25, color: '#2f6fd8' },
  jet: { name: 'Condor', blurb: 'Twin-jet airliner, 720 km/h, stalls at 220. Heavy, slow to respond, 1.5 km runways only.', gear: 3.7, thrust: 4.4, falloff: 0.55, vmax: 200, vref: 120, vtrim: 150, liftK: 0.0021, cd0: 0.022, ar: 26, alphaStall: 0.24, rotate: 68, stall: 61, span: 16, nose: 18, scale: 1, pitchRate: 0.4, rollRate: 0.65, yawRate: 0.35, tau: 0.55, cam: 3.2, color: '#f6f7f8' },
}

const clamp = THREE.MathUtils.clamp
const UP = new THREE.Vector3(0, 1, 0)

export class Plane {
  mesh = new THREE.Group()
  pos = new THREE.Vector3()
  velocity = new THREE.Vector3()
  forward = new THREE.Vector3(0, 0, -1)
  up = new THREE.Vector3(0, 1, 0)
  right = new THREE.Vector3(1, 0, 0)
  q = new THREE.Quaternion()
  rates = new THREE.Vector3()
  kind: PlaneKind = 'wheels'
  yaw = 0
  pitch = 0
  roll = 0
  speed = 0
  throttle = 0
  engineOn = true
  starting = 0
  onGround = true
  surface: 'ground' | 'water' = 'ground'
  crashed = false
  stalled = false
  landed = false
  crashReason = ''
  lastTouchdown = 0
  alpha = 0
  vtrim = 50
  start: Start
  private airTime = 0
  private time = 0
  private spinners: THREE.Object3D[] = []
  private tmpQ = new THREE.Quaternion()
  private tmpE = new THREE.Euler()
  private vb = new THREE.Vector3()
  private accel = new THREE.Vector3()
  private dir = new THREE.Vector3()
  private liftDir = new THREE.Vector3()

  constructor(private world: World, start: Start) {
    this.start = start
    this.setKind('wheels')
    this.reset()
  }

  get spec() {
    return PLANES[this.kind]
  }

  get altitude() {
    return Math.max(0, this.pos.y - this.spec.gear - PAVEMENT_TOP)
  }

  setKind(kind: PlaneKind) {
    this.kind = kind
    this.mesh.clear()
    this.mesh.scale.setScalar(this.spec.scale)
    this.spinners = kind === 'floats' ? [this.buildFloatplane()] : kind === 'fast' ? [this.buildTourer()] : kind === 'jet' ? this.buildJet() : [this.buildLandplane()]
  }

  reset(start = this.start) {
    this.start = start
    const gear = this.spec.gear
    this.pos.set(start.x, start.water ? WATER_LEVEL + gear : this.world.groundHeight(start.x, start.z) + gear, start.z)
    this.velocity.set(0, 0, 0)
    this.rates.set(0, 0, 0)
    this.q.setFromEuler(this.tmpE.set(0, start.yaw, 0, 'YXZ'))
    this.speed = this.throttle = this.airTime = this.alpha = 0
    this.engineOn = true
    this.starting = 0
    this.vtrim = this.spec.vtrim
    this.onGround = true
    this.surface = start.water ? 'water' : 'ground'
    this.crashed = this.stalled = this.landed = false
    this.crashReason = ''
    this.mesh.visible = true
    this.axes()
    this.sync(0)
  }

  toggleEngine() {
    if (this.engineOn) {
      this.engineOn = false
      this.starting = 0
    } else if (this.starting <= 0) this.starting = 1.6
  }

  update(dt: number, input: Input) {
    if (this.crashed) return
    this.time += dt
    const s = this.spec
    const gear = s.gear
    const pitchIn = input.axis(['KeyW', 'ArrowUp'], ['KeyS', 'ArrowDown'])
    const rollIn = input.axis(['KeyD', 'ArrowRight'], ['KeyA', 'ArrowLeft'])
    const yawIn = input.axis(['KeyE'], ['KeyQ'])
    const brake = input.down('Space')
    const thrIn = (input.down('ShiftLeft', 'ShiftRight') ? 1 : 0) - (input.down('ControlLeft', 'ControlRight') ? 1 : 0)
    this.throttle = clamp(this.throttle + thrIn * 0.6 * dt, 0, 1)
    if (this.starting > 0) {
      this.starting -= dt
      if (this.starting <= 0) this.engineOn = true
    }

    this.axes()
    const V = this.velocity.length()
    this.speed = V
    this.vb.copy(this.velocity).applyQuaternion(this.tmpQ.copy(this.q).invert())
    const alpha = V > 2 ? Math.atan2(-this.vb.y, -this.vb.z) : 0
    const beta = V > 2 ? Math.atan2(this.vb.x, -this.vb.z) : 0
    this.alpha = alpha
    const qeff = clamp((V / s.vref) * (V / s.vref), 0, 1.6)
    const stalled = !this.onGround && Math.abs(alpha) > s.alphaStall && V > 4
    this.stalled = stalled

    if (!this.onGround && V > s.stall * 0.9) this.vtrim += (V - this.vtrim) * Math.min(1, dt / (pitchIn !== 0 ? 2 : 5))
    const trim = Math.min(G / (s.liftK * this.vtrim * this.vtrim * CL_ALPHA), s.alphaStall * 0.85)
    const ctrl = Math.min(qeff, 1.25)
    let pc = pitchIn * s.pitchRate * ctrl - (alpha - trim) * 2.4 * qeff - this.velocity.y * 0.004 * qeff * (1 - Math.abs(pitchIn))
    let yc = yawIn * s.yawRate * ctrl - beta * 2.6 * qeff
    let rc = rollIn * s.rollRate * ctrl + beta * 0.9 * qeff - (rollIn === 0 ? Math.sin(this.roll) * 0.45 * Math.min(1, qeff) : 0)
    if (stalled) {
      pc -= Math.sign(alpha) * 0.9 * Math.min(1, (Math.abs(alpha) - s.alphaStall) / 0.2 + 0.3)
      rc += yc * 1.8 + Math.sin(this.time * 6.3) * 0.35
      yc *= 0.6
    }
    const k = Math.min(1, dt / s.tau)
    this.rates.x += (pc - this.rates.x) * k
    this.rates.y += (yc - this.rates.y) * k
    this.rates.z += (rc - this.rates.z) * k

    if (this.onGround) {
      const steer = clamp(rollIn + yawIn, -1, 1)
      this.rates.y = steer * (this.surface === 'water' ? 0.7 : 1.0) * clamp(V / 6, 0, 1)
      this.rates.z = 0
      const pitchNow = Math.asin(clamp(this.forward.y, -1, 1))
      if (pitchNow <= 0.001 && this.rates.x < 0) this.rates.x = 0
      if (pitchNow >= 0.3 && this.rates.x > 0) this.rates.x = 0
    }

    this.q.multiply(this.tmpQ.setFromEuler(this.tmpE.set(this.rates.x * dt, this.rates.y * dt, this.rates.z * dt, 'XYZ'))).normalize()
    if (this.onGround) {
      this.axes()
      const yaw = Math.atan2(-this.forward.x, -this.forward.z)
      const pitch = clamp(Math.asin(clamp(this.forward.y, -1, 1)), 0, 0.3)
      this.q.setFromEuler(this.tmpE.set(pitch, yaw, 0, 'YXZ'))
    }
    this.axes()

    const thrust = this.engineOn ? s.thrust * (1 - s.falloff * clamp(V / s.vmax, 0, 1.2)) * (0.06 + 0.94 * this.throttle) : 0
    const cl = this.liftCoefficient(alpha)
    const cd = s.cd0 + (cl * cl) / s.ar + (stalled ? 0.35 * (Math.abs(alpha) - s.alphaStall) : 0) + Math.abs(beta) * 0.12
    const V2 = V * V
    this.accel.set(0, -G, 0)
    this.accel.addScaledVector(this.forward, thrust)
    if (V > 0.01) {
      this.dir.copy(this.velocity).divideScalar(V)
      this.liftDir.copy(this.up).addScaledVector(this.dir, -this.up.dot(this.dir))
      if (this.liftDir.lengthSq() > 0.001) this.liftDir.normalize()
      else this.liftDir.copy(this.up)
      this.accel.addScaledVector(this.liftDir, s.liftK * cl * V2)
      this.accel.addScaledVector(this.dir, -s.liftK * cd * V2)
      this.accel.addScaledVector(this.right, -beta * 0.5 * s.liftK * V2)
    }
    if (this.onGround) {
      const friction = this.surface === 'water' ? 1.3 + (brake ? 3.5 : 0) : 0.6 + (brake ? 6 : 0)
      if (V > 0.01) this.accel.addScaledVector(this.dir, -Math.min(friction, V / dt))
      const pitchNow = Math.asin(clamp(this.forward.y, -1, 1))
      if (this.accel.y > 0.6 && pitchNow > 0.02) {
        this.onGround = false
        this.airTime = 0
      } else {
        this.accel.y = 0
        this.velocity.y = 0
      }
    } else {
      this.airTime += dt
      if (this.altitude > 15) this.landed = false
    }
    this.velocity.addScaledVector(this.accel, dt)
    this.pos.addScaledVector(this.velocity, dt)

    const water = this.world.inWater(this.pos.x, this.pos.z)
    const floor = water ? this.world.waterLevel(this.pos.x, this.pos.z) + gear : this.world.groundHeight(this.pos.x, this.pos.z) + gear
    if (this.pos.y <= floor + 0.05 && (this.onGround || this.velocity.y <= 0.05)) {
      if (!this.onGround) this.touchdown(water)
      if (this.crashed) {
        this.pos.y = floor
        this.sync(dt)
        return
      }
      this.pos.y = floor
      this.onGround = true
      this.surface = water ? 'water' : 'ground'
      this.velocity.y = 0
      this.rates.z = 0
      const yaw = Math.atan2(-this.forward.x, -this.forward.z)
      const pitch = clamp(Math.asin(clamp(this.forward.y, -1, 1)), 0, 0.3)
      this.q.setFromEuler(this.tmpE.set(pitch, yaw, 0, 'YXZ'))
      this.axes()
    }

    if (this.onGround && V > 1 && !this.crashed) {
      const pave = this.world.onPavement(this.pos.x, this.pos.z)
      if (water && this.kind !== 'floats') this.crash('Drove into the water')
      else if (!water && !pave) {
        if (this.kind === 'jet' && V > 8) this.crash('Ran off the runway')
        else if (V > 32) this.crash('Too fast for the grass')
        else if (V > 5 && this.world.slope(this.pos.x, this.pos.z) > 0.2) this.crash('Rolled into the hillside')
      }
    }
    if (V > s.vmax * 1.45) this.crash('Airframe broke up in overspeed')
    if (this.pos.x < WORLD.minX || this.pos.x > WORLD.maxX || this.pos.z < WORLD.minZ || this.pos.z > WORLD.maxZ) this.crash('Flew off the map')
    if (!this.crashed) this.checkObstacles()
    this.sync(dt)
  }

  private liftCoefficient(alpha: number) {
    const as = this.spec.alphaStall
    const a = clamp(alpha, -as - 0.7, as + 0.7)
    if (Math.abs(a) <= as) return CL_ALPHA * a
    const over = Math.abs(a) - as
    return Math.sign(a) * CL_ALPHA * as * Math.max(0.2, 1 - over / 0.45)
  }

  private axes() {
    this.forward.set(0, 0, -1).applyQuaternion(this.q)
    this.up.set(0, 1, 0).applyQuaternion(this.q)
    this.right.set(1, 0, 0).applyQuaternion(this.q)
    this.yaw = Math.atan2(-this.forward.x, -this.forward.z)
    this.pitch = Math.asin(clamp(this.forward.y, -1, 1))
    this.roll = Math.atan2(this.right.y, this.up.y)
  }

  private touchdown(water: boolean) {
    this.lastTouchdown = this.velocity.y
    const pitch = this.pitch, roll = Math.abs(this.roll)
    if (water) {
      if (this.kind !== 'floats') return this.crash('Hit the water')
      if (this.velocity.y < -5) return this.crash('Hit the water too hard')
      if (roll > 0.35) return this.crash('Dug a float into the water')
      if (pitch < -0.12) return this.crash('Nosed into the water')
      this.landed = this.landed || this.airTime > 1.5
      return
    }
    const pave = this.world.onPavement(this.pos.x, this.pos.z)
    if (this.velocity.y < -6) return this.crash('Hard landing')
    if (roll > 0.4) return this.crash('Wing hit the ground')
    if (pitch < -0.15) return this.crash('Nose hit the ground')
    if (pitch > 0.32) return this.crash('Tail struck the ground')
    if (!pave && this.speed > 32) return this.crash('Too fast for the grass')
    if (!pave && this.world.slope(this.pos.x, this.pos.z) > 0.2) return this.crash('Hit the hillside')
    const heading = Math.atan2(-this.forward.x, -this.forward.z)
    const track = Math.atan2(-this.velocity.x, -this.velocity.z)
    const crab = Math.abs(Math.atan2(Math.sin(heading - track), Math.cos(heading - track)))
    if (this.speed > 15 && crab > 0.35) return this.crash('Landed sideways and flipped')
    this.landed = this.landed || this.airTime > 1.5
  }

  private checkObstacles() {
    const p = this.pos
    const span = this.spec.span, nose = this.spec.nose
    const points = [
      [p.x, p.y, p.z],
      [p.x + this.forward.x * nose, p.y + this.forward.y * nose, p.z + this.forward.z * nose],
      [p.x + this.right.x * span, p.y + this.right.y * span, p.z + this.right.z * span],
      [p.x - this.right.x * span, p.y - this.right.y * span, p.z - this.right.z * span],
    ]
    for (const [x, y, z] of points) {
      const o = this.world.collides(x, y, z)
      if (o) return this.crash(o.reason)
    }
  }

  private crash(reason: string) {
    this.crashed = true
    this.crashReason = reason
    this.mesh.visible = false
  }

  private sync(dt: number) {
    this.mesh.position.copy(this.pos)
    this.mesh.quaternion.copy(this.q)
    if (this.onGround && this.surface === 'water' && !this.crashed) {
      this.mesh.position.y += Math.sin(this.time * 2.1) * 0.05
      this.mesh.rotateZ(Math.sin(this.time * 1.6) * 0.012)
      this.mesh.rotateX(Math.sin(this.time * 1.3 + 1) * 0.008)
    }
    const spin = this.engineOn ? 6 + this.throttle * 50 : clamp(this.speed / 60, 0, 0.35) * 12
    for (const sp of this.spinners) sp.rotation.z += spin * dt
  }

  private add(geo: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number) {
    const m = new THREE.Mesh(geo, mat)
    m.position.set(x, y, z)
    m.castShadow = true
    this.mesh.add(m)
    return m
  }

  private lamps(halfSpan: number, wingY: number, wingZ: number, tailY: number, tailZ: number) {
    const lamp = (color: number, x: number, y: number, z: number) => this.add(new THREE.SphereGeometry(0.14, 6, 4), new THREE.MeshBasicMaterial({ color }), x, y, z)
    lamp(0xff2a2a, -halfSpan, wingY, wingZ)
    lamp(0x2aff5a, halfSpan, wingY, wingZ)
    lamp(0xffffff, 0, tailY, tailZ)
  }

  private buildJet() {
    const white = new THREE.MeshLambertMaterial({ color: 0xf6f7f8 })
    const blue = new THREE.MeshLambertMaterial({ color: 0x2f6fd8 })
    const wing = new THREE.MeshLambertMaterial({ color: 0xd0d4da })
    const dark = new THREE.MeshLambertMaterial({ color: 0x2d3a4a })
    const steel = new THREE.MeshLambertMaterial({ color: 0x5f6875 })
    const body = new THREE.Group()
    body.position.y = -3.7
    this.mesh.add(body)
    const add = (geo: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number) => {
      const m = new THREE.Mesh(geo, mat)
      m.position.set(x, y, z)
      m.castShadow = true
      body.add(m)
      return m
    }
    const R = 2, yc = 3.7
    const tube = new THREE.CylinderGeometry(R, R, 24, 14)
    tube.rotateX(Math.PI / 2)
    add(tube, white, 0, yc, 1)
    add(new THREE.SphereGeometry(R, 14, 9), white, 0, yc, -11).scale.set(1, 1, 2.2)
    const cone = new THREE.CylinderGeometry(0.55, R, 11, 14)
    cone.rotateX(Math.PI / 2)
    add(cone, white, 0, yc + 0.5, 18.4).rotation.x = -0.09
    add(new THREE.BoxGeometry(2 * R + 0.06, 0.55, 22), dark, 0, yc + 0.55, 1)
    add(new THREE.BoxGeometry(2.6, 0.7, 1.4), dark, 0, yc + 0.55, -12.6)
    add(new THREE.BoxGeometry(2 * R + 0.05, 0.35, 25), blue, 0, yc - 0.35, 1)
    add(planform(15.5, 5.6, 1.6, 27, 0.45), wing, 0, yc - 1.4, -1.6)
    add(planform(5.6, 3, 1.2, 32, 0.28), wing, 0, yc + 1, 17.5)
    add(finShape(13.5, 21.5, 18.6, 21.5, 6.5, 0.4), blue, 0, yc + 1.2, 0)
    const nacelle = new THREE.CylinderGeometry(1.15, 1.05, 4.4, 12)
    nacelle.rotateX(Math.PI / 2)
    const ring = new THREE.CylinderGeometry(1.22, 1.22, 0.5, 12)
    ring.rotateX(Math.PI / 2)
    const spinners: THREE.Object3D[] = []
    for (const x of [-5.6, 5.6]) {
      add(nacelle, blue, x, yc - 2.3, 0.4)
      add(ring, dark, x, yc - 2.3, -1.8)
      add(new THREE.BoxGeometry(0.5, 1.4, 2.6), wing, x, yc - 1.5, 1.2)
      const fan = new THREE.Group()
      fan.position.set(x, yc - 2.3, -2.02)
      for (const a of [0, Math.PI / 3, (2 * Math.PI) / 3]) {
        const blade = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.22, 0.06), steel)
        blade.rotation.z = a
        fan.add(blade)
      }
      body.add(fan)
      spinners.push(fan)
    }
    const wheel = new THREE.CylinderGeometry(0.45, 0.45, 0.4, 8)
    wheel.rotateZ(Math.PI / 2)
    add(wheel, steel, -0.3, 0.45, -8)
    add(wheel, steel, 0.3, 0.45, -8)
    add(new THREE.BoxGeometry(0.3, 2.6, 0.3), steel, 0, 1.6, -8)
    for (const x of [-2.6, 2.6]) {
      add(wheel, steel, x, 0.45, 2.1)
      add(wheel, steel, x, 0.45, 3.1)
      add(new THREE.BoxGeometry(0.28, 1.4, 1.2), steel, x, 0.45, 2.6)
      add(new THREE.BoxGeometry(0.3, 2.6, 0.3), steel, x, 1.6, 2.6)
    }
    for (const x of [-15.4, 15.4]) add(new THREE.BoxGeometry(0.12, 1.6, 1.4), blue, x, yc - 0.55, 8.2).rotation.z = x < 0 ? 0.25 : -0.25
    for (const x of [-4.2, -8.2, -12, 4.2, 8.2, 12]) add(new THREE.BoxGeometry(0.5, 0.7, 4.2), wing, x, yc - 1.9, 2.4 + Math.abs(x) * 0.51)
    for (const z of [-9.2, 11.5]) for (const s of [-1, 1]) add(new THREE.BoxGeometry(0.12, 1.9, 1.1), dark, s * (R - 0.02), yc - 0.05, z)
    add(new THREE.BoxGeometry(3.6, 1.6, 12), white, 0, yc - 1.5, 0.5)
    add(new THREE.BoxGeometry(0.22, 0.6, 1.2), white, 0, yc + 2.15, -6)
    add(new THREE.BoxGeometry(0.22, 0.5, 1), white, 0, yc + 2.1, 8)
    add(new THREE.SphereGeometry(0.16, 6, 4), new THREE.MeshBasicMaterial({ color: 0xff2a2a }), 0, yc + 2.15, 2)
    add(new THREE.SphereGeometry(0.16, 6, 4), new THREE.MeshBasicMaterial({ color: 0xff2a2a }), 0, yc - 2.35, 0.5)
    const apu = new THREE.CylinderGeometry(0.3, 0.42, 1.4, 8)
    apu.rotateX(Math.PI / 2)
    add(apu, dark, 0, yc + 1.05, 24.4)
    add(new THREE.BoxGeometry(0.44, 2.2, 3.4), white, 0, yc + 4.4, 20).rotation.x = -0.5
    this.lamps(15.4, yc - 1.3 - 3.7, 6.2, yc + 7.9 - 3.7, 21.4)
    return spinners
  }

  private buildLandplane() {
    const red = new THREE.MeshLambertMaterial({ color: 0xd8432f })
    const cream = new THREE.MeshLambertMaterial({ color: 0xf3e9cf })
    const dark = new THREE.MeshLambertMaterial({ color: 0x2b2b30 })
    const glass = new THREE.MeshLambertMaterial({ color: 0x9fd8ff, transparent: true, opacity: 0.75 })
    this.add(new THREE.BoxGeometry(1.3, 1.2, 4.6), red, 0, 0, 0.3)
    this.add(new THREE.BoxGeometry(1.0, 0.9, 1.4), cream, 0, -0.05, -2.6)
    this.add(new THREE.ConeGeometry(0.35, 0.7, 8), dark, 0, 0, -3.65).rotation.x = -Math.PI / 2
    const prop = this.add(new THREE.BoxGeometry(0.18, 2.6, 0.12), dark, 0, 0, -3.42)
    this.add(new THREE.BoxGeometry(11, 0.18, 1.7), cream, 0, 0.25, -0.4)
    this.add(new THREE.BoxGeometry(11.04, 0.24, 0.34), red, 0, 0.25, -1.11)
    this.add(new THREE.BoxGeometry(0.9, 0.7, 1.7), glass, 0, 0.85, -0.6)
    this.add(new THREE.BoxGeometry(4.2, 0.12, 1.1), cream, 0, 0.2, 2.5)
    this.add(new THREE.BoxGeometry(0.12, 1.5, 1.2), red, 0, 1.1, 2.5)
    const wheel = new THREE.CylinderGeometry(0.32, 0.32, 0.25, 8)
    wheel.rotateZ(Math.PI / 2)
    const strut = new THREE.BoxGeometry(0.12, 0.7, 0.12)
    for (const x of [-1.4, 1.4]) {
      this.add(wheel, dark, x, -0.85, -0.3)
      this.add(strut, dark, x, -0.45, -0.3)
    }
    this.add(wheel, dark, 0, -0.85, 2.3)
    this.add(strut, dark, 0, -0.45, 2.3)
    this.lamps(5.55, 0.25, -0.4, 1.95, 2.5)
    return prop
  }

  private buildTourer() {
    const blue = new THREE.MeshLambertMaterial({ color: 0x2f6fd8 })
    const white = new THREE.MeshLambertMaterial({ color: 0xf6f7f8 })
    const dark = new THREE.MeshLambertMaterial({ color: 0x2b2b30 })
    const glass = new THREE.MeshLambertMaterial({ color: 0x9fd8ff, transparent: true, opacity: 0.75 })
    this.add(new THREE.BoxGeometry(1.3, 1.15, 5.2), blue, 0, 0, 0.4)
    this.add(new THREE.BoxGeometry(1.34, 0.3, 5.24), white, 0, -0.2, 0.4)
    this.add(new THREE.BoxGeometry(1.05, 0.9, 1.3), blue, 0, -0.05, -2.75)
    this.add(new THREE.ConeGeometry(0.34, 0.8, 8), white, 0, 0, -3.8).rotation.x = -Math.PI / 2
    const prop = this.add(new THREE.BoxGeometry(0.16, 2.7, 0.12), dark, 0, 0, -3.5)
    this.add(new THREE.BoxGeometry(11.4, 0.16, 1.8), blue, 0, 0.1, -0.2)
    this.add(new THREE.BoxGeometry(11.44, 0.22, 0.36), white, 0, 0.1, -0.95)
    this.add(new THREE.BoxGeometry(1.0, 0.62, 2.3), glass, 0, 0.85, -0.5)
    this.add(new THREE.BoxGeometry(1.1, 0.2, 2.4), blue, 0, 0.55, -0.5)
    this.add(new THREE.BoxGeometry(4.8, 0.12, 1.1), blue, 0, 0.2, 2.75)
    this.add(new THREE.BoxGeometry(0.12, 1.7, 1.25), blue, 0, 1.2, 2.7)
    this.add(new THREE.BoxGeometry(0.16, 0.36, 1.3), white, 0, 2.2, 2.7)
    const wheel = new THREE.CylinderGeometry(0.3, 0.3, 0.24, 8)
    wheel.rotateZ(Math.PI / 2)
    const strut = new THREE.BoxGeometry(0.12, 0.6, 0.12)
    for (const x of [-1.5, 1.5]) {
      this.add(wheel, dark, x, -0.87, 0.2)
      this.add(strut, dark, x, -0.5, 0.2)
    }
    this.add(wheel, dark, 0, -0.87, -2.4)
    this.add(strut, dark, 0, -0.5, -2.4)
    this.lamps(5.75, 0.1, -0.2, 2.45, 2.7)
    return prop
  }

  private buildFloatplane() {
    const yellow = new THREE.MeshLambertMaterial({ color: 0xf2c12e })
    const cream = new THREE.MeshLambertMaterial({ color: 0xf3e9cf })
    const dark = new THREE.MeshLambertMaterial({ color: 0x2b2b30 })
    const floatMat = new THREE.MeshLambertMaterial({ color: 0xd8dde3 })
    const glass = new THREE.MeshLambertMaterial({ color: 0x9fd8ff, transparent: true, opacity: 0.75 })
    this.add(new THREE.BoxGeometry(1.4, 1.3, 4.8), yellow, 0, 0, 0.3)
    this.add(new THREE.BoxGeometry(1.1, 1.0, 1.4), cream, 0, -0.05, -2.7)
    this.add(new THREE.ConeGeometry(0.36, 0.7, 8), dark, 0, 0, -3.75).rotation.x = -Math.PI / 2
    const prop = this.add(new THREE.BoxGeometry(0.18, 2.7, 0.12), dark, 0, 0, -3.52)
    this.add(new THREE.BoxGeometry(11.6, 0.2, 1.8), yellow, 0, 0.78, -0.5)
    this.add(new THREE.BoxGeometry(11.64, 0.26, 0.34), dark, 0, 0.78, -1.26)
    this.add(new THREE.BoxGeometry(1.0, 0.55, 1.7), glass, 0, 0.45, -1.0)
    this.add(new THREE.BoxGeometry(4.4, 0.14, 1.2), yellow, 0, 0.25, 2.5)
    this.add(new THREE.BoxGeometry(0.14, 1.6, 1.3), yellow, 0, 1.15, 2.5)
    this.add(new THREE.BoxGeometry(0.2, 0.36, 1.34), dark, 0, 2.1, 2.5)
    const floatGeo = new THREE.BoxGeometry(0.75, 0.6, 5.4)
    const bow = new THREE.BoxGeometry(0.75, 0.55, 1.2)
    const wheel = new THREE.CylinderGeometry(0.22, 0.22, 0.2, 8)
    wheel.rotateZ(Math.PI / 2)
    for (const x of [-1.05, 1.05]) {
      this.add(floatGeo, floatMat, x, -1.05, 0.3)
      this.add(bow, floatMat, x, -0.85, -2.7).rotation.x = -0.5
      this.add(new THREE.BoxGeometry(0.12, 0.95, 0.12), dark, x * 0.85, -0.45, -1.2)
      this.add(new THREE.BoxGeometry(0.12, 0.95, 0.12), dark, x * 0.85, -0.45, 1.5)
      this.add(wheel, dark, x, -1.25, -0.9)
      this.add(wheel, dark, x, -1.25, 1.7)
    }
    this.add(new THREE.BoxGeometry(2.3, 0.1, 0.1), dark, 0, -0.75, -1.2)
    this.add(new THREE.BoxGeometry(2.3, 0.1, 0.1), dark, 0, -0.75, 1.5)
    for (const x of [-1, 1]) this.add(new THREE.BoxGeometry(0.1, 0.1, 2.6), dark, x * 2.6, 0.35, -0.5).rotation.x = 0
    this.lamps(5.85, 0.78, -0.5, 2.35, 2.5)
    return prop
  }
}

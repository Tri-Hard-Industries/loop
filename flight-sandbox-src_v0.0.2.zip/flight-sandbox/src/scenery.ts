import * as THREE from 'three'
import { PAVEMENT, ROADS, TOWNS, insidePave, pointToWorld, type Field, type Pave } from './fields'
import { hash, terrainHeight } from './terrain'
import { M, WATER_LEVEL, addObstacle, box, flatten, lambert, place, prismRoof, type Site } from './builders'

const CROPS = [0xc9b458, 0x8fbf5a, 0x6f9f45, 0x9c7a4a, 0xb8c96a, 0xd8c56b, 0x7fae4f]

export function buildTurbine(site: Site, x: number, z: number) {
  const y = terrainHeight(x, z)
  const g = new THREE.Group()
  g.position.set(x, y, z)
  place(site, new THREE.Mesh(new THREE.CylinderGeometry(1.3, 2.2, 62, 10), M.white), 0, 31, 0, g)
  place(site, box(3.2, 3.2, 7.5, M.white), 0, 63, 0, g)
  const rotor = new THREE.Group()
  rotor.position.set(0, 63, -4.4)
  const hub = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.1, 1.6, 10), M.white)
  hub.rotation.x = Math.PI / 2
  rotor.add(hub)
  for (let k = 0; k < 3; k++) {
    const blade = new THREE.Mesh(new THREE.BoxGeometry(1.4, 29, 0.35), M.white)
    blade.position.set(0, 0, 0)
    blade.geometry.translate(0, 14.5, 0)
    blade.rotation.z = (k * 2 * Math.PI) / 3
    blade.castShadow = true
    rotor.add(blade)
  }
  rotor.rotation.z = hash(x, z) * Math.PI
  g.add(rotor)
  site.scene.add(g)
  site.rotors.push(rotor)
  const m = new THREE.Matrix4().makeTranslation(x, y, z)
  site.obstacles.push({ inv: m.invert(), box: new THREE.Box3(new THREE.Vector3(-3, 0, -3), new THREE.Vector3(3, 60, 3)), reason: 'Hit a wind turbine' })
  const m2 = new THREE.Matrix4().makeTranslation(x, y, z)
  site.obstacles.push({ inv: m2.invert(), box: new THREE.Box3(new THREE.Vector3(-30, 34, -6), new THREE.Vector3(30, 93, 0)), reason: 'Hit a wind turbine' })
}

export function buildLighthouse(site: Site, x: number, z: number) {
  const y = terrainHeight(x, z)
  const g = new THREE.Group()
  g.position.set(x, y, z)
  place(site, new THREE.Mesh(new THREE.CylinderGeometry(1.7, 2.4, 15, 12), M.white), 0, 7.5, 0, g)
  for (const yy of [4, 10]) place(site, new THREE.Mesh(new THREE.CylinderGeometry(2.05 - yy * 0.02, 2.15 - yy * 0.02, 2.2, 12), lambert(0xd8432f)), 0, yy, 0, g)
  place(site, new THREE.Mesh(new THREE.CylinderGeometry(2.4, 2.4, 0.5, 12), M.steel), 0, 15.2, 0, g)
  place(site, new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.5, 2.6, 10), M.glass), 0, 16.8, 0, g)
  place(site, box(0.9, 0.9, 0.9, M.lamp), 0, 16.8, 0, g)
  place(site, new THREE.Mesh(new THREE.ConeGeometry(2.1, 1.8, 10), lambert(0xd8432f)), 0, 19, 0, g)
  place(site, box(6, 3, 5, M.wall), 5, 1.5, 1, g)
  place(site, box(16, 0.4, 2.2, M.wall), 0, 0.2, 9, g)
  addObstacle(site, g, 'Hit the lighthouse')
}

export function buildPier(site: Site, x: number, z: number, rot: number, len: number) {
  const g = new THREE.Group()
  g.position.set(x, 0, z)
  g.rotation.y = rot
  place(site, box(3, 0.35, len, lambert(0xb08a5a)), 0, 0.4, -len / 2, g)
  for (let d = 4; d < len; d += 6) for (const px of [-1.2, 1.2]) place(site, box(0.35, 3.2, 0.35, M.steel), px, -0.9, -d, g)
  place(site, box(2.2, 0.9, 6, M.white), 3.2, WATER_LEVEL + 0.5, -len + 8, g)
  place(site, box(2.2, 0.9, 5, M.white), -3.4, WATER_LEVEL + 0.5, -len + 16, g)
  place(site, box(46, 0.3, 18, lambert(0xe3d3a3)), 0, 0.05, 5, g)
  addObstacle(site, g, 'Hit the pier')
}

export function buildFarmland(site: Site, f: Field, region: Pave) {
  const g = new THREE.Group()
  const fields = new THREE.Group()
  const color = new THREE.Color()
  let n = 0
  const cellW = 130, cellD = 105
  for (let lx = region.x - region.w / 2; lx < region.x + region.w / 2 - 40; lx += cellW) {
    for (let lz = region.z - region.d / 2; lz < region.z + region.d / 2 - 40; lz += cellD) {
      const w = cellW - 12 - hash(lx, lz) * 30, d = cellD - 12 - hash(lz, lx) * 24
      const cx = lx + cellW / 2, cz = lz + cellD / 2
      const [x, z] = pointToWorld(f, cx, cz)
      let ok = true
      for (const [ox, oz] of [[-w / 2, -d / 2], [w / 2, -d / 2], [-w / 2, d / 2], [w / 2, d / 2], [0, 0]]) {
        const [px, pz] = pointToWorld(f, cx + ox, cz + oz)
        if (Math.abs(terrainHeight(px, pz)) > 0.4 || PAVEMENT.some(p => insidePave(p, px, pz, 12)) || ROADS.some(r => insidePave(r, px, pz, 6)) || TOWNS.some(t => insidePave(t, px, pz, 25))) ok = false
      }
      if (!ok) continue
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, 0.25, d), new THREE.MeshLambertMaterial({ color: color.setHex(CROPS[Math.floor(hash(cx, cz + 3) * CROPS.length)]).multiplyScalar(0.9 + hash(cz, cx) * 0.2) }))
      mesh.position.set(x, 0.12, z)
      mesh.rotation.y = f.a
      mesh.receiveShadow = true
      fields.add(mesh)
      site.farmRects.push({ x, z, w, d, a: f.a, y: 0 })
      n++
      for (let t = -w / 2 + 8; t < w / 2; t += 22) {
        if (hash(t + cx, cz) > 0.55) continue
        const [tx, tz] = pointToWorld(f, cx + t, cz - d / 2 - 3)
        site.trees.push({ x: tx, z: tz, s: 0.6 + hash(t, cz) * 0.5 })
      }
      if (hash(cx, cz + 9) > 0.8) {
        const [bx, bz] = pointToWorld(f, cx + w / 2 - 10, cz + d / 2 - 8)
        const barn = new THREE.Group()
        barn.position.set(bx, 0, bz)
        barn.rotation.y = f.a
        place(site, box(14, 6, 9, lambert(0xa5432f)), 0, 3, 0, barn)
        place(site, new THREE.Mesh(prismRoof(14, 9, 6, 3.5), lambert(0x5a5f66)), 0, 0, 0, barn)
        place(site, new THREE.Mesh(new THREE.CylinderGeometry(2.2, 2.2, 11, 10), M.concrete), 10.5, 5.5, 0, barn)
        place(site, new THREE.Mesh(new THREE.ConeGeometry(2.4, 1.8, 10), M.steel), 10.5, 11.9, 0, barn)
        addObstacle(site, barn, 'Hit a barn')
      }
    }
  }
  const merged = flatten(fields)
  g.add(merged)
  site.scene.add(g)
  return n
}

import type { Plane } from './plane'

const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v))

type Piston = { osc: OscillatorNode; sub: OscillatorNode; filter: BiquadFilterNode; gain: GainNode; propLfo: OscillatorNode; propBand: BiquadFilterNode; propLevel: GainNode; crackleLfo: OscillatorNode; crackleLevel: GainNode; whine: OscillatorNode; whineGain: GainNode; waves: Record<string, PeriodicWave> }
type Profile = { fMin: number; fMax: number; filterMin: number; filterMax: number; gainIdle: number; gainFull: number; propIdle: number; propFull: number; propRatio: number; crackle: number; throb: number; whine: number; wave: string }
const PROFILES: Record<string, Profile> = {
  wheels: { fMin: 24, fMax: 82, filterMin: 300, filterMax: 1250, gainIdle: 0.08, gainFull: 0.26, propIdle: 0.03, propFull: 0.1, propRatio: 0.5, crackle: 0.02, throb: 0, whine: 0, wave: 'flat4' },
  floats: { fMin: 16, fMax: 58, filterMin: 220, filterMax: 850, gainIdle: 0.09, gainFull: 0.3, propIdle: 0.05, propFull: 0.15, propRatio: 0.34, crackle: 0.03, throb: 0.1, whine: 0, wave: 'radial' },
  fast: { fMin: 30, fMax: 108, filterMin: 380, filterMax: 1700, gainIdle: 0.07, gainFull: 0.24, propIdle: 0.02, propFull: 0.08, propRatio: 0.67, crackle: 0, throb: 0, whine: 0.012, wave: 'smooth6' },
}
type Jet = { whine: OscillatorNode; whine2: OscillatorNode; whineGain: GainNode; buzz: OscillatorNode[]; buzzGain: GainNode; core: BiquadFilterNode; coreGain: GainNode; exhaust: BiquadFilterNode; exhaustGain: GainNode }

export class Sound {
  volume = 0.7
  muted = false
  private ctx: AudioContext | null = null
  private master!: GainNode
  private noiseBuffer!: AudioBuffer
  private piston!: Piston
  private jet!: Jet
  private wind!: { band: BiquadFilterNode; gain: GainNode; lowGain: GainNode }
  private roll!: GainNode
  private water!: GainNode
  private stall!: { gain: GainNode; tremolo: GainNode }
  private rpm = 0
  private n1 = 0
  private nextBump = 0
  private nextBird = 3
  private lastPlane: Plane | null = null
  private profileKey = ''

  constructor() {
    const start = () => {
      if (!this.ctx) this.init()
      else if (this.ctx.state === 'suspended') this.ctx.resume()
    }
    addEventListener('keydown', start)
    addEventListener('pointerdown', start)
  }

  setVolume(v: number) {
    this.volume = clamp(v, 0, 1)
    this.applyVolume()
  }

  toggleMute() {
    this.muted = !this.muted
    this.applyVolume()
    return this.muted
  }

  update(dt: number, plane: Plane, paused: boolean) {
    if (!this.ctx) return
    this.lastPlane = plane
    const ctx = this.ctx
    const t = ctx.currentTime
    const jet = plane.kind === 'jet'
    const off = plane.crashed || paused

    const prof = PROFILES[plane.kind] ?? PROFILES.wheels
    const p = this.piston
    if (this.profileKey !== plane.kind && !jet) {
      this.profileKey = plane.kind
      p.osc.setPeriodicWave(p.waves[prof.wave])
    }
    const running = plane.engineOn && !off
    const targetRpm = !running || jet ? 0 : 0.16 + plane.throttle * 0.84 + clamp(plane.speed / 220, 0, 0.08)
    this.rpm += (targetRpm - this.rpm) * Math.min(1, 1.5 * dt)
    const jitter = 1 + Math.sin(t * 5.3) * 0.004 + Math.sin(t * 0.61) * 0.012 + (Math.random() - 0.5) * 0.006
    const throb = 1 + prof.throb * Math.sin(t * 2.8)
    const f = (prof.fMin + this.rpm * (prof.fMax - prof.fMin)) * jitter
    p.osc.frequency.setTargetAtTime(f, t, 0.06)
    p.sub.frequency.setTargetAtTime(f / 2, t, 0.06)
    p.propLfo.frequency.setTargetAtTime(f * prof.propRatio, t, 0.06)
    p.crackleLfo.frequency.setTargetAtTime(f, t, 0.06)
    p.filter.frequency.setTargetAtTime(prof.filterMin + this.rpm * (prof.filterMax - prof.filterMin), t, 0.08)
    p.propBand.frequency.setTargetAtTime(220 + this.rpm * 420, t, 0.1)
    const pistonOn = this.rpm > 0.02
    p.gain.gain.setTargetAtTime(pistonOn ? (prof.gainIdle + this.rpm * (prof.gainFull - prof.gainIdle)) * throb : 0, t, 0.08)
    p.propLevel.gain.setTargetAtTime(pistonOn ? prof.propIdle + this.rpm * (prof.propFull - prof.propIdle) : 0, t, 0.08)
    p.crackleLevel.gain.setTargetAtTime(pistonOn ? this.rpm * prof.crackle : 0, t, 0.08)
    p.whine.frequency.setTargetAtTime(700 + this.rpm * 1900, t, 0.1)
    p.whineGain.gain.setTargetAtTime(pistonOn ? this.rpm * this.rpm * prof.whine : 0, t, 0.1)

    const targetN1 = !running || !jet ? 0 : 0.2 + plane.throttle * 0.8
    this.n1 += (targetN1 - this.n1) * Math.min(1, 0.5 * dt)
    const j = this.jet
    const n1 = this.n1
    const jetOn = n1 > 0.02
    j.whine.frequency.setTargetAtTime(620 + n1 * 1150, t, 0.1)
    j.whine2.frequency.setTargetAtTime((620 + n1 * 1150) * 2.01, t, 0.1)
    j.whineGain.gain.setTargetAtTime(jetOn ? 0.005 + n1 * 0.013 : 0, t, 0.1)
    j.buzz.forEach((o, k) => o.frequency.setTargetAtTime((170 + n1 * 230) * [1, 1.018, 0.985, 1.04][k], t, 0.1))
    j.buzzGain.gain.setTargetAtTime(jetOn ? n1 * n1 * 0.035 : 0, t, 0.1)
    j.core.frequency.setTargetAtTime(300 + n1 * 520, t, 0.1)
    j.coreGain.gain.setTargetAtTime(jetOn ? 0.05 + n1 * 0.26 : 0, t, 0.1)
    j.exhaust.frequency.setTargetAtTime(600 + n1 * 900, t, 0.1)
    j.exhaustGain.gain.setTargetAtTime(jetOn ? n1 * n1 * 0.17 : 0, t, 0.1)

    const v = off ? 0 : plane.speed
    const w = clamp(v / (jet ? 200 : 72), 0, 1)
    this.wind.gain.gain.setTargetAtTime(w * w * (jet ? 0.2 : 0.17), t, 0.2)
    this.wind.band.frequency.setTargetAtTime(200 + v * 6, t, 0.2)
    this.wind.lowGain.gain.setTargetAtTime(w * w * 0.1, t, 0.2)

    const rolling = !off && plane.onGround && plane.surface === 'ground' ? clamp(v / 30, 0, 1) : 0
    this.roll.gain.setTargetAtTime(rolling * 0.2, t, 0.06)
    if (rolling > 0.3) {
      this.nextBump -= v * dt
      if (this.nextBump <= 0) {
        this.thud(0.03 + rolling * 0.05, 46 + Math.random() * 20)
        this.nextBump = 22 + Math.random() * 18
      }
    }

    const afloat = !off && plane.onGround && plane.surface === 'water' ? clamp(v / 25, 0, 1) : 0
    this.water.gain.setTargetAtTime(afloat * 0.16, t, 0.06)
    if (afloat > 0.2 && Math.random() < dt * 3) this.burst(600 + Math.random() * 500, 900, 0.03 + afloat * 0.03, 0.14, 'bandpass')

    this.stall.gain.gain.setTargetAtTime(!off && plane.stalled ? 0.038 : 0, t, 0.02)

    if (!off && plane.onGround && v < 2) {
      this.nextBird -= dt
      if (this.nextBird <= 0) {
        this.bird()
        this.nextBird = 3 + Math.random() * 8
      }
    }
  }

  touchdown(sink: number, water: boolean) {
    if (!this.ctx) return
    const s = clamp(sink / 6, 0.2, 1)
    if (water) {
      this.burst(700, 1400, 0.35 * s + 0.15, 0.7, 'bandpass')
      this.burst(260, 320, 0.3 * s, 0.35, 'lowpass')
      this.thud(0.3 * s, 55)
      return
    }
    this.thud(0.25 + 0.45 * s, 70)
    this.burst(2200, 2600, 0.12 + 0.12 * s, 0.09, 'bandpass')
    this.burst(320, 320, 0.25 * s, 0.22, 'lowpass')
  }

  crash(water: boolean) {
    if (!this.ctx) return
    if (water) {
      this.burst(900, 1800, 0.9, 1.2, 'bandpass')
      this.burst(200, 320, 0.7, 0.9, 'lowpass')
      this.thud(0.8, 42)
      return
    }
    this.burst(2600, 70, 0.95, 1.8, 'lowpass')
    this.burst(900, 1600, 0.3, 0.5, 'bandpass')
    this.thud(0.9, 40)
    const ctx = this.ctx
    const t = ctx.currentTime
    const o = ctx.createOscillator()
    o.frequency.setValueAtTime(52, t)
    o.frequency.exponentialRampToValueAtTime(22, t + 1.1)
    const g = ctx.createGain()
    g.gain.setValueAtTime(0.7, t)
    g.gain.exponentialRampToValueAtTime(0.001, t + 1.3)
    o.connect(g).connect(this.master)
    o.start(t)
    o.stop(t + 1.4)
  }

  private thud(gain: number, hz: number) {
    const ctx = this.ctx!
    const t = ctx.currentTime
    const o = ctx.createOscillator()
    o.frequency.setValueAtTime(hz, t)
    o.frequency.exponentialRampToValueAtTime(hz * 0.45, t + 0.18)
    const g = ctx.createGain()
    g.gain.setValueAtTime(gain, t)
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.22)
    o.connect(g).connect(this.master)
    o.start(t)
    o.stop(t + 0.25)
  }

  private burst(fromHz: number, toHz: number, gain: number, seconds: number, type: BiquadFilterType) {
    const ctx = this.ctx!
    const t = ctx.currentTime
    const src = ctx.createBufferSource()
    src.buffer = this.noiseBuffer
    src.loop = true
    src.loopStart = Math.random() * 1.5
    const f = ctx.createBiquadFilter()
    f.type = type
    f.Q.value = type === 'bandpass' ? 0.9 : 0.7
    f.frequency.setValueAtTime(fromHz, t)
    f.frequency.exponentialRampToValueAtTime(toHz, t + seconds)
    const g = ctx.createGain()
    g.gain.setValueAtTime(0.0001, t)
    g.gain.exponentialRampToValueAtTime(gain, t + 0.015)
    g.gain.exponentialRampToValueAtTime(0.001, t + seconds)
    src.connect(f).connect(g).connect(this.master)
    src.start(t)
    src.stop(t + seconds + 0.05)
  }

  private bird() {
    const ctx = this.ctx!
    const t = ctx.currentTime
    const notes = 2 + Math.floor(Math.random() * 3)
    for (let k = 0; k < notes; k++) {
      const o = ctx.createOscillator()
      const base = 2400 + Math.random() * 1600
      const t0 = t + k * 0.17
      o.frequency.setValueAtTime(base, t0)
      o.frequency.exponentialRampToValueAtTime(base * (Math.random() > 0.5 ? 1.35 : 0.75), t0 + 0.09)
      const g = ctx.createGain()
      g.gain.setValueAtTime(0.0001, t0)
      g.gain.exponentialRampToValueAtTime(0.02, t0 + 0.02)
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.12)
      o.connect(g).connect(this.master)
      o.start(t0)
      o.stop(t0 + 0.14)
    }
  }

  private applyVolume() {
    if (this.ctx) this.master.gain.setTargetAtTime(this.muted ? 0 : this.volume * 0.3, this.ctx.currentTime, 0.03)
  }

  private init() {
    const ctx = new AudioContext()
    this.ctx = ctx
    const limiter = ctx.createDynamicsCompressor()
    limiter.threshold.value = -18
    limiter.knee.value = 12
    limiter.ratio.value = 5
    limiter.attack.value = 0.004
    limiter.release.value = 0.2
    limiter.connect(ctx.destination)
    this.master = ctx.createGain()
    this.master.gain.value = this.muted ? 0 : this.volume * 0.3
    this.master.connect(limiter)

    const len = ctx.sampleRate * 3
    this.noiseBuffer = ctx.createBuffer(1, len, ctx.sampleRate)
    const data = this.noiseBuffer.getChannelData(0)
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1
    const noise = ctx.createBufferSource()
    noise.buffer = this.noiseBuffer
    noise.loop = true
    noise.start()

    const makeWave = (power: number, evenScale: number, cut: number) => {
      const harmonics = 22
      const real = new Float32Array(harmonics + 1)
      const imag = new Float32Array(harmonics + 1)
      for (let k = 1; k <= harmonics; k++) imag[k] = Math.pow(k, -power) * (k % 2 === 0 ? evenScale : 1) * (k > cut ? 0.5 : 1)
      return ctx.createPeriodicWave(real, imag)
    }
    const waves = { flat4: makeWave(1.25, 0.75, 12), radial: makeWave(1.1, 1.15, 8), smooth6: makeWave(1.6, 0.9, 14) }
    const wave = waves.flat4

    const shaper = ctx.createWaveShaper()
    const curve = new Float32Array(1024)
    for (let i = 0; i < 1024; i++) curve[i] = Math.tanh((i / 511.5 - 1) * 1.8)
    shaper.curve = curve
    shaper.oversample = '2x'

    const pFilter = ctx.createBiquadFilter()
    pFilter.type = 'lowpass'
    pFilter.Q.value = 0.7
    const pGain = ctx.createGain()
    pGain.gain.value = 0
    pFilter.connect(shaper).connect(pGain).connect(this.master)
    const osc = ctx.createOscillator()
    osc.setPeriodicWave(wave)
    const oscLevel = ctx.createGain()
    oscLevel.gain.value = 0.55
    osc.connect(oscLevel).connect(pFilter)
    osc.start()
    const sub = ctx.createOscillator()
    sub.type = 'sine'
    const subLevel = ctx.createGain()
    subLevel.gain.value = 0.35
    sub.connect(subLevel).connect(pFilter)
    sub.start()
    const propBand = ctx.createBiquadFilter()
    propBand.type = 'bandpass'
    propBand.Q.value = 1.1
    const propAm = ctx.createGain()
    propAm.gain.value = 0.5
    const propLfo = ctx.createOscillator()
    propLfo.type = 'sine'
    const propDepth = ctx.createGain()
    propDepth.gain.value = 0.5
    propLfo.connect(propDepth).connect(propAm.gain)
    propLfo.start()
    const propLevel = ctx.createGain()
    propLevel.gain.value = 0
    noise.connect(propBand).connect(propAm).connect(propLevel).connect(this.master)
    const crackleHp = ctx.createBiquadFilter()
    crackleHp.type = 'highpass'
    crackleHp.frequency.value = 1400
    const crackleAm = ctx.createGain()
    crackleAm.gain.value = 0.5
    const crackleLfo = ctx.createOscillator()
    crackleLfo.type = 'square'
    const crackleDepth = ctx.createGain()
    crackleDepth.gain.value = 0.5
    crackleLfo.connect(crackleDepth).connect(crackleAm.gain)
    crackleLfo.start()
    const crackleLevel = ctx.createGain()
    crackleLevel.gain.value = 0
    noise.connect(crackleHp).connect(crackleAm).connect(crackleLevel).connect(pFilter)
    const pWhine = ctx.createOscillator()
    pWhine.type = 'sine'
    const pWhineGain = ctx.createGain()
    pWhineGain.gain.value = 0
    pWhine.connect(pWhineGain).connect(this.master)
    pWhine.start()
    this.piston = { osc, sub, filter: pFilter, gain: pGain, propLfo, propBand, propLevel, crackleLfo, crackleLevel, whine: pWhine, whineGain: pWhineGain, waves }

    const whine = ctx.createOscillator()
    whine.type = 'sine'
    const whine2 = ctx.createOscillator()
    whine2.type = 'sine'
    const whine2Level = ctx.createGain()
    whine2Level.gain.value = 0.15
    const whineGain = ctx.createGain()
    whineGain.gain.value = 0
    whine.connect(whineGain)
    whine2.connect(whine2Level).connect(whineGain)
    whineGain.connect(this.master)
    whine.start()
    whine2.start()
    const buzzGain = ctx.createGain()
    buzzGain.gain.value = 0
    const buzz = [0, 1, 2, 3].map(() => {
      const o = ctx.createOscillator()
      o.type = 'triangle'
      const l = ctx.createGain()
      l.gain.value = 0.25
      o.connect(l).connect(buzzGain)
      o.start()
      return o
    })
    const buzzLp = ctx.createBiquadFilter()
    buzzLp.type = 'lowpass'
    buzzLp.frequency.value = 700
    buzzGain.connect(buzzLp).connect(this.master)
    const core = ctx.createBiquadFilter()
    core.type = 'lowpass'
    core.Q.value = 0.6
    const coreGain = ctx.createGain()
    coreGain.gain.value = 0
    noise.connect(core).connect(coreGain).connect(this.master)
    const exhaust = ctx.createBiquadFilter()
    exhaust.type = 'bandpass'
    exhaust.Q.value = 0.45
    const exhaustGain = ctx.createGain()
    exhaustGain.gain.value = 0
    noise.connect(exhaust).connect(exhaustGain).connect(this.master)
    this.jet = { whine, whine2, whineGain, buzz, buzzGain, core, coreGain, exhaust, exhaustGain }

    const windBand = ctx.createBiquadFilter()
    windBand.type = 'bandpass'
    windBand.Q.value = 0.7
    const windGain = ctx.createGain()
    windGain.gain.value = 0
    noise.connect(windBand).connect(windGain).connect(this.master)
    const windLow = ctx.createBiquadFilter()
    windLow.type = 'lowpass'
    windLow.frequency.value = 260
    const windLowGain = ctx.createGain()
    windLowGain.gain.value = 0
    noise.connect(windLow).connect(windLowGain).connect(this.master)
    this.wind = { band: windBand, gain: windGain, lowGain: windLowGain }

    const rollFilter = ctx.createBiquadFilter()
    rollFilter.type = 'lowpass'
    rollFilter.frequency.value = 140
    this.roll = ctx.createGain()
    this.roll.gain.value = 0
    noise.connect(rollFilter).connect(this.roll).connect(this.master)

    const waterBand = ctx.createBiquadFilter()
    waterBand.type = 'bandpass'
    waterBand.frequency.value = 750
    waterBand.Q.value = 0.8
    this.water = ctx.createGain()
    this.water.gain.value = 0
    noise.connect(waterBand).connect(this.water).connect(this.master)

    const horn = ctx.createOscillator()
    horn.type = 'sine'
    horn.frequency.value = 620
    const horn2 = ctx.createOscillator()
    horn2.type = 'triangle'
    horn2.frequency.value = 1240
    const horn2Level = ctx.createGain()
    horn2Level.gain.value = 0.2
    const tremolo = ctx.createGain()
    tremolo.gain.value = 0.7
    const tremLfo = ctx.createOscillator()
    tremLfo.frequency.value = 5.5
    const tremDepth = ctx.createGain()
    tremDepth.gain.value = 0.3
    tremLfo.connect(tremDepth).connect(tremolo.gain)
    tremLfo.start()
    const hornGain = ctx.createGain()
    hornGain.gain.value = 0
    horn.connect(tremolo)
    horn2.connect(horn2Level).connect(tremolo)
    tremolo.connect(hornGain).connect(this.master)
    horn.start()
    horn2.start()
    this.stall = { gain: hornGain, tremolo }

    const ambient = ctx.createBiquadFilter()
    ambient.type = 'lowpass'
    ambient.frequency.value = 220
    const ambientGain = ctx.createGain()
    ambientGain.gain.value = 0.012
    noise.connect(ambient).connect(ambientGain).connect(this.master)
    if (this.lastPlane) this.update(0.016, this.lastPlane, false)
  }
}

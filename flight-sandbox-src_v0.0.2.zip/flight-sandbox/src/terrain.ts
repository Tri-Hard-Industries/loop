import { Color, MathUtils } from 'three'
import { COAST, FLAT_SPOTS, ISLANDS, ISLE, LAKES, RIVER, lakeRadius } from './fields'
import { hash } from './noise'

export const WORLD = { minX: -12000, maxX: 12000, minZ: -12000, maxZ: 56000 }
export const NORTH_TILE = { minX: -8500, maxX: 8500, minZ: -8500, maxZ: 8500, segs: 300 }
export const ISLE_TILE = { minX: -1500, maxX: 6500, minZ: 46000, maxZ: 53000, segs: 160 }
const clamp = MathUtils.clamp

export { hash } from './noise'

export function noise(x: number, z: number) {
  const xi = Math.floor(x), zi = Math.floor(z)
  const fx = x - xi, fz = z - zi
  const u = fx * fx * (3 - 2 * fx), v = fz * fz * (3 - 2 * fz)
  const a = hash(xi, zi), b = hash(xi + 1, zi), c = hash(xi, zi + 1), d = hash(xi + 1, zi + 1)
  return (a * (1 - u) + b * u) * (1 - v) + (c * (1 - u) + d * u) * v
}

export function smoothstep(a: number, b: number, x: number) {
  const t = clamp((x - a) / (b - a), 0, 1)
  return t * t * (3 - 2 * t)
}

function baseHeight(x: number, z: number) {
  const d = Math.hypot(x, z)
  const hills = noise(x / 380, z / 380) * 70 + noise(x / 130 + 7.3, z / 130 + 2.1) * 22 + noise(x / 40 + 3.7, z / 40 + 9.2) * 5
  const big = smoothstep(1300, 2400, d) * noise(x / 800 + 2, z / 800 + 9) * 110 + smoothstep(3800, 5200, d) * noise(x / 1300 + 4, z / 1300 + 1) * 140
  const edge = Math.max(Math.abs(x), Math.abs(z))
  const mountains = smoothstep(7300, 8400, edge) * (1 - smoothstep(9800, 11800, edge)) * (noise(x / 520 + 11, z / 520 + 5) * 520 + noise(x / 170 + 4, z / 170 + 8) * 90)
  const bump = (u: number, w: number) => Math.exp(-((u / w) ** 2))
  const rx = x + 3400, rz = z + 3600
  const u = rx * 0.727 - rz * 0.687
  const v = rx * 0.687 + rz * 0.727
  const along = bump(u + 800, 620) * 820 + bump(u - 500, 520) * 650 + bump(u - 1800, 560) * 420 + bump(u + 2100, 560) * 380
  const ridge = along * bump(v, 480) * (0.8 + 0.4 * noise(x / 160 + 5, z / 160 + 3))
  let flat = 1
  for (const f of FLAT_SPOTS) flat *= smoothstep(f.r0, f.r1, Math.hypot(x - f.x, z - f.z))
  let bowl = 0
  for (const [lx, lz, r] of LAKES) {
    const dx = x - lx, dz = z - lz
    const u = Math.hypot(dx, dz) / lakeRadius(r, Math.atan2(dz, dx))
    bowl += 10 * (1 - smoothstep(0.35, 1, u))
  }
  if (x > RIVER.x0 && x < RIVER.x1) {
    const hw = RIVER.half(x)
    bowl += 6 * (1 - smoothstep(hw * 0.6, hw + 25, Math.abs(z - RIVER.z(x))))
  }
  let island = 0
  for (const [ix, iz, r, h] of ISLANDS) island += h * (1 - smoothstep(r * 0.4, r, Math.hypot(x - ix, z - iz)))
  const land = (hills + big + mountains + ridge) * flat - bowl + island
  if (z < 36000) return land
  const cz = COAST(x)
  const coastal = smoothstep(cz - 500, cz + 500, z)
  const isle = 1 - smoothstep(0.7, 1, Math.hypot((x - ISLE.x) / ISLE.rx, (z - ISLE.z) / ISLE.rz))
  const sea = coastal * (1 - isle)
  const depth = 8 + 14 * smoothstep(cz + 1500, cz + 7000, z) * (1 - isle)
  const lowland = land * (1 - 0.7 * smoothstep(cz - 6000, cz - 1500, z))
  return lowland * (1 - sea) - depth * sea
}

export function seaFactor(x: number, z: number) {
  if (z < 36000) return 0
  const cz = COAST(x)
  return smoothstep(cz - 2000, cz + 500, z)
}

export function terrainHeight(x: number, z: number) {
  return baseHeight(x, z)
}

const GRASS = new Color(0x74b94e)
const DARK_GRASS = new Color(0x4c8c3a)
const ROCK = new Color(0x8d8578)
const SNOW = new Color(0xf4f6f8)
const SAND = new Color(0xd9c99a)
const SEABED = new Color(0x6e8f9c)

export function terrainColor(out: Color, h: number, ny: number, r: number, coastal = 0) {
  out.copy(GRASS).lerp(DARK_GRASS, clamp(h / 140, 0, 1) * 0.75 + r * 0.18)
  if (ny < 0.8) out.lerp(ROCK, clamp((0.8 - ny) / 0.3, 0, 1))
  if (h > 250) out.lerp(SNOW, smoothstep(250, 380, h))
  if (h < 0) out.lerp(SAND, clamp(-h / 2, 0, 1))
  if (coastal > 0 && h < 2.5) out.lerp(SAND, coastal * clamp((2.5 - h) / 1.5, 0, 1))
  if (h < -3) out.lerp(SEABED, clamp((-3 - h) / 6, 0, 1))
}

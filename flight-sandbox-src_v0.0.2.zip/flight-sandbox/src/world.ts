import * as THREE from 'three'
import { FIELDS, LAKES, PAVEMENT, PAVEMENT_TOP, RIVER, ROADS, TOWNS, TREE_CLUSTERS, insidePave, lakeRadius } from './fields'
import { ISLE_TILE, NORTH_TILE, WORLD, hash, seaFactor, terrainColor, terrainHeight } from './terrain'
import { buildField, buildLights } from './airfield'
import { CITY_MAT, M, WATER_LEVEL, WATER_MAT, flatten, type Obstacle, type Site, type TreeSpot } from './builders'

export const SKY = 0x8ec9ff

export class World implements Site {
  scene = new THREE.Scene()
  obstacles: Obstacle[] = []
  buildings: [number, number][] = []
  lights: { x: number; y: number; z: number; color: number }[] = []
  trees: TreeSpot[] = []
  rotors: THREE.Object3D[] = []
  farmRects: { x: number; z: number; w: number; d: number; a: number; y: number }[] = []
  night = false
  private sun = new THREE.DirectionalLight(0xfff1d6, 2.6)
  private hemi = new THREE.HemisphereLight(0xd6ecff, 0x5e9440, 1.2)
  private stars = new THREE.Points()
  private moon = new THREE.Mesh(new THREE.SphereGeometry(110, 16, 12), new THREE.MeshBasicMaterial({ color: 0xe6ecff, fog: false }))
  private clouds: THREE.Group[] = []
  private grid = new Map<number, Obstacle[]>()
  private probe = new THREE.Vector3()

  constructor() {
    this.scene.background = new THREE.Color(SKY)
    this.scene.fog = new THREE.Fog(SKY, 1200, 7500)
    this.scene.add(this.hemi)
    this.buildSky()
    this.sun.castShadow = true
    this.sun.shadow.mapSize.set(2048, 2048)
    this.sun.shadow.bias = -0.0004
    const sc = this.sun.shadow.camera
    sc.left = sc.bottom = -140
    sc.right = sc.top = 140
    sc.near = 10
    sc.far = 900
    this.scene.add(this.sun, this.sun.target)
    this.buildTerrain()
    for (const f of FIELDS) buildField(this, f)
    buildLights(this)
    this.buildGrid()
    this.buildTrees()
    this.buildGrid()
    this.buildClouds()
  }

  collides(x: number, y: number, z: number) {
    const list = this.grid.get(this.cell(x, z))
    if (!list) return null
    for (const o of list) if (o.box.containsPoint(this.probe.set(x, y, z).applyMatrix4(o.inv))) return o
    return null
  }

  inWater(x: number, z: number) {
    for (const [lx, lz, r] of LAKES) {
      const dx = x - lx, dz = z - lz
      if (Math.hypot(dx, dz) < lakeRadius(r, Math.atan2(dz, dx)) * 0.82) return true
    }
    if (x > RIVER.x0 && x < RIVER.x1 && Math.abs(z - RIVER.z(x)) < RIVER.half(x) + 3) return true
    return z > 36000 && terrainHeight(x, z) < WATER_LEVEL - 0.2
  }

  waterLevel(_x: number, _z: number) {
    return WATER_LEVEL
  }

  private cell(x: number, z: number) {
    return Math.floor((x - WORLD.minX) / 150) * 4096 + Math.floor((z - WORLD.minZ) / 150)
  }

  private buildGrid() {
    this.grid.clear()
    const m = new THREE.Matrix4()
    const wb = new THREE.Box3()
    for (const o of this.obstacles) {
      wb.copy(o.box).applyMatrix4(m.copy(o.inv).invert())
      for (let x = wb.min.x; x <= wb.max.x + 150; x += 150) {
        for (let z = wb.min.z; z <= wb.max.z + 150; z += 150) {
          const key = this.cell(Math.min(x, wb.max.x), Math.min(z, wb.max.z))
          const list = this.grid.get(key)
          if (list) {
            if (list[list.length - 1] !== o) list.push(o)
          } else this.grid.set(key, [o])
        }
      }
    }
  }

  groundHeight(x: number, z: number) {
    return terrainHeight(x, z) + (this.onPavement(x, z) ? PAVEMENT_TOP : 0)
  }

  onPavement(x: number, z: number, margin = 3) {
    return PAVEMENT.some(r => insidePave(r, x, z, margin))
  }

  setNight(on: boolean) {
    this.night = on
    const sky = on ? 0x0a1020 : SKY
    ;(this.scene.background as THREE.Color).setHex(sky)
    ;(this.scene.fog as THREE.Fog).color.setHex(sky)
    this.hemi.color.setHex(on ? 0x2a3a6a : 0xd6ecff)
    this.hemi.groundColor.setHex(on ? 0x0e1218 : 0x5e9440)
    this.hemi.intensity = on ? 0.35 : 1.2
    this.sun.color.setHex(on ? 0xaabbff : 0xfff1d6)
    this.sun.intensity = on ? 0.45 : 2.6
    this.stars.visible = this.moon.visible = on
    M.darkGlass.emissive.setHex(on ? 0x8a7a3c : 0)
    M.glass.emissive.setHex(on ? 0x5a6a80 : 0)
    CITY_MAT.emissive.setHex(on ? 0xffffff : 0)
  }

  slope(x: number, z: number) {
    const dx = terrainHeight(x + 4, z) - terrainHeight(x - 4, z)
    const dz = terrainHeight(x, z + 4) - terrainHeight(x, z - 4)
    return Math.hypot(dx, dz) / 8
  }

  update(dt: number, focus: THREE.Vector3) {
    if (WATER_MAT.map) {
      WATER_MAT.map.offset.x += dt * 0.0025
      WATER_MAT.map.offset.y += dt * 0.0011
    }
    for (const r of this.rotors) r.rotation.z += dt * 0.9
    this.sun.position.set(focus.x + 150, focus.y + 260, focus.z + 90)
    this.sun.target.position.copy(focus)
    for (const c of this.clouds) {
      c.position.x += 2.5 * dt
      if (c.position.x > WORLD.maxX - 300) c.position.x = WORLD.minX + 300
    }
  }

  private buildSky() {
    const n = 1600
    const pos = new Float32Array(n * 3)
    for (let i = 0; i < n; i++) {
      const u = hash(i, 91) * Math.PI * 2, v = Math.acos(1 - hash(i, 92))
      const r = 9000
      pos[i * 3] = r * Math.sin(v) * Math.cos(u)
      pos[i * 3 + 1] = Math.abs(r * Math.cos(v)) + 200
      pos[i * 3 + 2] = r * Math.sin(v) * Math.sin(u)
    }
    const geo = new THREE.BufferGeometry()
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3))
    this.stars = new THREE.Points(geo, new THREE.PointsMaterial({ color: 0xffffff, size: 18, fog: false, sizeAttenuation: true }))
    this.stars.visible = false
    this.moon.position.set(3200, 2600, -4200)
    this.moon.visible = false
    this.scene.add(this.stars, this.moon)
  }

  private buildTerrain() {
    const coarse = 250
    const fine = [NORTH_TILE, ISLE_TILE]
    this.terrainTile(WORLD.minX, WORLD.maxX, WORLD.minZ, WORLD.maxZ, coarse, (x0, z0, x1, z1) => fine.some(t => x0 >= t.minX - 1 && x1 <= t.maxX + 1 && z0 >= t.minZ - 1 && z1 <= t.maxZ + 1))
    for (const t of fine) {
      this.terrainTile(t.minX, t.maxX, t.minZ, t.maxZ, (t.maxX - t.minX) / t.segs)
      this.skirt(t.minX, t.maxX, t.minZ, t.maxZ, (t.maxX - t.minX) / t.segs)
    }
    const seaGeo = new THREE.PlaneGeometry(WORLD.maxX - WORLD.minX, WORLD.maxZ - 36000, 24, 20)
    const seaUv = seaGeo.attributes.uv as THREE.BufferAttribute
    for (let i = 0; i < seaUv.count; i++) seaUv.setXY(i, seaUv.getX(i) * (WORLD.maxX - WORLD.minX), seaUv.getY(i) * (WORLD.maxZ - 36000))
    const sea = new THREE.Mesh(seaGeo, WATER_MAT)
    sea.rotation.x = -Math.PI / 2
    sea.position.set(0, WATER_LEVEL, (36000 + WORLD.maxZ) / 2)
    sea.receiveShadow = true
    this.scene.add(sea)
  }

  private terrainTile(x0: number, x1: number, z0: number, z1: number, cell: number, skip?: (cx0: number, cz0: number, cx1: number, cz1: number) => boolean) {
    const nx = Math.round((x1 - x0) / cell), nz = Math.round((z1 - z0) / cell)
    const heights: number[][] = []
    for (let i = 0; i <= nx; i++) {
      heights.push([])
      for (let j = 0; j <= nz; j++) heights[i].push(terrainHeight(x0 + i * cell, z0 + j * cell))
    }
    const pos: number[] = [], col: number[] = []
    const c = new THREE.Color()
    const push = (ax: number, az: number, bx: number, bz: number, cx: number, cz: number) => {
      const ay = heights[Math.round((ax - x0) / cell)][Math.round((az - z0) / cell)]
      const by = heights[Math.round((bx - x0) / cell)][Math.round((bz - z0) / cell)]
      const cy = heights[Math.round((cx - x0) / cell)][Math.round((cz - z0) / cell)]
      pos.push(ax, ay, az, bx, by, bz, cx, cy, cz)
      const ux = bx - ax, uy = by - ay, uz = bz - az, vx = cx - ax, vy = cy - ay, vz = cz - az
      const nnx = uy * vz - uz * vy, nny = uz * vx - ux * vz, nnz = ux * vy - uy * vx
      const ny = nny / Math.hypot(nnx, nny, nnz)
      const h = (ay + by + cy) / 3
      const mx = (ax + bx + cx) / 3, mz = (az + bz + cz) / 3
      terrainColor(c, h, ny, hash(Math.round(mx), Math.round(mz)), seaFactor(mx, mz))
      for (let k = 0; k < 3; k++) col.push(c.r, c.g, c.b)
    }
    for (let i = 0; i < nx; i++) {
      for (let j = 0; j < nz; j++) {
        const cx0 = x0 + i * cell, cz0 = z0 + j * cell, cx1 = cx0 + cell, cz1 = cz0 + cell
        if (skip && skip(cx0, cz0, cx1, cz1)) continue
        push(cx0, cz0, cx0, cz1, cx1, cz1)
        push(cx0, cz0, cx1, cz1, cx1, cz0)
      }
    }
    const geo = new THREE.BufferGeometry()
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3))
    geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3))
    geo.computeVertexNormals()
    const mesh = new THREE.Mesh(geo, new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true }))
    mesh.receiveShadow = true
    this.scene.add(mesh)
  }

  private skirt(x0: number, x1: number, z0: number, z1: number, cell: number) {
    const pos: number[] = [], col: number[] = []
    const c = new THREE.Color()
    const drop = 40
    const edge = (ax: number, az: number, bx: number, bz: number) => {
      const ay = terrainHeight(ax, az), by = terrainHeight(bx, bz)
      terrainColor(c, Math.min(ay, by) - 5, 0.6, 0.5, seaFactor(ax, az))
      pos.push(ax, ay, az, bx, by, bz, bx, by - drop, bz, ax, ay, az, bx, by - drop, bz, ax, ay - drop, az)
      for (let k = 0; k < 6; k++) col.push(c.r, c.g, c.b)
    }
    for (let x = x0; x < x1; x += cell) {
      edge(x, z0, x + cell, z0)
      edge(x + cell, z1, x, z1)
    }
    for (let z = z0; z < z1; z += cell) {
      edge(x0, z + cell, x0, z)
      edge(x1, z, x1, z + cell)
    }
    const geo = new THREE.BufferGeometry()
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3))
    geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3))
    geo.computeVertexNormals()
    this.scene.add(new THREE.Mesh(geo, new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide })))
  }

  private buildTrees() {
    const spots: { x: number; y: number; z: number; s: number }[] = []
    for (let i = 0; i < 15000; i++) {
      const x = WORLD.minX + 100 + hash(i, 1) * (WORLD.maxX - WORLD.minX - 200)
      const z = WORLD.minZ + 100 + hash(i, 2) * (WORLD.maxZ - WORLD.minZ - 200)
      if (this.onPavement(x, z, 35)) continue
      if (ROADS.some(r => insidePave(r, x, z, 15))) continue
      if (TOWNS.some(r => insidePave(r, x, z, 20)) || this.farmRects.some(r => insidePave(r, x, z, 4))) continue
      const y = terrainHeight(x, z)
      if (y < 0.2 || y > 240 || this.slope(x, z) > 0.6) continue
      if (this.collides(x, y + 1, z) || this.collides(x, y + 1, z + 30) || this.collides(x + 30, y + 1, z)) continue
      spots.push({ x, y, z, s: 0.8 + hash(i, 3) * 0.8 })
    }
    for (const t of this.trees) spots.push({ x: t.x, y: terrainHeight(t.x, t.z), z: t.z, s: t.s })
    TREE_CLUSTERS.forEach((cl, k) => {
      for (let i = 0; i < cl.n; i++) {
        const a = hash(i + k * 1000, 8) * Math.PI * 2, d = Math.sqrt(hash(i + k * 1000, 9)) * cl.r
        const x = cl.x + Math.cos(a) * d, z = cl.z + Math.sin(a) * d
        const y = terrainHeight(x, z)
        if (y < 0.2) continue
        if (this.onPavement(x, z, 8) || ROADS.some(r => insidePave(r, x, z, 6)) || TOWNS.some(t => insidePave(t, x, z, 10)) || this.farmRects.some(r => insidePave(r, x, z, 4))) continue
        if (this.collides(x, y + 1, z)) continue
        spots.push({ x, y, z, s: 0.9 + hash(i + k * 1000, 10) * 0.9 })
      }
    })
    const palms = spots.filter((t, i) => t.z > 44500 && hash(i, 13) > 0.25)
    const rest = spots.filter(t => !palms.includes(t))
    const pines = rest.filter((_, i) => hash(i, 12) > 0.38), broad = rest.filter((_, i) => hash(i, 12) <= 0.38)
    const trunks = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.35, 0.5, 3, 5), new THREE.MeshLambertMaterial({ color: 0x6b4a2b }), spots.length)
    const leaves = new THREE.InstancedMesh(new THREE.ConeGeometry(2.6, 7, 6), new THREE.MeshLambertMaterial({ flatShading: true }), pines.length)
    const crowns = new THREE.InstancedMesh(new THREE.SphereGeometry(3, 6, 5), new THREE.MeshLambertMaterial({ flatShading: true }), broad.length)
    const palmTrunks = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.22, 0.4, 9, 5), new THREE.MeshLambertMaterial({ color: 0x8a6a45 }), palms.length)
    const fronds = new THREE.ConeGeometry(2.8, 2.4, 7)
    fronds.rotateX(Math.PI)
    const palmCrowns = new THREE.InstancedMesh(fronds, new THREE.MeshLambertMaterial({ flatShading: true }), palms.length)
    const m = new THREE.Matrix4()
    const c = new THREE.Color()
    const identity = new THREE.Matrix4()
    rest.forEach((t, i) => {
      m.makeScale(t.s, t.s, t.s).setPosition(t.x, t.y + 1.5 * t.s, t.z)
      trunks.setMatrixAt(i, m)
    })
    trunks.count = rest.length
    spots.forEach(t => this.obstacles.push({ inv: identity, box: new THREE.Box3().setFromCenterAndSize(new THREE.Vector3(t.x, t.y + 4.5 * t.s, t.z), new THREE.Vector3(3.4 * t.s, 9 * t.s, 3.4 * t.s)), reason: 'Hit a tree' }))
    palms.forEach((t, i) => {
      m.makeScale(t.s, t.s, t.s).setPosition(t.x, t.y + 4.5 * t.s, t.z)
      palmTrunks.setMatrixAt(i, m)
      m.makeScale(t.s, t.s, t.s).setPosition(t.x, t.y + 9.6 * t.s, t.z)
      palmCrowns.setMatrixAt(i, m)
      palmCrowns.setColorAt(i, c.setHSL(0.27 + hash(i, 8) * 0.06, 0.6, 0.32 + hash(i, 9) * 0.1))
    })
    pines.forEach((t, i) => {
      m.makeScale(t.s, t.s, t.s).setPosition(t.x, t.y + 6 * t.s, t.z)
      leaves.setMatrixAt(i, m)
      leaves.setColorAt(i, c.setHSL(0.3 + hash(i, 4) * 0.09, 0.55, 0.3 + hash(i, 5) * 0.12))
    })
    broad.forEach((t, i) => {
      m.makeScale(t.s * 1.1, t.s * 0.9, t.s * 1.1).setPosition(t.x, t.y + 5.4 * t.s, t.z)
      crowns.setMatrixAt(i, m)
      crowns.setColorAt(i, c.setHSL(0.22 + hash(i, 6) * 0.1, 0.5, 0.33 + hash(i, 7) * 0.12))
    })
    trunks.castShadow = leaves.castShadow = crowns.castShadow = palmTrunks.castShadow = palmCrowns.castShadow = true
    this.scene.add(trunks, leaves, crowns, palmTrunks, palmCrowns)
  }

  private buildClouds() {
    const mat = new THREE.MeshLambertMaterial({ color: 0xffffff, flatShading: true })
    const geo = new THREE.SphereGeometry(1, 7, 5)
    for (let i = 0; i < 420; i++) {
      const g = new THREE.Group()
      const n = 3 + Math.floor(hash(i, 7) * 3)
      for (let k = 0; k < n; k++) {
        const s = new THREE.Mesh(geo, mat)
        const r = 12 + hash(i, k + 10) * 14
        s.scale.set(r * 1.5, r * 0.7, r)
        s.position.set((hash(i, k + 20) - 0.5) * 60, (hash(i, k + 30) - 0.5) * 8, (hash(i, k + 40) - 0.5) * 36)
        g.add(s)
      }
      g.position.set(WORLD.minX + hash(i, 50) * (WORLD.maxX - WORLD.minX), 260 + hash(i, 60) * 240, WORLD.minZ + hash(i, 70) * (WORLD.maxZ - WORLD.minZ))
      this.clouds.push(g)
      this.scene.add(flatten(g))
    }
  }
}
